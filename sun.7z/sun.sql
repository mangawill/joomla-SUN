-- MySQL dump 10.13  Distrib 5.5.8, for Win32 (x86)
--
-- Host: localhost    Database: sun
-- ------------------------------------------------------
-- Server version	5.5.8

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `j25_assets`
--

DROP TABLE IF EXISTS `j25_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `j25_assets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set parent.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `level` int(10) unsigned NOT NULL COMMENT 'The cached level in the nested tree.',
  `name` varchar(50) NOT NULL COMMENT 'The unique name for the asset.\n',
  `title` varchar(100) NOT NULL COMMENT 'The descriptive title for the asset.',
  `rules` varchar(5120) NOT NULL COMMENT 'JSON encoded access control.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_asset_name` (`name`),
  KEY `idx_lft_rgt` (`lft`,`rgt`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `j25_assets`
--

LOCK TABLES `j25_assets` WRITE;
/*!40000 ALTER TABLE `j25_assets` DISABLE KEYS */;
INSERT INTO `j25_assets` VALUES (35,1,69,70,1,'com_content.article.2','游戏规则',''),(36,1,71,72,1,'com_content.article.3','存款取款',''),(37,1,73,74,1,'com_content.article.4','常见问题',''),(38,1,75,76,1,'com_content.article.5','联系我们',''),(39,1,77,78,1,'com_content.article.6','苹果向开发者提供iOS 4.3 Golden Master',''),(40,1,79,80,1,'com_content.article.7','迪斯尼收购HTML5游戏开发商Rocket Pack',''),(41,1,81,82,1,'com_content.article.8','迪斯尼收购HTML5游戏开发商Rocket Pack',''),(42,1,83,84,1,'com_content.article.9','苹果向开发者提供iOS 4.3 Golden Master',''),(43,1,85,86,1,'com_content.article.10','苹果向开发者提供iOS 4.3 Golden Master',''),(44,1,87,88,1,'com_content.article.11','迪斯尼收购HTML5游戏开发商Rocket Pack',''),(45,1,89,90,1,'com_content.article.12','迪斯尼收购HTML5游戏开发商Rocket Pack',''),(46,1,91,92,1,'com_content.article.13','苹果向开发者提供iOS 4.3 Golden Master',''),(47,1,93,94,1,'com_content.article.14','苹果向开发者提供iOS 4.3 Golden Master',''),(48,1,95,96,1,'com_content.article.15','迪斯尼收购HTML5游戏开发商Rocket Pack',''),(49,1,97,98,1,'com_content.article.16','迪斯尼收购HTML5游戏开发商Rocket Pack',''),(50,1,99,100,1,'com_content.article.17','苹果向开发者提供iOS 4.3 Golden Master',''),(51,1,101,102,1,'com_content.article.18','苹果向开发者提供iOS 4.3 Golden Master',''),(52,1,103,104,1,'com_content.article.19','迪斯尼收购HTML5游戏开发商Rocket Pack',''),(53,1,105,106,1,'com_content.article.20','迪斯尼收购HTML5游戏开发商Rocket Pack',''),(54,1,107,108,1,'com_content.article.21','最新优惠',''),(55,1,109,110,1,'com_content.article.22','实时定位－Location',''),(56,1,111,112,1,'com_content.article.23','历史活动轨迹-Track',''),(57,1,113,114,1,'com_content.article.24','终端状态-Presence',''),(58,1,115,116,1,'com_content.article.25','发送邮件-Email',''),(59,1,117,118,1,'com_content.article.26','短信功能-SMS',''),(60,1,119,120,1,'com_content.article.27','语音通话-Call',''),(61,1,121,122,1,'com_content.article.28','首页',''),(62,1,123,124,1,'com_content.article.29','产品用途',''),(63,1,125,126,1,'com_content.article.30','BANNER1',''),(64,1,127,128,1,'com_content.article.31','BANNER1',''),(65,1,129,130,1,'com_content.article.32','BANNER1',''),(66,1,131,132,1,'com_content.article.33','BANNER1',''),(67,1,133,134,1,'com_content.article.34','首   页',''),(68,1,135,136,1,'com_content.article.35','关于我们',''),(69,1,137,138,1,'com_content.article.36','游戏规则',''),(70,1,139,140,1,'com_content.article.37','存款取款',''),(71,1,141,142,1,'com_content.article.38','最新优惠',''),(72,1,143,144,1,'com_content.article.39','常见问题',''),(73,1,145,146,1,'com_content.article.40','联系我们',''),(74,1,147,148,1,'com_content.article.41','会员存款',''),(75,1,149,150,1,'com_content.article.42','规则与条款',''),(76,1,151,152,1,'com_content.article.43','百家乐',''),(77,1,153,154,1,'com_content.article.44','骰宝玩法',''),(78,1,155,156,1,'com_content.article.45','轮盘玩法',''),(79,1,157,158,1,'com_content.article.46','龙虎斗',''),(80,1,159,160,1,'com_content.article.47','斗牛游戏',''),(81,1,161,162,1,'com_content.article.48','三公对对碰',''),(82,1,163,164,1,'com_content.article.49','加勒比海 扑克',''),(83,1,165,166,1,'com_content.article.50','闯关连赢夺大奖',''),(84,1,167,168,1,'com_content.article.51','会员提款',''),(85,1,169,170,1,'com_content.article.52','取款流程',''),(86,1,171,172,1,'com_content.article.53','博彩责任',''),(87,1,173,174,1,'com_content.article.54','免责条款',''),(88,1,175,176,1,'com_content.article.55','私隐政策',''),(89,1,177,178,1,'com_content.article.56','服务条款',''),(90,1,179,180,1,'com_content.article.57','关于我们',''),(91,7,16,17,2,'com_contact.category.1','墨认分类',''),(92,1,67,68,1,'com_content.article.1','关于我们','');
/*!40000 ALTER TABLE `j25_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_aicontactsafe_config`
--

DROP TABLE IF EXISTS `uxlo0_aicontactsafe_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_aicontactsafe_config` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `config_key` varchar(50) NOT NULL DEFAULT '',
  `config_value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_aicontactsafe_config`
--

LOCK TABLES `uxlo0_aicontactsafe_config` WRITE;
/*!40000 ALTER TABLE `uxlo0_aicontactsafe_config` DISABLE KEYS */;
INSERT INTO `uxlo0_aicontactsafe_config` VALUES (1,'use_css_backend','1'),(2,'use_SqueezeBox','0'),(3,'highlight_errors','1'),(4,'keep_session_alive','0'),(5,'activate_help','1'),(6,'date_format','l, d F Y H:i'),(7,'default_status_filter','0'),(8,'editbox_cols','40'),(9,'editbox_rows','10'),(10,'default_name',''),(11,'default_email',''),(12,'default_subject',''),(13,'activate_spam_control','0'),(14,'block_words','url='),(15,'record_blocked_messages','1'),(16,'activate_ip_ban','0'),(17,'ban_ips',''),(18,'redirect_ips',''),(19,'ban_ips_blocked_words','0'),(20,'maximum_messages_ban_ip','0'),(21,'maximum_minutes_ban_ip','0'),(22,'email_ban_ip',''),(23,'set_sender_joomla','0'),(24,'upload_attachments','media&#92;aicontactsafe&#92;attachments'),(25,'maximum_size','5000000'),(26,'attachments_types','rar,zip,doc,xls,txt,gif,jpg,png,bmp'),(27,'attach_to_email','1'),(28,'delete_after_sent','0'),(29,'gid_messages','8'),(30,'users_all_messages','0');
/*!40000 ALTER TABLE `uxlo0_aicontactsafe_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_aicontactsafe_contactinformations`
--

DROP TABLE IF EXISTS `uxlo0_aicontactsafe_contactinformations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_aicontactsafe_contactinformations` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `profile_id` int(11) unsigned NOT NULL,
  `info_key` varchar(50) NOT NULL DEFAULT '',
  `info_label` varchar(250) NOT NULL DEFAULT '',
  `info_value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_aicontactsafe_contactinformations`
--

LOCK TABLES `uxlo0_aicontactsafe_contactinformations` WRITE;
/*!40000 ALTER TABLE `uxlo0_aicontactsafe_contactinformations` DISABLE KEYS */;
INSERT INTO `uxlo0_aicontactsafe_contactinformations` VALUES (1,1,'contact_info','contact_info','<img style=\"margin-left: 10px; float: right;\" alt=\"powered by joomla\" src=\"images/powered_by.png\" width=\"165\" height=\"68\" /><div style=\"width: 150px; float: left;\">Algis Info Grup SRL<br />Str. Hărmanului Nr.63<br />bl.1A sc.A ap.8<br />Brașov, România<br />500232<br /><a target=\"_blank\" href=\"http://www.algisinfo.com/\">www.algisinfo.com</a></div>'),(2,2,'contact_info','contact_info','<img style=\"margin-left: 10px; float: right;\" alt=\"powered by joomla\" src=\"images/powered_by.png\" width=\"165\" height=\"68\" /><div style=\"width: 150px; float: left;\">Algis Info Grup SRL<br />Str. Hărmanului Nr.63<br />bl.1A sc.A ap.8<br />Brașov, România<br />500232<br /><a target=\"_blank\" href=\"http://www.algisinfo.com/\">www.algisinfo.com</a></div>'),(3,1,'meta_description','meta_description',''),(4,2,'meta_description','meta_description',''),(5,1,'meta_keywords','meta_keywords',''),(6,2,'meta_keywords','meta_keywords',''),(7,1,'meta_robots','meta_robots',''),(8,2,'meta_robots','meta_robots',''),(9,1,'thank_you_message','thank_you_message','Email sent. Thank you for your message.'),(10,2,'thank_you_message','thank_you_message','Email sent. Thank you for your message.'),(11,1,'required_field_notification','required_field_notification','Fields marked with %mark% are required.'),(12,2,'required_field_notification','required_field_notification','Fields marked with %mark% are required.'),(13,3,'meta_description','meta_description (会员提款)',''),(14,3,'meta_keywords','meta_keywords (会员提款)',''),(15,3,'meta_robots','meta_robots (会员提款)',''),(16,3,'thank_you_message','thank_you_message (会员提款)','Email sent. Thank you for your message.'),(17,3,'required_field_notification','required_field_notification (会员提款)','请详细填写以下表格，带 * 项目为必填项目，提交成功后请在10分钟内暂停投注，我们会在10分钟内为您支付，有任何问题请联系我们的在线客服或QQ客服为您处理'),(18,3,'contact_info','contact_info (会员提款)','');
/*!40000 ALTER TABLE `uxlo0_aicontactsafe_contactinformations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_aicontactsafe_fields`
--

DROP TABLE IF EXISTS `uxlo0_aicontactsafe_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_aicontactsafe_fields` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `field_label` text NOT NULL,
  `label_parameters` text NOT NULL,
  `field_label_message` text NOT NULL,
  `label_message_parameters` text NOT NULL,
  `label_after_field` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `field_type` varchar(2) NOT NULL DEFAULT 'TX',
  `field_parameters` text NOT NULL,
  `field_values` text NOT NULL,
  `field_limit` int(11) NOT NULL DEFAULT '0',
  `default_value` varchar(150) NOT NULL DEFAULT '',
  `auto_fill` varchar(10) NOT NULL DEFAULT '',
  `field_sufix` text NOT NULL,
  `field_prefix` text NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `field_required` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `field_in_message` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `send_message` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_update` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `checked_out` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_aicontactsafe_fields`
--

LOCK TABLES `uxlo0_aicontactsafe_fields` WRITE;
/*!40000 ALTER TABLE `uxlo0_aicontactsafe_fields` DISABLE KEYS */;
INSERT INTO `uxlo0_aicontactsafe_fields` VALUES (1,'aics_name','Name','','Name','',0,'TX','class=\'textbox\'','',0,'','UN','','',1,1,1,0,'2012-04-28 23:11:26','2012-04-28 23:11:26',1,0,'0000-00-00'),(2,'aics_email','Email','','Email','',0,'EM','class=\'email\'','',0,'','UE','','',2,1,1,0,'2012-04-28 23:11:26','2012-04-28 23:11:26',1,0,'0000-00-00'),(3,'aics_phone','Phone','','Phone','',0,'TX','class=\'textbox\'','',15,'','','','',3,0,1,0,'2012-04-28 23:11:26','2012-04-28 23:11:26',1,0,'0000-00-00'),(4,'aics_subject','Subject','','Subject','',0,'TX','class=\'textbox\'','',0,'','','','',4,1,1,0,'2012-04-28 23:11:26','2012-04-28 23:11:26',1,0,'0000-00-00'),(5,'aics_message','Message','','Message','',0,'ED','class=\'editbox\'','',500,'','','','',5,1,1,0,'2012-04-28 23:11:26','2012-04-28 23:11:26',1,0,'0000-00-00'),(6,'aics_send_to_sender','Send a copy of this message to yourself','','Send a copy of this message to yourself','',1,'CK','class=\'checkbox\'','',0,'','','','',6,0,0,0,'2012-04-28 23:11:26','2012-04-28 23:11:26',1,0,'0000-00-00'),(7,'aics_username','游戏帐号','','游戏帐号','',0,'TX','','',0,'','','请输入您开户的帐号','',0,1,1,0,'2012-04-28 15:14:00','2012-04-28 15:48:28',1,0,'0000-00-00'),(8,'aics_amount','提款金额','','提款金额','',0,'TX','','',0,'','','请输入您要取款的现金额度','',0,1,1,0,'2012-04-28 15:14:44','2012-04-28 15:49:22',1,0,'0000-00-00'),(9,'aics_bank','开户银行','','开户银行','',0,'CB','ac=','农业银行;\r\n建设银行;\r\n工商银行;\r\n中国银行;\r\n招商银行;\r\n交通银行',0,'','','','',0,1,1,0,'2012-04-28 15:16:55','2012-04-28 15:36:48',1,0,'0000-00-00'),(10,'aics_bank_account','银行账号','','银行账号','',0,'TX','','',0,'','','(请注意：银行账号姓名必须跟游戏账号姓名保持一致)','',0,1,1,0,'2012-04-28 15:37:37','2012-04-28 15:49:52',1,0,'0000-00-00'),(11,'aics_bank_name','银行账号开户姓名','','银行账号开户姓名','',0,'TX','','',0,'','','','',0,1,1,0,'2012-04-28 15:38:28','2012-04-28 15:38:28',1,0,'0000-00-00'),(12,'aics_address','详细地址','','详细地址','',0,'TX','','',0,'','','**省**市/县**支行/分理处','',0,1,1,0,'2012-04-28 15:38:59','2012-04-28 15:52:49',1,0,'0000-00-00'),(13,'aics_password','取款口令','','取款口令','',0,'TX','','',0,'','','','',0,1,1,0,'2012-04-28 15:40:30','2012-04-28 15:40:30',1,0,'0000-00-00');
/*!40000 ALTER TABLE `uxlo0_aicontactsafe_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_aicontactsafe_fieldvalues`
--

DROP TABLE IF EXISTS `uxlo0_aicontactsafe_fieldvalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_aicontactsafe_fieldvalues` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `field_id` int(11) unsigned NOT NULL,
  `message_id` int(11) unsigned NOT NULL,
  `field_value` text NOT NULL,
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_update` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `checked_out` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_aicontactsafe_fieldvalues`
--

LOCK TABLES `uxlo0_aicontactsafe_fieldvalues` WRITE;
/*!40000 ALTER TABLE `uxlo0_aicontactsafe_fieldvalues` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_aicontactsafe_fieldvalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_aicontactsafe_messagefiles`
--

DROP TABLE IF EXISTS `uxlo0_aicontactsafe_messagefiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_aicontactsafe_messagefiles` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `message_id` int(11) unsigned NOT NULL,
  `name` text NOT NULL,
  `r_id` int(21) unsigned NOT NULL,
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_update` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `checked_out` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_aicontactsafe_messagefiles`
--

LOCK TABLES `uxlo0_aicontactsafe_messagefiles` WRITE;
/*!40000 ALTER TABLE `uxlo0_aicontactsafe_messagefiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_aicontactsafe_messagefiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_aicontactsafe_messages`
--

DROP TABLE IF EXISTS `uxlo0_aicontactsafe_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_aicontactsafe_messages` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `subject` varchar(200) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  `send_to_sender` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `sender_ip` varchar(20) NOT NULL DEFAULT '',
  `profile_id` int(11) unsigned NOT NULL,
  `status_id` int(11) unsigned NOT NULL,
  `manual_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `email_destination` text NOT NULL,
  `email_reply` varchar(100) NOT NULL DEFAULT '',
  `subject_reply` text NOT NULL,
  `message_reply` text NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_update` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `checked_out` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_aicontactsafe_messages`
--

LOCK TABLES `uxlo0_aicontactsafe_messages` WRITE;
/*!40000 ALTER TABLE `uxlo0_aicontactsafe_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_aicontactsafe_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_aicontactsafe_profiles`
--

DROP TABLE IF EXISTS `uxlo0_aicontactsafe_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_aicontactsafe_profiles` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `use_ajax` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `use_message_css` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `contact_form_width` int(11) NOT NULL DEFAULT '0',
  `bottom_row_space` int(11) NOT NULL DEFAULT '0',
  `align_buttons` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `contact_info_width` int(11) NOT NULL DEFAULT '0',
  `use_captcha` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `captcha_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `align_captcha` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `email_address` varchar(100) NOT NULL DEFAULT '',
  `always_send_to_email_address` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `subject_prefix` varchar(100) NOT NULL DEFAULT '',
  `email_mode` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `record_message` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `record_fields` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `custom_date_format` varchar(30) NOT NULL DEFAULT '%d %B %Y',
  `custom_date_years_back` int(11) NOT NULL DEFAULT '70',
  `custom_date_years_forward` int(11) NOT NULL DEFAULT '0',
  `required_field_mark` text NOT NULL,
  `display_format` int(11) NOT NULL DEFAULT '2',
  `plg_contact_info` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `use_random_letters` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `min_word_length` tinyint(2) unsigned NOT NULL DEFAULT '5',
  `max_word_length` tinyint(2) unsigned NOT NULL DEFAULT '8',
  `set_default` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `active_fields` text NOT NULL,
  `captcha_width` smallint(4) NOT NULL DEFAULT '400',
  `captcha_height` smallint(4) NOT NULL DEFAULT '55',
  `captcha_bgcolor` varchar(10) NOT NULL DEFAULT '#FFFFFF',
  `captcha_backgroundTransparent` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `captcha_colors` text NOT NULL,
  `name_field_id` int(11) unsigned NOT NULL,
  `email_field_id` int(11) unsigned NOT NULL,
  `subject_field_id` int(11) unsigned NOT NULL,
  `send_to_sender_field_id` int(11) NOT NULL,
  `redirect_on_success` text NOT NULL,
  `fields_order` text NOT NULL,
  `use_mail_template` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `default_status_id` int(11) unsigned NOT NULL,
  `read_status_id` int(11) unsigned NOT NULL,
  `reply_status_id` int(11) unsigned NOT NULL,
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_update` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `checked_out` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_aicontactsafe_profiles`
--

LOCK TABLES `uxlo0_aicontactsafe_profiles` WRITE;
/*!40000 ALTER TABLE `uxlo0_aicontactsafe_profiles` DISABLE KEYS */;
INSERT INTO `uxlo0_aicontactsafe_profiles` VALUES (1,'Default form',0,1,0,0,1,0,1,0,1,'',1,'',1,1,0,'%d %B %Y',60,0,'( ! )',2,0,0,5,8,1,'0',300,55,'#FFFFFF',1,'#FF0000;#00FF00;#0000FF',1,2,4,6,'','',0,1,2,3,'2009-01-01 00:00:00','2009-01-01 00:00:00',1,0,'0000-00-00'),(2,'Module form',0,1,0,0,1,0,1,0,1,'',1,'',1,1,0,'%d %B %Y',60,0,'( ! )',1,0,0,5,8,0,'0',180,55,'#FFFFFF',1,'#FF0000;#00FF00;#0000FF',1,2,4,6,'','',0,1,2,3,'2009-01-01 00:00:00','2009-01-01 00:00:00',1,0,'0000-00-00'),(3,'会员提款',0,1,0,0,0,0,0,0,0,'',0,'',0,1,1,'dmy',80,0,'*',0,0,0,0,0,0,'7,8,9,10,11,12,13',400,55,'#FFFFFF',0,'#FF0000;#00FF00;#0000FF',7,0,0,0,'','7,8,9,1,2,3,4,5,6,10,11,12,13',1,1,1,1,'2012-04-28 15:21:49','2012-04-28 15:54:38',1,0,'0000-00-00');
/*!40000 ALTER TABLE `uxlo0_aicontactsafe_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_aicontactsafe_statuses`
--

DROP TABLE IF EXISTS `uxlo0_aicontactsafe_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_aicontactsafe_statuses` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL DEFAULT '',
  `color` varchar(10) NOT NULL DEFAULT '#FFFFFF',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_update` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `checked_out` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_aicontactsafe_statuses`
--

LOCK TABLES `uxlo0_aicontactsafe_statuses` WRITE;
/*!40000 ALTER TABLE `uxlo0_aicontactsafe_statuses` DISABLE KEYS */;
INSERT INTO `uxlo0_aicontactsafe_statuses` VALUES (1,'New','#FF0000',1,'2012-04-28 23:11:26','2012-04-28 23:11:26',1,0,'0000-00-00'),(2,'Read','#000000',2,'2012-04-28 23:11:26','2012-04-28 23:11:26',1,0,'0000-00-00'),(3,'Replied','#009900',3,'2012-04-28 23:11:26','2012-04-28 23:11:26',1,0,'0000-00-00'),(4,'Archived','#CCCCCC',4,'2012-04-28 23:11:26','2012-04-28 23:11:26',1,0,'0000-00-00');
/*!40000 ALTER TABLE `uxlo0_aicontactsafe_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_assets`
--

DROP TABLE IF EXISTS `uxlo0_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_assets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set parent.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `level` int(10) unsigned NOT NULL COMMENT 'The cached level in the nested tree.',
  `name` varchar(50) NOT NULL COMMENT 'The unique name for the asset.\n',
  `title` varchar(100) NOT NULL COMMENT 'The descriptive title for the asset.',
  `rules` varchar(5120) NOT NULL COMMENT 'JSON encoded access control.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_asset_name` (`name`),
  KEY `idx_lft_rgt` (`lft`,`rgt`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_assets`
--

LOCK TABLES `uxlo0_assets` WRITE;
/*!40000 ALTER TABLE `uxlo0_assets` DISABLE KEYS */;
INSERT INTO `uxlo0_assets` VALUES (1,0,1,119,0,'root.1','Root Asset','{\"core.login.site\":{\"6\":1,\"2\":1},\"core.login.admin\":{\"6\":1},\"core.login.offline\":{\"6\":1},\"core.admin\":{\"8\":1},\"core.manage\":{\"7\":1},\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1}}'),(2,1,1,2,1,'com_admin','com_admin','{}'),(3,1,3,6,1,'com_banners','com_banners','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(4,1,7,8,1,'com_cache','com_cache','{\"core.admin\":{\"7\":1},\"core.manage\":{\"7\":1}}'),(5,1,9,10,1,'com_checkin','com_checkin','{\"core.admin\":{\"7\":1},\"core.manage\":{\"7\":1}}'),(6,1,11,12,1,'com_config','com_config','{}'),(7,1,13,16,1,'com_contact','com_contact','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(8,1,17,58,1,'com_content','com_content','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(9,1,59,60,1,'com_cpanel','com_cpanel','{}'),(10,1,61,62,1,'com_installer','com_installer','{\"core.admin\":[],\"core.manage\":{\"7\":0},\"core.delete\":{\"7\":0},\"core.edit.state\":{\"7\":0}}'),(11,1,63,64,1,'com_languages','com_languages','{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(12,1,65,66,1,'com_login','com_login','{}'),(13,1,67,68,1,'com_mailto','com_mailto','{}'),(14,1,69,70,1,'com_massmail','com_massmail','{}'),(15,1,71,72,1,'com_media','com_media','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":{\"5\":1}}'),(16,1,73,74,1,'com_menus','com_menus','{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(17,1,75,76,1,'com_messages','com_messages','{\"core.admin\":{\"7\":1},\"core.manage\":{\"7\":1}}'),(18,1,77,78,1,'com_modules','com_modules','{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(19,1,79,82,1,'com_newsfeeds','com_newsfeeds','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(20,1,83,84,1,'com_plugins','com_plugins','{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(21,1,85,86,1,'com_redirect','com_redirect','{\"core.admin\":{\"7\":1},\"core.manage\":[]}'),(22,1,87,88,1,'com_search','com_search','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1}}'),(23,1,89,90,1,'com_templates','com_templates','{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(24,1,91,94,1,'com_users','com_users','{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(25,1,95,98,1,'com_weblinks','com_weblinks','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(26,1,99,100,1,'com_wrapper','com_wrapper','{}'),(27,8,18,23,2,'com_content.category.2','Uncategorised','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(28,3,4,5,2,'com_banners.category.3','Uncategorised','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(29,7,14,15,2,'com_contact.category.4','Uncategorised','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(30,19,80,81,2,'com_newsfeeds.category.5','Uncategorised','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(31,25,96,97,2,'com_weblinks.category.6','Uncategorised','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(32,24,92,93,1,'com_users.notes.category.7','Uncategorised','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(33,1,101,102,1,'com_finder','com_finder','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1}}'),(34,1,103,104,1,'com_joomlaupdate','com_joomlaupdate','{\"core.admin\":[],\"core.manage\":[],\"core.delete\":[],\"core.edit.state\":[]}'),(35,27,19,20,3,'com_content.article.58','test','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(36,1,105,106,1,'com_jce','jce','{}'),(37,1,107,108,1,'com_xcloner-backupandrestore','xcloner-backupandrestore','{}'),(38,40,27,28,3,'com_content.article.37','存款取款','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(39,40,25,26,3,'com_content.article.52','取款流程','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(40,8,24,29,2,'com_content.category.8','存款取款','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(41,1,109,110,1,'com_easybookreloaded','com_easybookreloaded','{\"core.admin\":[],\"core.manage\":[]}'),(42,1,111,112,1,'com_aicontactsafe','aicontactsafe','{}'),(43,1,113,118,1,'com_djimageslider','com_djimageslider','{}'),(45,43,114,115,2,'com_djimageslider.category.9','Home Top Slideshow',''),(46,8,30,33,2,'com_content.category.10','System','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(47,46,31,32,3,'com_content.article.59','Home','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(48,43,116,117,2,'com_djimageslider.category.11','Home Bottom Slideshow',''),(49,8,34,49,2,'com_content.category.12','游戏','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(50,49,35,36,3,'com_content.article.49','加勒比海 扑克',''),(51,49,37,38,3,'com_content.article.47','斗牛游戏',''),(52,49,39,40,3,'com_content.article.43','百家乐',''),(53,49,41,42,3,'com_content.article.45','轮盘玩法',''),(54,49,43,44,3,'com_content.article.44','骰宝玩法',''),(55,49,45,46,3,'com_content.article.48','三公对对碰',''),(56,49,47,48,3,'com_content.article.46','龙虎斗',''),(57,8,50,57,2,'com_content.category.13','最新优惠','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(58,57,51,52,3,'com_content.article.60','开户礼金','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(59,57,53,54,3,'com_content.article.61','高额洗码','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(60,57,55,56,3,'com_content.article.62','保险礼金','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(61,27,21,22,3,'com_content.article.40','联系我们','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}');
/*!40000 ALTER TABLE `uxlo0_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_associations`
--

DROP TABLE IF EXISTS `uxlo0_associations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_associations` (
  `id` varchar(50) NOT NULL COMMENT 'A reference to the associated item.',
  `context` varchar(50) NOT NULL COMMENT 'The context of the associated item.',
  `key` char(32) NOT NULL COMMENT 'The key for the association computed from an md5 on associated ids.',
  PRIMARY KEY (`context`,`id`),
  KEY `idx_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_associations`
--

LOCK TABLES `uxlo0_associations` WRITE;
/*!40000 ALTER TABLE `uxlo0_associations` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_associations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_banner_clients`
--

DROP TABLE IF EXISTS `uxlo0_banner_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_banner_clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `contact` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `extrainfo` text NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `metakey` text NOT NULL,
  `own_prefix` tinyint(4) NOT NULL DEFAULT '0',
  `metakey_prefix` varchar(255) NOT NULL DEFAULT '',
  `purchase_type` tinyint(4) NOT NULL DEFAULT '-1',
  `track_clicks` tinyint(4) NOT NULL DEFAULT '-1',
  `track_impressions` tinyint(4) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`),
  KEY `idx_own_prefix` (`own_prefix`),
  KEY `idx_metakey_prefix` (`metakey_prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_banner_clients`
--

LOCK TABLES `uxlo0_banner_clients` WRITE;
/*!40000 ALTER TABLE `uxlo0_banner_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_banner_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_banner_tracks`
--

DROP TABLE IF EXISTS `uxlo0_banner_tracks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_banner_tracks` (
  `track_date` datetime NOT NULL,
  `track_type` int(10) unsigned NOT NULL,
  `banner_id` int(10) unsigned NOT NULL,
  `count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`track_date`,`track_type`,`banner_id`),
  KEY `idx_track_date` (`track_date`),
  KEY `idx_track_type` (`track_type`),
  KEY `idx_banner_id` (`banner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_banner_tracks`
--

LOCK TABLES `uxlo0_banner_tracks` WRITE;
/*!40000 ALTER TABLE `uxlo0_banner_tracks` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_banner_tracks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_banners`
--

DROP TABLE IF EXISTS `uxlo0_banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `imptotal` int(11) NOT NULL DEFAULT '0',
  `impmade` int(11) NOT NULL DEFAULT '0',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `clickurl` varchar(200) NOT NULL DEFAULT '',
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `custombannercode` varchar(2048) NOT NULL,
  `sticky` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `params` text NOT NULL,
  `own_prefix` tinyint(1) NOT NULL DEFAULT '0',
  `metakey_prefix` varchar(255) NOT NULL DEFAULT '',
  `purchase_type` tinyint(4) NOT NULL DEFAULT '-1',
  `track_clicks` tinyint(4) NOT NULL DEFAULT '-1',
  `track_impressions` tinyint(4) NOT NULL DEFAULT '-1',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `reset` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `language` char(7) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`state`),
  KEY `idx_own_prefix` (`own_prefix`),
  KEY `idx_metakey_prefix` (`metakey_prefix`),
  KEY `idx_banner_catid` (`catid`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_banners`
--

LOCK TABLES `uxlo0_banners` WRITE;
/*!40000 ALTER TABLE `uxlo0_banners` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_categories`
--

DROP TABLE IF EXISTS `uxlo0_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `level` int(10) unsigned NOT NULL DEFAULT '0',
  `path` varchar(255) NOT NULL DEFAULT '',
  `extension` varchar(50) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `metadesc` varchar(1024) NOT NULL COMMENT 'The meta description for the page.',
  `metakey` varchar(1024) NOT NULL COMMENT 'The meta keywords for the page.',
  `metadata` varchar(2048) NOT NULL COMMENT 'JSON encoded metadata properties.',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cat_idx` (`extension`,`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_path` (`path`),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_categories`
--

LOCK TABLES `uxlo0_categories` WRITE;
/*!40000 ALTER TABLE `uxlo0_categories` DISABLE KEYS */;
INSERT INTO `uxlo0_categories` VALUES (1,0,0,0,25,0,'','system','ROOT','root','','',1,0,'0000-00-00 00:00:00',1,'{}','','','',0,'2009-10-18 16:07:09',0,'0000-00-00 00:00:00',0,'*'),(2,27,1,1,2,1,'uncategorised','com_content','Uncategorised','uncategorised','','',1,0,'0000-00-00 00:00:00',1,'{\"target\":\"\",\"image\":\"\"}','','','{\"page_title\":\"\",\"author\":\"\",\"robots\":\"\"}',42,'2010-06-28 13:26:37',0,'0000-00-00 00:00:00',0,'*'),(3,28,1,3,4,1,'uncategorised','com_banners','Uncategorised','uncategorised','','',1,0,'0000-00-00 00:00:00',1,'{\"target\":\"\",\"image\":\"\",\"foobar\":\"\"}','','','{\"page_title\":\"\",\"author\":\"\",\"robots\":\"\"}',42,'2010-06-28 13:27:35',0,'0000-00-00 00:00:00',0,'*'),(4,29,1,5,6,1,'uncategorised','com_contact','Uncategorised','uncategorised','','',1,0,'0000-00-00 00:00:00',1,'{\"target\":\"\",\"image\":\"\"}','','','{\"page_title\":\"\",\"author\":\"\",\"robots\":\"\"}',42,'2010-06-28 13:27:57',0,'0000-00-00 00:00:00',0,'*'),(5,30,1,7,8,1,'uncategorised','com_newsfeeds','Uncategorised','uncategorised','','',1,0,'0000-00-00 00:00:00',1,'{\"target\":\"\",\"image\":\"\"}','','','{\"page_title\":\"\",\"author\":\"\",\"robots\":\"\"}',42,'2010-06-28 13:28:15',0,'0000-00-00 00:00:00',0,'*'),(6,31,1,9,10,1,'uncategorised','com_weblinks','Uncategorised','uncategorised','','',1,0,'0000-00-00 00:00:00',1,'{\"target\":\"\",\"image\":\"\"}','','','{\"page_title\":\"\",\"author\":\"\",\"robots\":\"\"}',42,'2010-06-28 13:28:33',0,'0000-00-00 00:00:00',0,'*'),(7,32,1,11,12,1,'uncategorised','com_users.notes','Uncategorised','uncategorised','','',1,0,'0000-00-00 00:00:00',1,'{\"target\":\"\",\"image\":\"\"}','','','{\"page_title\":\"\",\"author\":\"\",\"robots\":\"\"}',42,'2010-06-28 13:28:33',0,'0000-00-00 00:00:00',0,'*'),(8,40,1,13,14,1,'deposit-cat','com_content','存款取款','deposit-cat','','',1,0,'0000-00-00 00:00:00',1,'{\"category_layout\":\"\",\"image\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',42,'2012-04-24 16:34:52',0,'0000-00-00 00:00:00',0,'*'),(9,45,1,15,16,1,'home-top-slideshow','com_djimageslider','Home Top Slideshow','home-top-slideshow','','',1,0,'0000-00-00 00:00:00',1,'{\"category_layout\":\"\",\"image\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',42,'2012-04-30 14:08:30',42,'2012-04-30 14:22:55',0,'*'),(10,46,1,17,18,1,'system','com_content','System','system','','',1,0,'0000-00-00 00:00:00',1,'{\"category_layout\":\"\",\"image\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',42,'2012-04-30 14:27:07',0,'0000-00-00 00:00:00',0,'*'),(11,48,1,19,20,1,'home-bottom-slideshow','com_djimageslider','Home Bottom Slideshow','home-bottom-slideshow','','',1,0,'0000-00-00 00:00:00',1,'{\"category_layout\":\"\",\"image\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',42,'2012-04-30 14:45:36',0,'0000-00-00 00:00:00',0,'*'),(12,49,1,21,22,1,'2012-05-01-10-08-58','com_content','游戏','2012-05-01-10-08-58','','',1,0,'0000-00-00 00:00:00',1,'{\"category_layout\":\"\",\"image\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',42,'2012-05-01 10:08:58',0,'0000-00-00 00:00:00',0,'*'),(13,57,1,23,24,1,'2012-05-05-03-21-35','com_content','最新优惠','2012-05-05-03-21-35','','',1,0,'0000-00-00 00:00:00',1,'{\"category_layout\":\"\",\"image\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',42,'2012-05-05 03:21:35',0,'0000-00-00 00:00:00',0,'*');
/*!40000 ALTER TABLE `uxlo0_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_contact_details`
--

DROP TABLE IF EXISTS `uxlo0_contact_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_contact_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `con_position` varchar(255) DEFAULT NULL,
  `address` text,
  `suburb` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `postcode` varchar(100) DEFAULT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `misc` mediumtext,
  `image` varchar(255) DEFAULT NULL,
  `imagepos` varchar(20) DEFAULT NULL,
  `email_to` varchar(255) DEFAULT NULL,
  `default_con` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `mobile` varchar(255) NOT NULL DEFAULT '',
  `webpage` varchar(255) NOT NULL DEFAULT '',
  `sortname1` varchar(255) NOT NULL,
  `sortname2` varchar(255) NOT NULL,
  `sortname3` varchar(255) NOT NULL,
  `language` char(7) NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if article is featured.',
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`published`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_contact_details`
--

LOCK TABLES `uxlo0_contact_details` WRITE;
/*!40000 ALTER TABLE `uxlo0_contact_details` DISABLE KEYS */;
INSERT INTO `uxlo0_contact_details` VALUES (1,'Super User','super-user','china','address','','','','','','','','',NULL,'william@qq.com',0,1,0,'0000-00-00 00:00:00',1,'{\"show_contact_category\":\"\",\"show_contact_list\":\"\",\"presentation_style\":\"\",\"show_name\":\"\",\"show_position\":\"\",\"show_email\":\"\",\"show_street_address\":\"\",\"show_suburb\":\"\",\"show_state\":\"\",\"show_postcode\":\"\",\"show_country\":\"\",\"show_telephone\":\"\",\"show_mobile\":\"\",\"show_fax\":\"\",\"show_webpage\":\"\",\"show_misc\":\"\",\"show_image\":\"\",\"allow_vcard\":\"\",\"show_articles\":\"\",\"show_profile\":\"\",\"show_links\":\"\",\"linka_name\":\"\",\"linka\":null,\"linkb_name\":\"\",\"linkb\":null,\"linkc_name\":\"\",\"linkc\":null,\"linkd_name\":\"\",\"linkd\":null,\"linke_name\":\"\",\"linke\":\"\",\"contact_layout\":\"\",\"show_email_form\":\"\",\"show_email_copy\":\"\",\"banned_email\":\"\",\"banned_subject\":\"\",\"banned_text\":\"\",\"validate_session\":\"\",\"custom_reply\":\"\",\"redirect\":\"\"}',42,4,1,'','','','','','*','2012-04-28 14:13:28',42,'','0000-00-00 00:00:00',0,'','','{\"robots\":\"\",\"rights\":\"\"}',0,'','0000-00-00 00:00:00','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `uxlo0_contact_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_content`
--

DROP TABLE IF EXISTS `uxlo0_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `title_alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT 'Deprecated in Joomla! 3.0',
  `introtext` mediumtext NOT NULL,
  `fulltext` mediumtext NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `sectionid` int(10) unsigned NOT NULL DEFAULT '0',
  `mask` int(10) unsigned NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` text NOT NULL,
  `urls` text NOT NULL,
  `attribs` varchar(5120) NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `parentid` int(10) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `metadata` text NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if article is featured.',
  `language` char(7) NOT NULL COMMENT 'The language code for the article.',
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`state`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_content`
--

LOCK TABLES `uxlo0_content` WRITE;
/*!40000 ALTER TABLE `uxlo0_content` DISABLE KEYS */;
INSERT INTO `uxlo0_content` VALUES (1,92,'关于我们','about-us','','<p style=\"text-align: center;\"><img src=\"images/stories/bs_iphone.jpg\" border=\"0\" /></p>\r\n<h3>用途概述</h3>\r\n<div>本站是国内第一个在线手机定位网站，您可以在本站使用电脑在地图上来定位跟踪手机的位置，除了可以在线定位手机外，还可以发送短信、语音通话、发送Email、随时查看手机的状态是否关机以及查看手机持有者的历史活动轨迹。</div>\r\n<div>\r\n<h3>工作原理</h3>\r\n<ul>\r\n<li> 首先您需要在本站首页的右面注册为本站会员并进行登录，注册需要您添加了全球唯一的一个号码用于语音    通信，然后从本站下载手机安装程序，并进在你的Android手机进行安装； </li>\r\n<li> 其次在您登录本站的前提下，在首页右面点击“号码添加”菜单，把您要定位的手机号码添加进来，这一步    可以添加多个号码，但要保证每一个号码都安装了手机程序； </li>\r\n<li> 完成上面两步以后，您就可以接着上面的操作点击“业务使用”菜单，这样您就会进入您要监控的手机的地    图呈现页面，这一步需要等待10分钟左右，就可以使用以上所有的业务了。 </li>\r\n</ul>\r\n</div>','',-2,0,0,2,'2011-03-03 19:32:54',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-03 19:32:54','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',6,0,0,'','',1,29,'',0,'*',''),(2,35,'游戏规则','game-rules','','<p style=\"text-align: center;\"><img src=\"images/stories/use_06.jpg\" border=\"0\" /></p>\r\n<p> </p>\r\n<p>第一步：首先您需要在本站首页的右面注册为本站会员并进行登录，注册需要您添加了全球唯一的一个号码用<br /> 于语音通信，然后从本站下载手机安装程序，并进在你的Android手机进行安装；<br /><br />第二步：其次在您登录本站的前提下，在首页右面点击“号码添加”菜单，把您要定位的手机号码添加进来，<br /> 这一步可以添加多个号码，但要保证每一个号码都安装了手机程序；<br /><br />第三步：完成上面两步以后，您就可以接着上面的操作点击“业务使用”菜单，这样您就会进入您要监控的手<br /> 机的地图呈现页面，这一步需要等待10分钟左右，就可以使用以上所有的业务了。</p>','',-2,0,0,2,'2011-03-03 19:33:44',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-03 19:33:44','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',4,0,0,'','',1,17,'',0,'*',''),(3,36,'存款取款','getprice','','<p><a href=\"#\">推荐业务：3G天翼</a></p>','',-2,0,0,2,'2011-03-03 19:34:33',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-03 19:34:33','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',4,0,0,'','',1,15,'',0,'*',''),(4,37,'常见问题','faq','','<ul>\r\n<li>\r\n<h5>1)	问：为什么我打开地图后没有看到监控的号码？</h5>\r\n<div>答：这可能是因为您首次使用本站，您安装的手机程序还没有把位置信息传回到服务器，这时需要您等待10分钟左右。</div>\r\n</li>\r\n<li>\r\n<h5>2)	为什么我上次查看地图的时候没有问题，这次打开后却确无法出现显示手机位置的“气泡”？</h5>\r\n<div>答：这可能是因为您IE的Cooker文件所致，您可以清理一下您的IE的缓存，然后刷新网页。</div>\r\n</li>\r\n<li>\r\n<h5>3)	为什么我注册的时候显示我的联系电话的号码已经有人用了？</h5>\r\n<div>答：这个号码不是真正的手机号码，只要服务器数据库中没有的号码就能实现语音通话，这时您可以换一个联系电话进行注册</div>\r\n</li>\r\n</ul>','',-2,0,0,2,'2011-03-03 19:35:12',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-03 19:35:12','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',2,0,0,'','',1,13,'',0,'*',''),(5,38,'联系我们','contact-us','','<p>sdf</p>','',-2,0,0,2,'2011-03-03 19:35:31',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-03 19:35:31','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',2,0,0,'','',1,7,'',0,'*',''),(6,39,'苹果向开发者提供iOS 4.3 Golden Master','ios-43-golden-master','','<p><strong>苹果今天发布了Golden Master版本的iOS  4.3，并已经将这一版本投放到开发人员，该版本预计正式发布时间3月11日，可用于iPad、iPhone 4、3GS和3-4代的iPod  Touch，而iPad 2中已经内置iOS 4.3，版本号为8F190。</strong><br /> iOS 4.3将为第三方应用增加Airplay功能，以及全新的“个人热点”（Personal Hotspot）WIFI连接功能。</p>','',-2,0,0,2,'2011-03-03 23:34:02',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-03 23:34:02','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,0,0,'','',1,0,'',0,'*',''),(7,40,'迪斯尼收购HTML5游戏开发商Rocket Pack','html5rocket-pack','','<p><strong>迪斯尼发言人确认，公司已经收购芬兰HTML5游戏引擎初创公司Rocket Pack，但迪斯尼方面没有透露收购价格，不过据知情人士透露，收购价格在1000万-2000万美元之间。</strong>迪斯尼发言人表示，公司已经收购Rocket Pack，它将为迪斯尼免插件浏览器游戏开发提供整合方案，收购后Racket Pack将成为迪士尼互动媒体集团完全拥有的子公司。</p>\r\n<p><img src=\"http://img.cnbeta.com/newsimg/110304/071158063567521.jpg\" border=\"0\" alt=\"http://img.cnbeta.com/newsimg/110304/071158063567521.jpg\" /><br /> <br /> <img src=\"http://img.cnbeta.com/newsimg/110304/07120311997660076.png\" border=\"0\" alt=\"http://img.cnbeta.com/newsimg/110304/07120311997660076.png\" /><br /> <br /> 据分析师推测，迪斯尼收购Rocket Pack意在摆脱苹果应用商店（App Store）的控制，Rocker  Pack开发的HTML5游戏可以直接在浏览器中运行，只使用javascript和CSS语言，无需安装额外插件，无需Flash的支持。从旧款的上网 本到新出的iPad，都可以运行Rocket Pack的游戏。通过Rocket  Pack网页游戏开发平台，用户甚至可以在iPad上编辑和创造游戏，因为Rocket Pack的游戏在Safari浏览器中也可以运行。</p>','',-2,0,0,2,'2011-03-03 23:35:13',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-03 23:35:13','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,0,0,'','',1,3,'',0,'*',''),(8,41,'迪斯尼收购HTML5游戏开发商Rocket Pack','html5rocket-pack1','','<p><strong>迪斯尼发言人确认，公司已经收购芬兰HTML5游戏引擎初创公司Rocket Pack，但迪斯尼方面没有透露收购价格，不过据知情人士透露，收购价格在1000万-2000万美元之间。</strong>迪斯尼发言人表示，公司已经收购Rocket Pack，它将为迪斯尼免插件浏览器游戏开发提供整合方案，收购后Racket Pack将成为迪士尼互动媒体集团完全拥有的子公司。</p>\r\n<p><img src=\"http://img.cnbeta.com/newsimg/110304/071158063567521.jpg\" border=\"0\" alt=\"http://img.cnbeta.com/newsimg/110304/071158063567521.jpg\" /><br /> <br /> <img src=\"http://img.cnbeta.com/newsimg/110304/07120311997660076.png\" border=\"0\" alt=\"http://img.cnbeta.com/newsimg/110304/07120311997660076.png\" /><br /> <br /> 据分析师推测，迪斯尼收购Rocket Pack意在摆脱苹果应用商店（App Store）的控制，Rocker  Pack开发的HTML5游戏可以直接在浏览器中运行，只使用javascript和CSS语言，无需安装额外插件，无需Flash的支持。从旧款的上网 本到新出的iPad，都可以运行Rocket Pack的游戏。通过Rocket  Pack网页游戏开发平台，用户甚至可以在iPad上编辑和创造游戏，因为Rocket Pack的游戏在Safari浏览器中也可以运行。</p>','',-2,0,0,2,'2011-03-03 23:35:13',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-03 23:35:13','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',0,0,0,'','',1,0,'',0,'*',''),(9,42,'苹果向开发者提供iOS 4.3 Golden Master','ios-43-golden-master2','','<p><strong>苹果今天发布了Golden Master版本的iOS  4.3，并已经将这一版本投放到开发人员，该版本预计正式发布时间3月11日，可用于iPad、iPhone 4、3GS和3-4代的iPod  Touch，而iPad 2中已经内置iOS 4.3，版本号为8F190。</strong><br /> iOS 4.3将为第三方应用增加Airplay功能，以及全新的“个人热点”（Personal Hotspot）WIFI连接功能。</p>','',-2,0,0,2,'2011-03-03 23:34:02',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-03 23:34:02','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',0,0,0,'','',1,0,'',0,'*',''),(10,43,'苹果向开发者提供iOS 4.3 Golden Master','ios-43-golden-master3','','<p><strong>苹果今天发布了Golden Master版本的iOS  4.3，并已经将这一版本投放到开发人员，该版本预计正式发布时间3月11日，可用于iPad、iPhone 4、3GS和3-4代的iPod  Touch，而iPad 2中已经内置iOS 4.3，版本号为8F190。</strong><br /> iOS 4.3将为第三方应用增加Airplay功能，以及全新的“个人热点”（Personal Hotspot）WIFI连接功能。</p>','',-2,0,0,2,'2011-03-03 23:34:02',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-03 23:34:02','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',0,0,0,'','',1,0,'',0,'*',''),(11,44,'迪斯尼收购HTML5游戏开发商Rocket Pack','html5rocket-pack4','','<p><strong>迪斯尼发言人确认，公司已经收购芬兰HTML5游戏引擎初创公司Rocket Pack，但迪斯尼方面没有透露收购价格，不过据知情人士透露，收购价格在1000万-2000万美元之间。</strong>迪斯尼发言人表示，公司已经收购Rocket Pack，它将为迪斯尼免插件浏览器游戏开发提供整合方案，收购后Racket Pack将成为迪士尼互动媒体集团完全拥有的子公司。</p>\r\n<p><img src=\"http://img.cnbeta.com/newsimg/110304/071158063567521.jpg\" border=\"0\" alt=\"http://img.cnbeta.com/newsimg/110304/071158063567521.jpg\" /><br /> <br /> <img src=\"http://img.cnbeta.com/newsimg/110304/07120311997660076.png\" border=\"0\" alt=\"http://img.cnbeta.com/newsimg/110304/07120311997660076.png\" /><br /> <br /> 据分析师推测，迪斯尼收购Rocket Pack意在摆脱苹果应用商店（App Store）的控制，Rocker  Pack开发的HTML5游戏可以直接在浏览器中运行，只使用javascript和CSS语言，无需安装额外插件，无需Flash的支持。从旧款的上网 本到新出的iPad，都可以运行Rocket Pack的游戏。通过Rocket  Pack网页游戏开发平台，用户甚至可以在iPad上编辑和创造游戏，因为Rocket Pack的游戏在Safari浏览器中也可以运行。</p>','',-2,0,0,2,'2011-03-03 23:35:13',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-03 23:35:13','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',0,0,0,'','',1,0,'',0,'*',''),(12,45,'迪斯尼收购HTML5游戏开发商Rocket Pack','html5rocket-pack5','','<p><strong>迪斯尼发言人确认，公司已经收购芬兰HTML5游戏引擎初创公司Rocket Pack，但迪斯尼方面没有透露收购价格，不过据知情人士透露，收购价格在1000万-2000万美元之间。</strong>迪斯尼发言人表示，公司已经收购Rocket Pack，它将为迪斯尼免插件浏览器游戏开发提供整合方案，收购后Racket Pack将成为迪士尼互动媒体集团完全拥有的子公司。</p>\r\n<p><img src=\"http://img.cnbeta.com/newsimg/110304/071158063567521.jpg\" border=\"0\" alt=\"http://img.cnbeta.com/newsimg/110304/071158063567521.jpg\" /><br /> <br /> <img src=\"http://img.cnbeta.com/newsimg/110304/07120311997660076.png\" border=\"0\" alt=\"http://img.cnbeta.com/newsimg/110304/07120311997660076.png\" /><br /> <br /> 据分析师推测，迪斯尼收购Rocket Pack意在摆脱苹果应用商店（App Store）的控制，Rocker  Pack开发的HTML5游戏可以直接在浏览器中运行，只使用javascript和CSS语言，无需安装额外插件，无需Flash的支持。从旧款的上网 本到新出的iPad，都可以运行Rocket Pack的游戏。通过Rocket  Pack网页游戏开发平台，用户甚至可以在iPad上编辑和创造游戏，因为Rocket Pack的游戏在Safari浏览器中也可以运行。</p>','',-2,0,0,2,'2011-03-03 23:35:13',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-03 23:35:13','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',0,0,0,'','',1,0,'',0,'*',''),(13,46,'苹果向开发者提供iOS 4.3 Golden Master','ios-43-golden-master6','','<p><strong>苹果今天发布了Golden Master版本的iOS  4.3，并已经将这一版本投放到开发人员，该版本预计正式发布时间3月11日，可用于iPad、iPhone 4、3GS和3-4代的iPod  Touch，而iPad 2中已经内置iOS 4.3，版本号为8F190。</strong><br /> iOS 4.3将为第三方应用增加Airplay功能，以及全新的“个人热点”（Personal Hotspot）WIFI连接功能。</p>','',-2,0,0,2,'2011-03-03 23:34:02',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-03 23:34:02','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',0,0,0,'','',1,0,'',0,'*',''),(14,47,'苹果向开发者提供iOS 4.3 Golden Master','ios-43-golden-master7','','<p><strong>苹果今天发布了Golden Master版本的iOS  4.3，并已经将这一版本投放到开发人员，该版本预计正式发布时间3月11日，可用于iPad、iPhone 4、3GS和3-4代的iPod  Touch，而iPad 2中已经内置iOS 4.3，版本号为8F190。</strong><br /> iOS 4.3将为第三方应用增加Airplay功能，以及全新的“个人热点”（Personal Hotspot）WIFI连接功能。</p>','',-2,0,0,2,'2011-03-03 23:34:02',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-03 23:34:02','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',0,0,0,'','',1,0,'',0,'*',''),(15,48,'迪斯尼收购HTML5游戏开发商Rocket Pack','html5rocket-pack8','','<p><strong>迪斯尼发言人确认，公司已经收购芬兰HTML5游戏引擎初创公司Rocket Pack，但迪斯尼方面没有透露收购价格，不过据知情人士透露，收购价格在1000万-2000万美元之间。</strong>迪斯尼发言人表示，公司已经收购Rocket Pack，它将为迪斯尼免插件浏览器游戏开发提供整合方案，收购后Racket Pack将成为迪士尼互动媒体集团完全拥有的子公司。</p>\r\n<p><img src=\"http://img.cnbeta.com/newsimg/110304/071158063567521.jpg\" border=\"0\" alt=\"http://img.cnbeta.com/newsimg/110304/071158063567521.jpg\" /><br /> <br /> <img src=\"http://img.cnbeta.com/newsimg/110304/07120311997660076.png\" border=\"0\" alt=\"http://img.cnbeta.com/newsimg/110304/07120311997660076.png\" /><br /> <br /> 据分析师推测，迪斯尼收购Rocket Pack意在摆脱苹果应用商店（App Store）的控制，Rocker  Pack开发的HTML5游戏可以直接在浏览器中运行，只使用javascript和CSS语言，无需安装额外插件，无需Flash的支持。从旧款的上网 本到新出的iPad，都可以运行Rocket Pack的游戏。通过Rocket  Pack网页游戏开发平台，用户甚至可以在iPad上编辑和创造游戏，因为Rocket Pack的游戏在Safari浏览器中也可以运行。</p>','',-2,0,0,2,'2011-03-03 23:35:13',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-03 23:35:13','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',0,0,0,'','',1,0,'',0,'*',''),(16,49,'迪斯尼收购HTML5游戏开发商Rocket Pack','html5rocket-pack9','','<p><strong>迪斯尼发言人确认，公司已经收购芬兰HTML5游戏引擎初创公司Rocket Pack，但迪斯尼方面没有透露收购价格，不过据知情人士透露，收购价格在1000万-2000万美元之间。</strong>迪斯尼发言人表示，公司已经收购Rocket Pack，它将为迪斯尼免插件浏览器游戏开发提供整合方案，收购后Racket Pack将成为迪士尼互动媒体集团完全拥有的子公司。</p>\r\n<p><img src=\"http://img.cnbeta.com/newsimg/110304/071158063567521.jpg\" border=\"0\" alt=\"http://img.cnbeta.com/newsimg/110304/071158063567521.jpg\" /><br /> <br /> <img src=\"http://img.cnbeta.com/newsimg/110304/07120311997660076.png\" border=\"0\" alt=\"http://img.cnbeta.com/newsimg/110304/07120311997660076.png\" /><br /> <br /> 据分析师推测，迪斯尼收购Rocket Pack意在摆脱苹果应用商店（App Store）的控制，Rocker  Pack开发的HTML5游戏可以直接在浏览器中运行，只使用javascript和CSS语言，无需安装额外插件，无需Flash的支持。从旧款的上网 本到新出的iPad，都可以运行Rocket Pack的游戏。通过Rocket  Pack网页游戏开发平台，用户甚至可以在iPad上编辑和创造游戏，因为Rocket Pack的游戏在Safari浏览器中也可以运行。</p>','',-2,0,0,2,'2011-03-03 23:35:13',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-03 23:35:13','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',0,0,0,'','',1,0,'',0,'*',''),(17,50,'苹果向开发者提供iOS 4.3 Golden Master','ios-43-golden-master10','','<p><strong>苹果今天发布了Golden Master版本的iOS  4.3，并已经将这一版本投放到开发人员，该版本预计正式发布时间3月11日，可用于iPad、iPhone 4、3GS和3-4代的iPod  Touch，而iPad 2中已经内置iOS 4.3，版本号为8F190。</strong><br /> iOS 4.3将为第三方应用增加Airplay功能，以及全新的“个人热点”（Personal Hotspot）WIFI连接功能。</p>','',-2,0,0,2,'2011-03-03 23:34:02',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-03 23:34:02','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',0,0,0,'','',1,0,'',0,'*',''),(18,51,'苹果向开发者提供iOS 4.3 Golden Master','ios-43-golden-master11','','<p><strong>苹果今天发布了Golden Master版本的iOS  4.3，并已经将这一版本投放到开发人员，该版本预计正式发布时间3月11日，可用于iPad、iPhone 4、3GS和3-4代的iPod  Touch，而iPad 2中已经内置iOS 4.3，版本号为8F190。</strong><br /> iOS 4.3将为第三方应用增加Airplay功能，以及全新的“个人热点”（Personal Hotspot）WIFI连接功能。</p>','',-2,0,0,2,'2011-03-03 23:34:02',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-03 23:34:02','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',0,0,0,'','',1,0,'',0,'*',''),(19,52,'迪斯尼收购HTML5游戏开发商Rocket Pack','html5rocket-pack12','','<p><strong>迪斯尼发言人确认，公司已经收购芬兰HTML5游戏引擎初创公司Rocket Pack，但迪斯尼方面没有透露收购价格，不过据知情人士透露，收购价格在1000万-2000万美元之间。</strong>迪斯尼发言人表示，公司已经收购Rocket Pack，它将为迪斯尼免插件浏览器游戏开发提供整合方案，收购后Racket Pack将成为迪士尼互动媒体集团完全拥有的子公司。</p>\r\n<p><img src=\"http://img.cnbeta.com/newsimg/110304/071158063567521.jpg\" border=\"0\" alt=\"http://img.cnbeta.com/newsimg/110304/071158063567521.jpg\" /><br /> <br /> <img src=\"http://img.cnbeta.com/newsimg/110304/07120311997660076.png\" border=\"0\" alt=\"http://img.cnbeta.com/newsimg/110304/07120311997660076.png\" /><br /> <br /> 据分析师推测，迪斯尼收购Rocket Pack意在摆脱苹果应用商店（App Store）的控制，Rocker  Pack开发的HTML5游戏可以直接在浏览器中运行，只使用javascript和CSS语言，无需安装额外插件，无需Flash的支持。从旧款的上网 本到新出的iPad，都可以运行Rocket Pack的游戏。通过Rocket  Pack网页游戏开发平台，用户甚至可以在iPad上编辑和创造游戏，因为Rocket Pack的游戏在Safari浏览器中也可以运行。</p>','',-2,0,0,2,'2011-03-03 23:35:13',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-03 23:35:13','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',0,0,0,'','',1,0,'',0,'*',''),(20,53,'迪斯尼收购HTML5游戏开发商Rocket Pack','html5rocket-pack13','','<p><strong>迪斯尼发言人确认，公司已经收购芬兰HTML5游戏引擎初创公司Rocket Pack，但迪斯尼方面没有透露收购价格，不过据知情人士透露，收购价格在1000万-2000万美元之间。</strong>迪斯尼发言人表示，公司已经收购Rocket Pack，它将为迪斯尼免插件浏览器游戏开发提供整合方案，收购后Racket Pack将成为迪士尼互动媒体集团完全拥有的子公司。</p>\r\n<p><img src=\"http://img.cnbeta.com/newsimg/110304/071158063567521.jpg\" border=\"0\" alt=\"http://img.cnbeta.com/newsimg/110304/071158063567521.jpg\" /><br /> <br /> <img src=\"http://img.cnbeta.com/newsimg/110304/07120311997660076.png\" border=\"0\" alt=\"http://img.cnbeta.com/newsimg/110304/07120311997660076.png\" /><br /> <br /> 据分析师推测，迪斯尼收购Rocket Pack意在摆脱苹果应用商店（App Store）的控制，Rocker  Pack开发的HTML5游戏可以直接在浏览器中运行，只使用javascript和CSS语言，无需安装额外插件，无需Flash的支持。从旧款的上网 本到新出的iPad，都可以运行Rocket Pack的游戏。通过Rocket  Pack网页游戏开发平台，用户甚至可以在iPad上编辑和创造游戏，因为Rocket Pack的游戏在Safari浏览器中也可以运行。</p>','',-2,0,0,2,'2011-03-03 23:35:13',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-03 23:35:13','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',0,0,0,'','',1,0,'',0,'*',''),(21,54,'最新优惠','pomo','','<p><strong>苹果今天发布了Golden Master版本的iOS  4.3，并已经将这一版本投放到开发人员，该版本预计正式发布时间3月11日，可用于iPad、iPhone 4、3GS和3-4代的iPod  Touch，而iPad 2中已经内置iOS 4.3，版本号为8F190。</strong><br /> iOS 4.3将为第三方应用增加Airplay功能，以及全新的“个人热点”（Personal Hotspot）WIFI连接功能。</p>','',-2,0,0,2,'2011-03-03 23:34:02',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-03 23:34:02','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,0,0,'','',1,1,'',0,'*',''),(22,55,'实时定位－Location','location','','<p>当您的要监控的手机安装了本站的手机程序，并且您已经在登录后把这个手机的号码通过“号码管理”菜单添加到服务器的数据库中以后，您就可以在点击“使用业务”菜单后进入定位地图，您可以在地图上找到您要监控的手机的“气泡”位置。可以用于：<br />老人小孩守护<br />机构外勤人员监控<br />帮忙您找到您丢失的手机</p>','',-2,0,0,2,'2011-03-04 23:41:26',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-04 23:41:26','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',2,0,0,'','',1,0,'',0,'*',''),(23,56,'历史活动轨迹-Track','track','','<p>在您监控的手机的“气泡”上进行单击，就可以弹出一个业务窗口，点击ShowTrack就可以看到这个手机本月的活动轨迹，当然您还可以通过点击地图页面的“Show Today”按钮来 查看这个号码今天的活动轨迹。可以用于：<br />查看手机当天活动轨迹<br />查看手机一个月的活动轨迹</p>','',-2,0,0,2,'2011-03-04 23:43:34',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-04 23:43:34','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,0,0,'','',1,0,'',0,'*',''),(24,57,'终端状态-Presence','presence','','<p>终端状态-Presence：<br />任何时候当您打开您的定位地图的时候，你都可以看到某一个手机“气泡”的颜色，红色代表该手机已经关机，绿色代表开机状态，此外“气泡”上面显示的手机当前的状态，主要有三个图标：行走、站立、下班回家。可以用于：<br />您的员工是不是在关键时候关机了<br />您的孩子是不是在上学的路上停止了</p>','',-2,0,0,2,'2011-03-04 23:46:07',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-04 23:46:07','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,0,0,'','',1,0,'',0,'*',''),(25,58,'发送邮件-Email','email','','<p>本站还支持在线发送邮件功能，支持163、QQ、Gmail等邮件发送。可以用于：<br />自动添加邮件接收者Email地址<br />小巧精致，方便快捷</p>','',-2,0,0,2,'2011-03-04 23:47:15',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-04 23:47:15','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,0,0,'','',1,0,'',0,'*',''),(26,59,'短信功能-SMS','sms','','<p>在您监控的手机的“气泡”上进行单击，就可以弹出一个业务窗口，点击SMS按钮，就会弹出一个短信的对话框，您可以在对话框下面输入您要发送的信息内容，然后点击“发送”按钮进行发送，短信对话框上面是对方给你回复过来的信息。可以用于：<br />电脑打字方便快捷<br />在线点击一键发送</p>','',-2,0,0,2,'2011-03-04 23:48:07',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-04 23:48:07','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,0,0,'','',1,0,'',0,'*',''),(27,60,'语音通话-Call','call','','<p>在您监控的手机的“气泡”上进行单击，就可以弹出一个业务窗口，点击MakeCall按钮，您就可以和该号码进行语音通话了。可以用于：<br />远程支持路线指导<br />一键通业务方便快捷<br />下午时间通话节省费用</p>','',-2,0,0,2,'2011-03-04 23:48:53',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-04 23:48:53','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,0,0,'','',1,0,'',0,'*',''),(28,61,'首页','homepage','','<h1 class=\"headline\">手机定位业务介绍</h1>\r\n<p>{loadposition user1}</p>','',-2,0,0,2,'2011-03-04 23:52:26',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-04 23:52:26','0000-00-00 00:00:00','','','{\"show_title\":0,\"link_titles\":0,\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',9,0,0,'','',1,243,'',0,'*',''),(29,62,'产品用途','products-use','','<p>用途概述：本站是国内第一个在线手机定位网站，您可以在本站使用电脑在地图上来定位跟踪手机的位置，除了可以在线定位手机外，还可以发送短信、语音通话、发送Email、随时查看手机的状态是否关机以及查看手机持有者的历史活动轨迹。</p>\r\n<p>● 使用范围：老人小孩守护、机构外勤人员监控、还有其他需要进行手机定位、监控和通信的用途，相信通过使用本站，您可以保证家人安全，提高工作效率，极大的丰富了人们的沟通和生活。</p>\r\n<p><img src=\"images/stories/bs_iphone.jpg\" border=\"0\" style=\"float: left;\" />1):首先您需要在本站首页的右面注册为本站会员并进行登录，注册需要您添加了全球唯一的一个号码用于语音通信，然后从本站下载手机安装程序，并进在你的Android手机进行安装；</p>\r\n<p>2):其次在您登录本站的前提下，在首页右面点击“号码添加”菜单，把您要定位的手机号码添加进来，这一步可以添加多个号码，但要保证每一个号码都安装了手机程<br /> 序；<br />3):完成上面两步以后，您就可以接着上面的操作点击“业务使用”菜单，这样您就会进入您要监控的手机的地图呈现页面，这一步需要等待10分钟左右，就可以使用以<br />上所有的业务了。 <br /><br /><br />声明：<br />1)    当前支持Android、Symbian s60 3rd手机使用，以后我们会逐步扩展。<br />2)    本站不会造成隐私侵权，因为必须是在取得手机持有者同意后才能进行手机程序的安装；</p>','',-2,0,0,2,'2011-03-03 19:32:54',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-03 19:32:54','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',3,0,0,'','',1,0,'',0,'*',''),(30,63,'BANNER1','banner1','','<p><img src=\"images/stories/banner.png\" border=\"0\" /></p>','',-2,0,0,2,'2011-03-06 00:45:25',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-06 00:45:25','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,0,0,'','',1,0,'',0,'*',''),(31,64,'BANNER1','banner114','','<p><img src=\"images/stories/banner3.jpg\" border=\"0\" /></p>','',-2,0,0,2,'2011-03-06 00:45:25',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-06 00:45:25','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,0,0,'','',1,0,'',0,'*',''),(32,65,'BANNER1','banner115','','<p><img src=\"images/stories/banner2.jpg\" border=\"0\" /></p>','',-2,0,0,2,'2011-03-06 00:45:25',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-06 00:45:25','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,0,0,'','',1,0,'',0,'*',''),(33,66,'BANNER1','banner116','','<p><img src=\"images/stories/banner.png\" border=\"0\" /></p>','',-2,0,0,2,'2011-03-06 00:45:25',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-06 00:45:25','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',0,0,0,'','',1,0,'',0,'*',''),(34,67,'首   页','2011-03-19-13-25-52','','<p>首   页</p>','',-2,0,0,2,'2011-03-19 13:25:44',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-19 13:25:44','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,0,0,'','',1,20832,'',0,'*',''),(35,68,'关于我们','2011-03-19-13-26-19','','<p>Sun City集团为正式注册的网上博彩公司。成立至今，我们不但为客户提供多元化网上娱乐，更承诺配备最优质的投注方法，並辅以最先进的网络技术支援，献上最佳的客户服务和最优惠的支付方案。我们致力于为广大客户提供丰富精彩的博彩活动，並极力以最优质的收费方式及丰富奖赏作回馈。</p>\r\n<p>太阳城的合法网上娱乐埸牌照是由菲律宾政府唯一认可的发牌及监管单位FCLRC(First Cagayan Leisure and Resort  Corporation )签发，FCLRC为卡加延特别经济区及自由港(CSEZFP)之互动总发牌及监管单位，严格要求持牌公司必须使用经 批准软件，并定时审查各公司的运作情况，确保客户使用的平台达到公平及安全的要求，保证客户与太阳城公司之间的公平 与公正，这已充份彰显太阳城的公正素质及能力。</p>\r\n<p align=\"center\"><img src=\"images/aboutus.jpg\" border=\"0\" /></p>\r\n<p>菲律宾太阳城是亚洲区规模庞大、最受玩家欢迎的的互联网真人游戏和电子游戏社区之一，致力於互联网为用户提供多 元化的电子娱乐服务.从2005年开始服务赌城玩家后，我们一直有惊人的成长。一年多来，太阳城一直孜孜不倦地追求技术创 新，依托强大的技术团队，致力於为用户提高质数的娱乐服务。截止到2006年第三季度，太阳城对真人游戏社区建设投资超 过五千万港元，拥有超过一千万注册帐户。时至今日，我们於服务水平及客户满意度方面亦已竖立威信，通过强大的游戏营 运能力，周到的客户服务能力，完善的技术保障和支持能力，高效健全的支付平台，形成了面向用户的综合性互动电子游戏 平台。各年龄层的玩家均可籍由太阳城真人互动游戏平台与其它成千上万的玩家进行互动，体验互动电子娱乐带来的乐趣。 作为太阳城实现”全球最大的真人游戏平台”的战略目标的重要部分，我们通过对软硬件、内容、网络以及服务的整合，为 用户提供更高质的娱乐服务！</p>','',1,0,0,2,'2011-03-19 13:26:08',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-19 13:26:08','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',5,0,14,'','',1,1366,'',0,'*',''),(36,69,'游戏规则','2011-03-19-13-26-34','','<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">\r\n<tbody>\r\n<tr>\r\n<td width=\"50%\" align=\"center\">\r\n<p style=\"text-align: center;\"><a href=\"index.php?option=com_content&amp;view=article&amp;id=43\"><img src=\"images/game1.jpg\" border=\"0\" alt=\"百家乐\" /></a></p>\r\n</td>\r\n<td width=\"50%\" align=\"center\">\r\n<p style=\"text-align: center;\"><a href=\"index.php?option=com_content&amp;view=article&amp;id=44\"><img src=\"images/game2.jpg\" border=\"0\" alt=\"骰宝\" /></a></p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td align=\"center\">\r\n<p style=\"text-align: center;\"><a href=\"index.php?option=com_content&amp;view=article&amp;id=45\"><img src=\"images/game3.jpg\" border=\"0\" alt=\"轮盘\" /></a></p>\r\n</td>\r\n<td align=\"center\">\r\n<p style=\"text-align: center;\"><a href=\"index.php?option=com_content&amp;view=article&amp;id=47\"><img src=\"images/game4.jpg\" border=\"0\" alt=\"斗牛游戏\" /></a></p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td align=\"center\">\r\n<p style=\"text-align: center;\"><a href=\"index.php?option=com_content&amp;view=article&amp;id=48\"><img src=\"images/game5.jpg\" border=\"0\" alt=\"三公对对碰\" /></a></p>\r\n</td>\r\n<td><a href=\"index.php?option=com_content&amp;view=article&amp;id=49\">\r\n<p style=\"text-align: center;\"><img src=\"images/game6.jpg\" border=\"0\" alt=\"加勒比海盗\" /></p>\r\n</a></td>\r\n</tr>\r\n</tbody>\r\n</table>','',1,0,0,2,'2011-03-19 13:26:26',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-19 13:26:26','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',8,0,13,'','',1,1777,'',0,'*',''),(37,38,'存款取款','deposit-put','','<div class=\"deposit_link clearfix\"><a class=\"put active\" href=\"index.php?option=com_content&amp;view=article&amp;id=37&amp;Itemid=103\">put</a> <a class=\"get\" href=\"index.php?option=com_content&amp;view=article&amp;id=52&amp;Itemid=103\">get</a></div>\r\n<p class=\"f_14\" align=\"center\"><strong>太阳城娱乐城目前提供<a class=\"f_14\" href=\"#\">银行转帐汇款</a>和<a class=\"f_14\" href=\"#\">在线支付方式存款</a>两种存款方式</strong></p>\r\n<p><strong>A.银行转帐汇款方式存款: </strong></p>\r\n<p>有开通过网银的用户可以直接通过网银转账至太阳城国际娱乐城存款帐户，未开通网银的用户可至银行柜台或ATM柜员 机进行转账存款，请在转账后请立即直接联系在线客服为您办理存款业务，建议您在转账存款时在尾数加一个零头，如存款 1000改为1000.1方便我们的财务人员对账，加快给您添加额度的速度。</p>\r\n<p>存款需知:</p>\r\n<p>太阳城最低存款为100元人民币 <br /> 未开通网银的会员，请亲洽您的银行柜台办理。<br /> 如有任何问题，请联系24小时在线客服咨询。</p>\r\n<p><strong>B. 在线支付方式存款:</strong></p>\r\n<ol>\r\n<li>点击网站任一页面\"会员存款\".</li>\r\n<li>进入页面后按要求填写个人资料,以\"账户充值\"为例包括充值金额、真实姓名、电话、充值账号以及E-mail(自由 填写).填写完成后,请点击\"立即支付\".</li>\r\n<li>进入\"选择支付银行\"页面.选择您需要进行转账的银行;确认无误后,点击\"立即支付\",进入下支付页面</li>\r\n<li>确认支付时，请您确认您的支付订单无误。</li>\r\n<li>进入网络银行页面，请确实填写您银行账号信息，支付成功后，建议您记录您的支付订单号码，以便查询，并联系 在线客服为您添加额度。</li>\r\n</ol>\r\n<p><strong>1.进入\"选择支付银行\"页面.选择您需要进行转帐的银行;确认无误后,点击\"立即支付\",进入下支付页面.</strong></p>\r\n<p style=\"text-align: center;\"><img src=\"images/step1.jpg\" alt=\"存款取款\" border=\"0\" /></p>\r\n<p><strong>2.进入\"客户订单支付服务\"页面,按要求填写支付卡(账)号,若想修改点击\"重填\",确认无误后点击\"提交\" 进入下一步.（如下图所示）</strong></p>\r\n<hr class=\"system-pagebreak\" />\r\n<p style=\"text-align: center;\"><img src=\"images/step2.jpg\" alt=\"存款取款\" border=\"0\" /></p>\r\n<p><strong>3.进入“预留信息”页面,预留信息确认无误后,点击“全额付款”,进入下一步.（如下图所示）</strong></p>\r\n<p style=\"text-align: center;\"><img src=\"images/step3.jpg\" alt=\"存款取款\" border=\"0\" /></p>\r\n<p><strong>4.进入“确认支付页面”,核对支付信息,输入短信验证码,确认无误后点击“提交” （如下图所示）</strong></p>\r\n<hr class=\"system-pagebreak\" />\r\n<p style=\"text-align: center;\"><img src=\"images/step4.jpg\" alt=\"存款取款\" border=\"0\" /></p>\r\n<p><strong>5、弹出“输入PIN“窗口,请案要求输入相应密码后,点击“确定”（如下图所示）</strong></p>\r\n<p style=\"text-align: center;\"><img src=\"images/step5.jpg\" alt=\"存款取款\" border=\"0\" /></p>\r\n<hr class=\"system-pagebreak\" />\r\n<p><strong>6、弹出视窗显示您的数据签名信息,以及此次交易详情,请点击“确定”.（如下图所示）</strong></p>\r\n<p style=\"text-align: center;\"><img src=\"images/step6.jpg\" alt=\"存款取款\" border=\"0\" /></p>\r\n<p><strong>7、进入“支付成功”页面,网上银行支付成功.请及时联系在线客服为您办理相关业务.（如下图所示）</strong></p>','',1,0,0,8,'2011-03-19 13:26:39',62,'','2012-04-24 16:35:12',42,0,'0000-00-00 00:00:00','2011-03-19 13:26:39','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":null,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":null,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":null,\"urlctext\":\"\",\"targetc\":\"\"}','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',26,0,21,'','',1,1732,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(38,71,'最新优惠','2011-03-19-13-27-54','','<p style=\"text-align: center;\"><img src=\"images/youhui.jpg\" border=\"0\" style=\"vertical-align: middle;\" /></p>\r\n<h2><strong>30%首存红利，最高奖励10000RMB</strong></h2>\r\n<p>作为一名新的真钱玩家，我们将对您的首次存款赠送30%的免费现金红利，最多可达10000RMB.<br />享受首存开户优惠后，投注额达到存款加优惠的8倍即可申请提款：</p>\r\n<p><img src=\"images/youhui2.jpg\" border=\"0\" style=\"vertical-align: middle;\" /></p>\r\n<table border=\"0\" cellspacing=\"1\" cellpadding=\"0\" width=\"80%\">\r\n<tbody>\r\n<tr>\r\n<td>\r\n<p align=\"left\">例子</p>\r\n</td>\r\n<td>\r\n<p align=\"left\">存款</p>\r\n</td>\r\n<td>\r\n<p align=\"left\">得到奖金</p>\r\n</td>\r\n<td>\r\n<p align=\"left\">取款之前必须下注的总额</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align=\"left\">例一</p>\r\n</td>\r\n<td>\r\n<p align=\"left\">1000RMB</p>\r\n</td>\r\n<td>\r\n<p align=\"left\">300RMB</p>\r\n</td>\r\n<td>\r\n<p align=\"left\">（1000RMB+300RMB）*10=13000RMB</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align=\"left\">例二</p>\r\n</td>\r\n<td>\r\n<p align=\"left\">100000RMB</p>\r\n</td>\r\n<td>\r\n<p align=\"left\">10000RMB</p>\r\n</td>\r\n<td>\r\n<p align=\"left\">（100000RMB+30000RMB）*10=1300000RMB</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h2><strong>奖金使用条款 </strong></h2>\r\n<p>1.    玩家只有在太阳城娱乐场的首次存款才有资格获得到此奖金。<br />2.    每个家庭只能持有一个帐户，如果开设了第二个帐户，该帐户将被关闭，所有奖金和彩金将被取消。每个家庭和/或每个帐户将只能得到一次奖金机会。<br />3.    为了公平游戏，您在提取任何现金之前必须下注总额超过您奖金和存款的10倍。任何游戏的无风险投注（例如，在一手牌中平均投注不同的结果，使得投注没有任何风险）不具备提款要求。无风险投注包括在轮盘中同时投注红色和黑色，在百家乐中同时投注庄家和闲家。<br />4.    太阳城娱乐场保留回查交易记录和日志文件的权利。如果通过回查，根据娱乐场的判断，如玩家（们）合谋滥用我们的奖励，娱乐场保留取消该玩家获得促销奖励的权利。<br />5.    如果出现争执，太阳城娱乐场的所有决定将是最终决定。<br />6.    首次存款指第一笔投注之前的合计存款金额。<br />7.    申请首存优惠的有效时间为第一次提款前。</p>\r\n<h2><strong>周周洗码高额回水活动 </strong>:</h2>\r\n<p>太阳城娱乐场更为一直以来支持和关注本公司的新老会员准备了丰厚的洗码回水大礼。<br />洗码是指会员下注有效投注额的退水，不论输赢，只要进行有效投注即可享受洗码(退水)优惠。<br /><br />1.所有在太阳城娱乐场注册的真钱会员都享有周有效投注额0.2%的洗码<br />2.一周内有效投注额达到10万人民币（或首次开户存款1000元，并全额投注），可以享受0.4%的洗码优惠。<br />3.一周内有效投注额达到50万人民币（或首次开户存款5000元，并全额投注），可以享受0.6%的洗码优惠。<br />4.一周内有效投注额达到100万人民币（或首次开户存款10000元，并全额投注），即为我们的VIP会员，无论每周投注多少都可终身享受0.8%的洗码优惠，并享有随时结算洗码的权利。<br />4.太阳城将在每周一中午12点开始对上周符合洗码优惠赠送的会员进行结算，并在16点前自动将达到结算条件的会员洗码返点添加到会员的真钱账号上。添加完成后会电话短信通知会员！<br /><br />有效投注额累计时间为一周，一周是以美东时间的礼拜一到礼拜日为准，（北京时间则为周一中午12点到次周一的中午12点），每周一上午12点后开始对上周达到洗码标准的会员进行结算，如一周内达不到洗码标准（有效投注额10万），则没有洗码结算的。下周将会从零算起，重新累计。上一周的投注金额不能累计至下一周。会员享受了洗码优惠后，可以选择继续投注或是申请提款，洗码提款是不受任何限制的。<br /><br /></p>\r\n<h2><strong>优惠条款细则：</strong></h2>\r\n<p><br />1.洗码回水优惠以单个会员账号的有效投注额进行结算。<br />2.只有有效投注额才能享受优惠（无效投注包括在游戏中下注和局、游戏结果为和局、同一局游戏中下注正、反两种结果:如百家乐游戏同一局下注庄闲）。 <br />3.若系统侦测玩家以不正常手段来进行游戏，一经查证属实，会员账号将被永久锁定并取消优惠 。<br />4.如发现玩家使用不正当手段谋取我们的优惠奖励，太阳城娱乐场将保留取消该玩家获得促销奖励的权利。<br />如出现争执，太阳城娱乐场的所有决定将是最终决定，会员参加任何优惠活动则被视为认可并同意遵守规则以及沙龙娱乐城有关规定，愿意受其约束，本公司保留最终解释权。<br /><br />感谢新老会员对太阳城娱乐场的关注和支持，祝您财源广进，盈利多多。</p>\r\n<div>\r\n<h2 style=\"text-align: center;\"><strong>保险礼金活动</strong></h2>\r\n<p align=\"left\">保险礼金活动从发布至今，一直广受各位新老客户的欢迎，本公司为感谢新老客户的厚爱将继续延续此活动！</p>\r\n<p align=\"left\">活动期间，凡充值并全额投注，出现负盈利的会员，都会得到以下比例的保险投注反利。让您有机会返本盈利。</p>\r\n<p align=\"left\">祝您投注愉快，盈利多多。</p>\r\n<h2><strong>（保险投注）赠送细则：</strong> <strong> </strong></h2>\r\n<p align=\"left\">活动时间：2012年12月16日起 		（具体结束时间以新活动开启为准）</p>\r\n<p align=\"left\">只需全额投注即可享受保险礼包，凡是达到赠送礼金条件的用户我们将在次日下午16:00前将礼金自动结算添加到真钱游戏账号（礼金额度5倍投注即可提款）。具体赠送标准如下：</p>\r\n<table border=\"1\" cellpadding=\"0\" width=\"575\">\r\n<tbody>\r\n<tr>\r\n<td>\r\n<p align=\"left\">负盈利：</p>\r\n</td>\r\n<td>\r\n<p align=\"left\">500-4,999</p>\r\n</td>\r\n<td>\r\n<p align=\"left\">现金礼包赠送比率：</p>\r\n</td>\r\n<td>\r\n<p align=\"left\">6%</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align=\"left\">负盈利：</p>\r\n</td>\r\n<td>\r\n<p align=\"left\">5,000-19,999</p>\r\n</td>\r\n<td>\r\n<p align=\"left\">现金礼包赠送比率：</p>\r\n</td>\r\n<td>\r\n<p align=\"left\">7%</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align=\"left\">负盈利：</p>\r\n</td>\r\n<td>\r\n<p align=\"left\">20,000-59,999</p>\r\n</td>\r\n<td>\r\n<p align=\"left\">现金礼包赠送比率：</p>\r\n</td>\r\n<td>\r\n<p align=\"left\">8%</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align=\"left\">负盈利：</p>\r\n</td>\r\n<td>\r\n<p align=\"left\">60,000-99,999</p>\r\n</td>\r\n<td>\r\n<p align=\"left\">现金礼包赠送比率：</p>\r\n</td>\r\n<td>\r\n<p align=\"left\">9%</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align=\"left\">负盈利：</p>\r\n</td>\r\n<td>\r\n<p align=\"left\">100,000以上</p>\r\n</td>\r\n<td>\r\n<p align=\"left\">现金礼包赠送比率：</p>\r\n</td>\r\n<td>\r\n<p align=\"left\">10%</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h2><strong>活动条款：</strong> <strong> </strong></h2>\r\n<p align=\"left\">1.玩家只有在活动期间内才有资格获得到此回赠礼包。</p>\r\n<p align=\"left\">2.每位玩家、每户、每一住址、每一电子邮箱地址、每一电话号码、相同支付方式(相同支付卡/信用卡号码)、相同提款账号及共享电脑环境(例如学校、公共图书馆及工作办公场所等)每天只能享受一次优惠。</p>\r\n<p align=\"left\">3.此活动可与本网站其它活动同时享受。</p>\r\n<p align=\"left\">4.如发现个人或团体，有以骗取活动奖金为目的的行为, 		本公司将保留取消、收回优惠及产生的红利等，太阳城线上娱乐城的所有决定将是最终决定；</p>\r\n<p align=\"left\">5.本公司可在任何时候终止或修改所有活动规则及内容，最终解释权归本公司所有。</p>\r\n</div>','',-2,0,0,2,'2011-03-19 13:27:45',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-19 13:27:45','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',11,0,12,'','',1,1844,'',0,'*',''),(39,72,'常见问题','faq17','','<div>\r\n<p align=\"left\"><strong>1.</strong> <strong>如何注册太阳城娱乐帐户</strong> <strong>?</strong></p>\r\n<p align=\"left\">我们有两种开户形式：人工开户和网上自助开户。人工开户是指客服为您手工开户，需要提供一些信息，网上自助开户是指 		您自己通过点击我们网站www.818sun.com 		首页的\"我要开户\"按钮一步一步按照系统提示完成操作。</p>\r\n<p align=\"left\"><strong>2.</strong> <strong>怎么为游戏账号充值？</strong> <strong></strong></p>\r\n<p align=\"left\">您可以通过银行柜台或者ATM机转账到我们的指定中国大陆收款银行帐号, 您汇款后直接拨打客服电话:		<strong>国内热线：</strong><strong>13416209808 </strong><strong>菲律宾热线：</strong> 0063 928590 9999或联系在线客服或QQ客服<strong>：</strong><span style=\"text-decoration: underline;\">5539859</span><strong>，</strong><strong> </strong>QQ客服<span style=\"text-decoration: underline;\">：</span><span style=\"text-decoration: underline;\">9509138</span><strong>，</strong>QQ客服<span style=\"text-decoration: underline;\">：</span> <span style=\"text-decoration: underline;\">5767968</span> ，我们在确认您的存款收到后，将在5分钟内为您开通太阳城投注帐号及添加额度，您就可以进入投注了。</p>\r\n<p align=\"left\"><strong>3.</strong> <strong>最低开户金额是多少？</strong> <strong></strong></p>\r\n<p align=\"left\">真钱帐号开户是免费的，开户后存款金额最低人民币100元，100元您可以用来全额投注。每周更有丰富的洗码优惠等您来拿！</p>\r\n<p align=\"left\"><strong>4</strong> <strong>．怎么确认我的存款？</strong> <strong></strong></p>\r\n<p align=\"left\">建议您汇款的时候加一个零头：例如1001, 		1495.5，您汇款后请提供您的存款时间、地点和存款方式，这样我们可以更准确 		的确定付款人。</p>\r\n<p align=\"left\"><strong>5.</strong> <strong>如何申请开户优惠？</strong> <strong></strong></p>\r\n<p align=\"left\">因为享受首存优惠对会员有效投注额有限制，所以网站没有在会员首次存款时在帐号直接添加礼金，客户可以根据自己的盈 		利状况选择是否享受此优惠，如您需要申请，请联系在线客服为您提交，相关部门会2小时内审核，通过后将及时添加到您 		的真钱帐号内。</p>\r\n<p align=\"left\"><strong>6.</strong> <strong>你们都有哪些游戏？</strong> <strong></strong></p>\r\n<p align=\"left\">太阳城娱乐为您提供百家乐，龙虎斗，骰宝，轮盘真人视频网络博彩游戏以及三公，斗牛等扑克游戏。具体游戏规则请查阅 		网站首页的相关链接。</p>\r\n<p align=\"left\"><strong>7</strong> <strong>．提款多久到账？</strong> <strong></strong></p>\r\n<p align=\"left\">太阳城娱乐城承诺客户取款10分钟内准时到帐，如您有提款，请在申请提款 		10分钟后查询您的收款银行帐户是否收到，客服 		和彩金部门是7X24小时在线为您提供取款服务.</p>\r\n<p align=\"left\"><strong>8.</strong> <strong>怎么提款？</strong> <strong></strong></p>\r\n<p align=\"left\">在您盈利需要提款时，请您登录www.818sun.com点击在线客服或者联系QQ客服<strong>：</strong><span style=\"text-decoration: underline;\">5539859</span><strong>，</strong><strong> </strong>QQ客服<span style=\"text-decoration: underline;\">：</span><span style=\"text-decoration: underline;\">9509138</span> <strong>，</strong>QQ客服<span style=\"text-decoration: underline;\">：</span><span style=\"text-decoration: underline;\">5767968</span> ,您也可以拨打我们的电话：		<strong>国内热线：</strong><strong>13416209808 </strong><strong>菲律宾热线：</strong> 0063 928590 9999，提供您的游戏账户， 		取款银行账号，及开户网点，以及本次想要提取的金额我们会在接收到您的提款申请15分钟内为您准时支付您的提款，并在 		支付成功后电话和短信通知您核实查收。</p>\r\n<p align=\"left\"><strong>9.</strong> <strong>投注时意外网络中断怎么办？</strong> <strong></strong></p>\r\n<p align=\"left\">您可以及时记录您下注的游戏局号，网络恢复后，您可点击\"下注记录\"查看结果，没有结果的单子，系统会退回您的本金 		对于结算错误的，我们将会重新结算，有任何疑问会在三天内为您调取视频。</p>\r\n<p align=\"left\"><strong>10.</strong> <strong>还是不太相信你们？</strong> <strong></strong></p>\r\n<p align=\"left\">太阳城在线娱乐城是一家拥有多年博彩经验的境外公司，我们拥有合法的赌场经营牌照。公司成立至今，已经拥有良好的口碑 		以及庞大的客户群。您可以小额投资进行尝试我们的游戏,相信您可以慢慢感受到我们公司的良好信誉，以及优质的服务。</p>\r\n</div>','',1,0,0,2,'2011-03-19 13:27:59',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-19 13:27:59','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',7,0,11,'','',1,1007,'',0,'*',''),(40,61,'联系我们','2011-03-19-13-28-16','','<p>太阳城娱乐场作为国际专业的网上博彩游戏客户端运营企业，我们凭藉集合世界级的博彩资讯专 家丰富经验的服务团队、市场营销专家、先进的软硬件开发人员建立出suncity品牌全面而完善 的组织体系。我们承诺，为每一位客户提供最及新、最安全、最准确的专业博彩数据，以及全方 位的国际化服务。</p>\r\n<p><a href=\"http://chat8.live800.com/live800/chatClient/chatbox.jsp?companyID=89088&amp;configID=116305&amp;jid=4491931779&amp;enterurl=http%3A%2F%2Fchat8%2Elive800%2Ecom%3A8080%2Flive800%2Fpreview%2Ejsp&amp;operatorId=50137&amp;timestamp=1300780283312\' target=\'chat61815096\" onClick=\"javascript:window.open(\' http://chat8.live800.com/live800/chatClient/chatbox.jsp?companyID=89088&amp;configID=116305&amp;jid=4491931779&amp;enterurl=http%3A%2F%2Fchat8%2Elive800%2Ecom%3A8080%2Flive800%2Fpreview%2Ejsp&amp;operatorId=50137&amp;timestamp=1300780283312/&amp;referrer=\'+escape(document.location),\'chat61815096\',\'width=577,height=474,resizable=yes\');return false;\"><img style=\"display: block; margin-left: auto; margin-right: auto;\" src=\"images/chat_now.png\" /></a></p>\r\n<table width=\"575\" border=\"0\" cellpadding=\"10\" class=\"contact-us-table\">\r\n  <tr>\r\n    <td class=\"point\" align=\"right\">在线QQ客服：</td>\r\n    <td><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n      <tr>\r\n        <td>客服一：<a href=\"http://wpa.qq.com/msgrd?v=3&amp;uin=5539859&amp;site=qq&amp;menu=yes\" target=\"_blank\"><img src=\"http://wpa.qq.com/pa?p=2:5539859:41\" alt=\"点击这里给我发消息\" title=\"点击这里给我发消息\" border=\"0\" /></a></td>\r\n        <td>客服二：<a href=\"http://wpa.qq.com/msgrd?v=3&amp;uin=9509138&amp;site=qq&amp;menu=yes\" target=\"_blank\" style=\"font-weight: bold;\"><img src=\"http://wpa.qq.com/pa?p=2:9509138:41\" alt=\"点击这里给我发消息\" title=\"点击这里给我发消息\" border=\"0\" /></a></td>\r\n        <td>客服三：<a href=\"http://wpa.qq.com/msgrd?v=3&amp;uin=5767968&amp;site=qq&amp;menu=yes\" target=\"_blank\" style=\"font-weight: bold;\"><img src=\"http://wpa.qq.com/pa?p=2:5767968:41\" alt=\"点击这里给我发消息\" title=\"点击这里给我发消息\" border=\"0\" /></a></td>\r\n      </tr>\r\n    </table></td>\r\n  </tr>\r\n  <tr>\r\n    <td class=\"point\" align=\"right\">MSN：</td>\r\n    <td><a href=\"mailto:suncitycs888888@gmail.com\" style=\"font-weight: bold;\">suncitycs888888@gmail.com</a></td>\r\n  </tr>\r\n  <tr>\r\n    <td class=\"point\" align=\"right\">电子邮箱：</td>\r\n    <td><a href=\"mailto:suncitycs888888@gmail.com\" style=\"font-weight: bold;\">suncitycs888888@gmail.com</a></td>\r\n  </tr>\r\n</table>\r\n<p><br />\r\n  请致电我们的开户专线国内热线：<span class=\"point\">13416209808</span> 菲律宾热线：<span class=\"point\">0063 928590 9999</span> <br /> <br />\r\n  （7*24小时欢迎您联系咨询，太阳城客服竭诚为您服务）</p>\r\n','',1,0,0,2,'2011-03-19 13:28:10',62,'','2012-05-06 07:55:17',42,0,'0000-00-00 00:00:00','2011-03-19 13:28:10','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":null,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":null,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":null,\"urlctext\":\"\",\"targetc\":\"\"}','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',19,0,10,'','',1,1102,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(41,74,'会员存款','2011-03-20-12-47-27','','<p><img src=\"images/article-pic.jpg\" border=\"0\" /></p>\r\n<p>请详细填写以下表格，带*项目为必填项目</p>\r\n<table class=\"from-table\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">\r\n<tbody>\r\n<tr>\r\n<td width=\"75\" align=\"right\"><label for=\"accunt\">*充值账号</label></td>\r\n<td align=\"left\">px <input id=\"accunt\" class=\"text-filed\" name=\"accunt\" type=\"text\" /> 请正确填写你的账号</td>\r\n</tr>\r\n<tr>\r\n<td align=\"right\"><label for=\"amount\">*充值金额</label></td>\r\n<td align=\"left\"><input id=\"amount\" class=\"text-filed\" name=\"amount\" type=\"text\" /> 网上充值最低金额为100元人民币</td>\r\n</tr>\r\n<tr>\r\n<td align=\"right\"><label for=\"name\">*真实姓名</label></td>\r\n<td align=\"left\"><input id=\"name\" class=\"text-filed\" name=\"name\" type=\"text\" /> 必须与提款时的收款人一致</td>\r\n</tr>\r\n<tr>\r\n<td align=\"right\"><label for=\"telephone\">*手 　 机</label></td>\r\n<td align=\"left\"><input id=\"telephone\" class=\"text-filed\" name=\"telephone\" type=\"text\" /></td>\r\n</tr>\r\n<tr>\r\n<td align=\"right\"><label for=\"email\">E-mail</label></td>\r\n<td align=\"left\"><input id=\"email\" class=\"text-filed\" name=\"email\" type=\"text\" /> 请填写真实Email</td>\r\n</tr>\r\n<tr>\r\n<td align=\"right\"><label for=\"message\">您的备注信息</label></td>\r\n<td align=\"left\"><input id=\"message\" class=\"text-filed\" name=\"message\" type=\"text\" /></td>\r\n</tr>\r\n<tr>\r\n<td align=\"center\" valign=\"middle\">充值说明</td>\r\n<td>\r\n<p>银行系统支付成功后请不要马上关闭窗口，一定要等出现支付成功的页面出现才可关闭窗口。请一定牢记 您在支付时的支付订单号，这是保证您资金交易成功的凭证。您可以凭此订支付单号在支付平台查询您的 支付情况。</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td align=\"center\" valign=\"middle\"></td>\r\n<td align=\"left\"><input id=\"submit\" src=\"images/bt-submit.jpg\" type=\"image\" /></td>\r\n</tr>\r\n</tbody>\r\n</table>','',1,0,0,2,'2011-03-20 12:47:11',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-20 12:47:11','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,0,9,'','',1,43,'',0,'*',''),(42,75,'规则与条款','registration-agreement','','<p>请仔细阅读本条款，並确认你完全理解其內容。如果对于这一条款所产生的权利和义务有任何疑问，请向你所属法律管辖区域內的法律顾问寻求帮助。<br />•    1.定义<br />1.1<br />以下条规适用于用户使用、联接和参与由 SunCity (统称 SunCity 、「我们」及「我们的」，视具体情况而定) 通过http://www.818sun.com经营的网站提供的网上博彩服务。本条规须与特定博彩的博彩规则及适用于博彩软件的使用及与连接进入博彩网站和其中所含条规一併阅读。<br />1.2<br />「博彩」就本条规而言，包括但不限于通过博彩网站提供的任何及/或一切博彩服务进行的投注、游戏及各类博彩活动；<br />「联接设备」指任何应用联接设备，包括但不限于为使用和联接博彩网站、参与博彩服务而采用的个人电脑、笔记本电脑、移动电话、个人数码助理、PDA电话、手提设备。<br />「博彩软件」指经监管机关批准的、安装在用户联接设备上的电脑程序、数据文件或任何其他资讯及信息內容(包括与之有关的任何用户信息)，以便用户通过其使用、联接和参与在博彩网站上提供的博彩服务；<br />•    2.同意<br />2.1<br />用户在注册过程中于「我声明我已年满18岁」及「我同意 SunCity 的规则与条款。」字样之前的方框內打勾，並点击相应的「提交」按钮，即表示用户确认並同意：<br />i.    用户已经阅读、完全理解並同意本条规；<br />ii.    本条规构成用户与 SunCity 之间关于博彩服务使用的具有法律约束力的协议 (「使用协议」) 。<br />2.2<br />如果用户不同意本条规中的任何条款，请不要勾选「我同意 SunCity 的规则与条款。」及不要点击「提交」按钮，不要试图使用或继续使用任何博彩服务或下载和/或安装博彩软件。<br /> 3.修改<br />3.1<br />SunCity 保留不时修订、更新和修改本条规和博彩规则 (或其任何部分) 的絕对权利。上述任何修订、更新或修改将在博彩网站上公布。经修订、更新或修改的本条规和博彩规则于其在博彩网站上公布时生效。用户在之后继续通过博彩网站和博彩设备使用、联接和参与博彩服务，将视为同意並接受所公布的经修改或更新的本条规和博彩规则。<br />3.2<br />用户确认並同意自行负责查阅上述修订、更新和/或修改。 SunCity 可自主决定将上述修订、更新和修改通知用户。上述修订、更新和修改可由 SunCity 自主决定不时通知用户，但 SunCity 並无任何义务向用户通知任何更新和修改。<br /> 4.博彩资讯和知识产权<br />4.1<br />通过博彩网站、博彩服务、博彩设备和/或任何其他方式提供向用户公开、获取、产生和/或收集的信息、资料和数据，包括但不限于营销计划和资料、成绩、统计数据、赛事数据、赛程表、概率和投注数据、文字、图标、音像资讯 (「博彩资讯」) ，将属于 SunCity 和其许可人所有，仅供用户用于个人非商业性目的。<br />4.2<br />除在本条规外，未经我们或第三方资料专有人的事先书面同意，用户不得以任何方式或手段改编、拷贝、修改、复制、储存、散发、展示、公开播放、制入有线节目、出版、传送、出售、出借、出租、许可使用博彩资讯。用户也不得以其他方式使用任何他人或其他网站、网上服务、公告板、任何媒体和/或联接设备可以获得、使用、或连接上述博彩资讯。<br />4.3<br />在博彩网站和/或通过联接设备提供的博彩软件、博彩服务和博彩资讯享受着作权、商标和其他形式的知识产权和专利保护。博彩网站上的博彩软件、博彩服务和博彩资讯的所有权利、产权和利益均属 SunCity 和其许可人所有、使用或控制。用户确认並未通过使用或联接在博彩网站和/或联接设备提供的博彩软件、博彩服务和博彩资讯取得 SunCity 的博彩软件、博彩服务和博彩资讯的任何权利、利益或许可。<br /> 5.使用条件<br />作为使用博彩服务的条件，用户保证並承诺不得以任何违反适用于用户的任何法律、违反本条规和/或被本条规所禁止的目的使用或联接博彩网站、博彩服务软件、博彩软件服务和博彩资讯。除了本条规中所列一切其他声明和保证之外，用户在此进一步保证並承诺，作为使用博彩服务的条件：<br /> .    用户以本人的身份及名义进行活动，而非代他人进行交易；<br />i.    用户的法律行为能力不受限制；<br />ii.    用户未被诊断或认定为赌博强迫症；<br />iii.    用户年龄(a)至少已满18周岁；或(b)已满任何适用于用户的法律所规定的其他法定年龄或成人年龄，以较大者为准(「法定年龄」)；<br />iv.    用户充分瞭解在使用博彩服务的过程中亏损资金的风险；<br />v.    用户存入的款项並非来源于犯罪或其他非法、未经授权或许可的活动；<br />vi.    用户並非从事犯罪或其他非法、未经授权或许可活动和/或企图利用用户在 SunCity 开立的账户从事上述活动；用户不得利用或允许他人利用博彩服务或用户的博彩账户从事适用于用户或我们的任何法律所规定的任何犯罪或其他非法活动，包括但不限于洗钱；<br />vii.    对用户的户名、账号和密码予以保密，防止非法联接或使用，在户名、账号或密码以任何方式失密的情况下立即更改密码或通知我们；<br />viii.    对以用户的户名、账号和密码通过博彩网站和/或联接设备联接和使用博彩服务的任何及所有活动自行承担责任，不论上述联接和/或使用是否经用户授权或为用户所知晓；<br />ix.    不以任何干扰或可能干扰其他用户使用博彩服务和博彩网站的方式使用博 彩服务、博彩网站、联接设备、博彩软件和博彩资讯，不实施任何降低或可能降低博彩服务和博彩网站运行效能的行为；<br />x.    不徵集或以任何方式企图获取有关其他用户的任何资料；<br />xi.    不上传或散发任何含有病毒、已经毁坏或可能影响联接设备、博彩软件、博彩服务和/或博彩网站运行效能的程序、文件或数据；<br />xii.    用户通过博彩网站和/或联接设备联接或使用博彩服务和博彩资讯不违反适用于用户的法律；亦不违反对用户个人或用户目前联接博彩网站或使用联接设备所在国家所有人具有约束力的合约义务；同时不受上述法律或合约义务禁止；<br />xiii.    不使用任何设备、机械、装置、软件、程序或其他方法 (或任何具有上述性质的事物) 干扰或企图干扰博彩服务、联接设备、博彩软件、博彩网站、博彩资讯或博彩网站和/或联接设备提供的任何交易的正常运行；<br />xiv.    不向博彩网站和/或联接设备或任何其他用户发布或传送任何违法、骚扰性、侮辱性、威胁性、诬衊性、誹谤性、淫秽、猥褻、煽动性、种族歧视、色情或粗俗的內容，或可构成或教唆犯罪、引发民事责任或以其他方式违反任何法律的內容；<br />xv.    用户不是 SunCity 或其任何关联公司的管理人员、董事、雇员、顾问、关联人或代理人，或与上述任何人员具有亲属或同屋居住关係；<br />xvi.    不干扰其他用户使用博彩服务、博彩网站、博彩软件、联接设备和/或博彩资讯或发起和/或参与调查、竞赛、连锁信或发布/传送「垃圾邮件」或其他未受请求的群发邮件。<br /> 6.注册开立博彩账户和会员资格<br />6.1<br />欲通过 SunCity 参与博彩、使用博彩服务，用户须按博彩网站所述程序完成开立账户和会员资格的申请 (「会员资格申请」) 。<br />6.2<br />用户声明並承诺，用户在注册和办理会员资格申请时所提供的所有资料，包括会员资格申请所填用户姓名 (「姓名」) 、资金来源 (包括有关银行账号和卡号) 和住址，在一切方面均真实、准确、完整。<br />6.3<br />SunCity 将采取必要和适当的措施对用户向我们披露的个人资料予以保密。我们将对所收到的用户个人数据和投注资料予以严格保密，除非法律、法规、规章、法院、监管机关、任何有关博彩管理、执法机关的命令和决定或本条规要求披露。用户对其个人资料的保密自行承担责任。我们保留在完成博彩网站所提供的博彩服务的付款手续所需的范围內向我们支付结算服务提供者和金融机构披露用户个人数据的权利。<br />6.4<br />用户还须自行负责确保用户使用和联接博彩网站和其中所含的博彩资讯、下载安装博彩软件和/或使用和参与博彩服务不受适用于用户的法律禁止。<br />6.5<br />为验证用户的会员资格申请，我们仍需要用户提供身份和年龄证明 (如带照片的有效身份证明和借记卡或信用卡) 。用户提供的具体原始资料如有任何变更，应及时通知我们。为确认用户的姓名和地址， SunCity 保留通过邮寄等方式确认用户姓名和地址的权利。 SunCity 可自行决定采用其他安全措施核实用户提供的任何资料。用户同意本条规，即同时表示同意 SunCity 联接、使用、处理和储存对用户的任何身份验证或核实结果。<br />6.6<br />我们保留基于任何理由拒絕用户会员资格申请的絕对权利。<br /> .    我们仅对在线即时帮助所公布的 SunCity 官方备用网站负责。会员登录其它任意貌似 SunCity 网站的链接，所造成的任何损失我们将不承担任何责任。 如有其他疑问，请直接联络我们的在线客服<br />i.    若为曾违反本网站或我们之合作软件商/网站的条款及规则的玩家，其注册将不被接纳。如发现任何此类型之帐户，其将会被封闭及扣除所有赢款及余额。<br />6.7<br />用户在 SunCity 仅可开立一个账户。若我们发现用户在 SunCity 开设不止一个账户，我们保留自行决定将用户在 SunCity 的所有账户作为一个合併账户处理、取消多余账户或与用户终止本协议的权利。<br /> 7.下注及接受下注<br />7.1<br />我们于博彩网站上和/或通过联接设备所不时提供的游戏、体育赛事和其他博彩活动开放给用户下注。用户下注须遵守具体游戏或博彩活动的博彩规则以及本条规的规定。若任何赌局出现明显错误或显示错误的参赌人，该赌局的所有下注均告作废。 SunCity 博彩系统发生故障时， SunCity 亦有权宣布任何或所有下注无效。<br />7.2<br />儘管本条规可能存在其他规定，但 SunCity 有权基于任何理由酌情拒絕用户的全部或部分下注。<br />7.3<br />我们仅接受用户按本条规通过互联网和/或联接设备进行下注。其他下注形式(邮寄、电邮、传真等)一概不予接受。我们即使收到其他形式的下注，不论赌盘最后开出的结果如何，均视为无效。<br /> .    SunCity 有权搁置或拒絕疑用欺骗手段如通过攻击、操纵等破坏操作系统所进行的投注。<br />i.    任何不寻常的投注将被取消，而不需另行通知。特此声明，人工智能或软件（机器人“bots”）于线上投注服务的使用是被严禁的行为，而任何试图或利用该方式的投注将被取消，相关帐号立即会被关闭。<br />7.4<br />受限于本条规其他规定，用户输入正确的用户名和密码且账户內存有足够余额，用户即有效投下注码。<br />7.5<br />用户均须对使用下列內容（或其各项结合）所进行的所有活动和交易负责（无论下述使用是否得到授权）：<br />ii.    用户姓名；和/或<br />iii.    用户账户号；和/或<br />iv.    用户的用户名和密码。<br />7.6<br />用户自行负责确保其下注细节的准确性。受限于本条规其他规定，一旦用户下注且我们确认接受用户的下注，即为用户下注的最终确证；用户不得取消、撤回下注或更改下注细节。<br />7.7<br />所有下注均收录于交易记录数据库。 SunCity 的交易记录为所有交易及下注的相关信息的最终确证。<br />7.8<br />受限于本条规其他规定，当交易代号出现在用户屏幕上並有效显示在用户的交易历史中时，下注即视为有效及被 SunCity 接受。<br />7.9<br />比赛开始后和/或下注时比赛结果已被知晓之情况下不得下注。若比赛开始和/或用户下注时已经知晓比赛结果之情况下仍错误地开放给用户下注， SunCity 有权不经通知用户即可拒絕用户下注或宣布下注无效； SunCity 享有是否接受全部或部分该等下注的自主决定权。为避免疑义，本条款不排除「下半场」投注盘(“in play” bets)或「半场」投注盘 (“half time” bets)。<br />7.10<br />博彩网站上预告的开赛时间仅为信息参考之用。若 SunCity 因任何原因无意中于比赛开始后仍接受下注，则 SunCity 有权取消和宣布该等下注无效。<br />7.11<br />除非有关比赛和游戏的具体规则另有规定，否则为了博彩的目的，开放下注的比赛或游戏的结果将于比赛或游戏实际结束当天决定。 SunCity 不承认任何后来的可能导致推翻上述结果的质询，原派彩仍然有效。<br />7.12<br />体育赛事的比赛地点发生变化的，以原赛场为基础的所有下注均告无效。<br />7.13<br />比赛或游戏的贏家将根据博彩规则在上述比赛或游戏实际结束当天予以定。<br />7.14<br />为博彩目的， SunCity 不承认任何延期比赛、抗议或推翻的结果。<br />7.15<br />用户下注的多重彩中如包括非参赛者选项或无效选项，派彩将以剩余的有效选项为基础进行结算。<br />7.16<br />用户承认所有赔率、指数和让分可不经通知上下浮动，上述赔率、指数和让分仅在用户下注被我们接受时予以确定。<br />7.17<br />若明显错误或系统故障造成用户下注的赔率、指数或让分不正确时，则用户的下注或多重彩的部分下注无效。若有关错误或故障及时得到纠正， SunCity 有权自主(但无义务)决定尽合理努力和用户联络允许用户以正确的赔率、指数和让分重新下注。<br />7.18<br />我们不接受用户同时对同一赛事重复下注。<br />7.19<br />就任何下注及其相关交易而言， SunCity 享有最后决定权，且其所作决定系终局性並具有最终确定力的。<br /> 8.博彩软件使用权<br />8.1<br />用户特此确认並同意，用户通过联接设备以下载或其他方式获得的以便其远程使用的博彩网站的博彩软件属于博彩服务的一部分，为 SunCity 和其许可人的财产；用户对该等博彩软件不享有任何权利。用户不得以任何方式或以任何手段改编、拷贝、修改、复制、储存、散发、展示、公开播放、传播、广播、制入有线节目、出版、传送、出售、出借、出租或许可使用博彩软件。用户不得以其他方式交流或使博彩软件对任何他人或网站、网上服务或公告板或任何其他媒体和/或联接设备开放。<br />8.2<br />SunCity 特此授予用户在联连设备上安装和使用博彩软件的非专属性、不可转让的个人使用权 (「使用权」) ，但博彩软件的安装和使用所用的联接设备须以用户为主要使用人。<br />8.3<br />SunCity 授权和散发博彩软件的目的仅为博彩软件的终端用户能完全连接和使用博彩服务。<br />8.4<br />用户不得：<br /> .    安装或传载博彩软件至其他连网设备的服务器或采取其他步骤使博彩软件可以通过任何形式或公告板、网上服务或远程拨号或网络使他人得到；<br />i.    散发、出借、出租、转授权、拷贝、转让、转移或以其他方式使任何其他人得到博彩软件和/或使用博彩软件的使用权；<br />ii.    允许其他人使用博彩软件；<br />iii.    设立或提供任何方式 (包括但不限于仿真程序)使他人使用博彩软件；<br />iv.    翻译、反向工程、反向编译，反彙编、修改、破解、全部或部分地以博彩软件和/或其源代码为基础开发衍生产品；或<br />v.    拷贝、修改、翻译或全部或部分地以博彩软件的相关用户文件为基础开发衍生产品。<br />8.5<br />用户承认並同意，博彩网站上提供的及或通过联连设备或其他方式提供的博彩软件或博彩软件用户方件均归 SunCity 和其许可人所有，並受着作权、商标权和其他知识产权和专利权的保护。用户特此承认，博彩软件的结构、组织和源代码为 SunCity 和其许可人的极具价值的商业秘密。用户承认除根据使用权向用户授予的权利外，用户对博彩软件和/或博彩软件用户文件不享有任何权利和权益。<br />8.6<br />本协议因任何原因终止，本协议顶下所授予的使用权自动作废，用户应停止使用博彩软件並将博彩软件从联连设备中卸载。<br /> 9.交易结算<br />9.1<br />用户使用信用卡或借记卡的，持卡人姓名须与会员登记和申请过程中所使用的姓名一致。若发生持卡人姓名和账户登记和会员申请所使用的姓名不一致的情况， SunCity 有权拒絕就相关交易进行结算。<br />9.2<br />用户承担向 SunCity 和其他用户（视具体情况而定）支付所有应付款项的一切责任。用户同意对任何付款不实施或促使他人实施退款，不拒絕或撤销付款，並向 SunCity 偿付所有被退还、拒絕或撤销的付款以及由此引起的所有损失和费用。 SunCity ，根据自主判断，有权终止向个別用户或使用某类信用卡或借记卡付款的用户提供服务或支付款项。<br />9.3<br />任何经 SunCity 认可的有效：<br /> .    体育博彩(Sportsbook)下注的最高彩金将根据不同盘口而定。<br />i.    真人娱乐场 (Live Casino) 下注的最高彩金将根据不同游戏而定 (或根据当日所公布的汇率不时确定的其他等额货币。)<br />9.4<br />彩金不包括下注额。<br />9.5<br />任何款项或彩金在存入帐户的过程中发生错误， SunCity 不负任何形式的任何责任，且 SunCity 有权在任何时候或在事后宣布涉及该等款项的交易无效。用户一旦发现账户內款项汇存有误，有责任立即通知 SunCity 。<br />9.6<br />在任何适用法律下就彩金所应缴付的税款和费用均由用户自行负责缴付。<br /> 10.领取彩金<br />10.1<br />用户的彩金经结算后，将存入用户账户，具体提取办法参照我们彩金提取规定並须出示我们认可的有效带照身份证和/或信用/借记卡。<br />10.2<br />根据监管政策的要求及运营的需要，我们在处理您的提款前，您将可能需要提供相关证件信息给KYC【客户身份识别】部门进行身份验证。一旦需要，KYC部门将会主动通过邮件的方式向您提出申请，验证完成后将不需要再次提供。<br />10.3<br />在用户所持的信用/借记卡发行银行允许的情况下，彩金可以直接存入用户交纳押金所用的信用/借记卡账户。支票或电汇的收款人以登记或申请会员时所用的姓名为准。以信用卡或借记卡支付押金的，收款人还必须是信用卡或借记卡的登记持卡人。<br />10.4<br />投注额必须与存款额相同才能进行提款， SunCity 将保留权利，收取必要的提款和存款手续费。<br />10.5<br />SunCity 因用户的博彩交易而蒙受的所有银行收费均由用户承担和偿付， SunCity 有权从用户彩金或账户中扣除和抵扣上述收费。<br /> 11.促销和奖励<br />11.1<br />所有促销、奖励和特价均须遵守本条规及 SunCity 针对具体促销活动所不时制定的规定。 SunCity 保留在任何时候中止、取消或修改该等奖励或促销和/或其相关规定及条款的权力。<br />11.2<br />若 SunCity 认定有人滥用或企图滥用某项奖励或促销活动，或可能因该等滥用行为而获利，我们有权自主决定以其认为合适的方式阻止、拒絕，中止、或撤消任何用户参加有关奖励或促销活动.<br />11.3<br />如发现任意带有串通勾结以及试图欺诈等嫌疑的个人或团队，我们将保留取消其部份或全部投注的权利。所涉及的个人，亲属，组织，博彩庄家及其员工帐户中的金额会将被立即查封没收。<br />11.4<br />作为服务性娱乐网站，SunCity 所公布的服务和优惠活动仅适用于真实玩家，而针对非真实玩家我们的服务与优惠活动将酌情进行调整。<br />真实的玩家是指真正参与游戏进行有风险的投注，以游戏结果为赢利目的的玩家。<br /> 12.赔偿<br />12.1<br />用户同意，由于用户连接博彩网站、下载或安装博彩软件、下注和/或以其他方式使用博彩服务、博彩软件和/或博彩资讯、及/或违背本条规和/或博彩规则，而对 SunCity 、其股东、雇员、管理人员、董事、受许可方、经销商、关联方、子公司和或代理商造成的任何损失、损害或及索赔 (包括合理的律师费) ，用户须予以全额赔偿。<br /> 13.免责声明及特別注意事项<br />13.1<br />博彩完全是一项个人选择，以个人判断与分析为依据，且风险自负的行为。用户下注的同时，即表明用户承认博彩服务、博彩网站和博彩资讯並无冒犯性，且並不令人反感、不公平或有悖公共道德。一些司法管辖区对网上及/或岸外网上博彩的合法性尚无定论；而另一些司法管辖区则明确规定网上博彩（在司法管辖区域內和/或岸外）均属非法行为。我们不鼓励任何人在非法的情况下使用和连接博彩网站、博彩资讯和/或博彩服务。博彩服务、博彩资讯和博彩网站的设立和提供並不构成我们发出要约、招揽或邀请任何人在那些规定使用或连接上述內容为非法行为的国家內使用或连接上述內容。用户独立承担遵守其所适用之相关法律规定的责任，而 SunCity 不就博彩服务、博彩软件、博彩网站或其中的博彩资讯与用户所适用的法律规定相符作出任何声明。<br />13.2<br />博彩服务、博彩软件、博彩网站和博彩资讯均按「原状原则」提供。除本条规明示的外， SunCity 不就博彩服务、博彩网站、博彩软件和博彩资讯作出任何声明或保证。故所有有关博彩服务、博彩软件、博彩网站和博彩资讯的声明或保证，不论明示或暗示、法定与否，特此在法律允许的最大范围內予以排除。 SunCity 不就博彩服务、博彩软件、博彩网站或博彩资讯的准确性、及时性、安全性、连续性、正确性或抗外界干扰性（任何性质），以及更正所发现的任何缺陷作出保证。 SunCity 亦不保证博彩服务、博彩软件、博彩网站和博彩资讯或提供上述內容的服务器不含有任何病毒、间谍软件、广告软件或其他具恶意性、破坏性或可导致电脑瘫痪的代码、程序、数据、宏指令或可影响任何联接设备和/或其中所存数据的其他软件或特性。用户承诺将自行自费采取预防措施，确保其使用或连接博彩服务所用的过程、方法和/或联接设备、以及博彩软件的安装和博彩网站的使用，均不会带来电脑病毒、间谍软件、广告软件或具恶意性、破坏性或可导致电脑瘫痪的其他代码，或导致其联接设备或其中所存数据受到干扰和破坏的其他风险。<br />13.3<br />若发生与账户结算或博彩服务的其他方面有关的系统错误或通讯错误， SunCity 不承担由此引起的任何责任。在此情况下， SunCity 有权取消所有受上述错误影响的下注並采取任何更正行动。<br />13.4<br />在任何情况下，因用户连接、使用或参与博彩服务、博彩网站、博彩软件和博彩资讯而发生任何损害、损失或支出，包括用户之联接设备或所存数据受到任何干扰或破坏， SunCity 不承担任何责任。此外，对博彩服务、博彩网站、博彩软件和博彩资讯中由第三方(包括但不限于宽带和电信服务供应商)所提供的內容， SunCity 亦不作任何保证和声明且不予负责；在任何情况下， SunCity 均不对上述第三方合作者的任何违约、过错或不作为承担责任。<br />13.5<br />在任何情况下， SunCity 、其关联公司、关联方、合伙人、管理人员、雇员和代理均不对任何损害、损失或支出承担责任。上述包括但不限于因用户连接或使用博彩服务、博彩网站、博彩软件和博彩资讯、或与用户连接或使用博彩服务、博彩网站、博彩软件和博彩资讯有关的、或因用户下载、安装或使用博彩软件所引起的任何直接、间接、因果性或特別的损害或经济损失，不论 SunCity 是否被告知可能发生上述损害、损失或支出。在任何情况下，就与用户下注直接相关的任何事宜、事件或情形所引起或与之相关的任何损失或损害(不论是否基于合约、侵权、严格责任或其他原因)，在法律允许的最大范围內， SunCity 对用户的全部责任(如有)应不超过用户的相应下注额。<br />13.6<br />用户承认，博彩资讯在性质上可能全部或部分地具有临时性，並且可按本条规予以修订、修改或更改。因此，用户承认博彩资讯仅为参考之用，不构成任何建议、意见或招揽，不构成任何具约束力的声明、保证、合约义务或用户依据的內容和基础。<br />13.7<br />用户特此承认並同意，在考虑所有相关因素，包括但不限于用户向 SunCity 提供对价的价值后，本条规所述之所有责任豁免和义务排除代表用户和 SunCity 协议中公平、合理的风险分担和利益分配。用户进一步同意上述免责和限制在适用法律允许的最大范围內具有强制执行力。<br />13.8<br />如果用户对任何博彩或比赛的结果存有异议，应在该等结果宣布之日后十四(14)天內向我们书面投诉。若出现用户联接设备所显示与 SunCity 系统的交易记录中所存的交易结果不符的情况(儘管发生这种情况的可能性很小)，用户同意 SunCity 系统中交易记录所记载的由我们的技术总监认证的交易结果应为该等结果具终局性的不容置疑的证据。<br /> 14.终止、关户及暂停博彩服务<br />14.1<br />如有充分理由相信或证明以下情形，除本条款项下所享有的其他权利外， SunCity 有权，根据自主判断，宣布任何彩金无效並没收用户下注账户中所存余额、终止本协议和/或暂停提供博彩服务/冻结用户账户：<br /> .    用户在 SunCity 拥有不止一个活动账户；<br />i.    用户姓名与向 SunCity 进行购卖或支付押金所用的信用卡或借记卡或其他付款账户的持有人姓名不符；<br />ii.    用户参与 SunCity 促销並在未满足促销要求之前退出该促销；<br />iii.    用户提供不正确或误导性的注册信息；<br />iv.    用户未提供或遗漏提供必要的身份资料；<br />v.    用户不满法定年龄；<br />vi.    用户连接和使用博彩服务所在的地区在法律上禁止使用博彩服务；<br />vii.    用户对我们实施或促使他人对我们实施「退款「，或否认以其账户名义进行的任何交易或押金；<br />viii.    用户押金来源于刑事犯罪或其他非法或未经授权的活动；<br />ix.    用户被发现欺诈或企图欺诈任何人或已经对任何人实施欺诈，或经 SunCity 认定用户使用专门设计用以干扰/捣毁系统之人工智能或其他系统(包括机械、电脑、软件或其他自动化系统)，或被发现与其他博彩玩客勾结或企图与其他赌客勾结欺骗 SunCity 或其他博彩玩客；<br />x.    用户允许(不论是否故意)他人使用其账户；<br />xi.    用户未遵守本协议项下的任何使用规定；<br />xii.    用户未披露其位置在菲律宾、台湾、美国、新加坡及香港境內的事实。<br />14.2<br />若我们按第14.1条规定暂停提供博彩服务和/或冻结账户，在用户实施必要的纠正措施 (如果可以纠正)，且我们确认完全满意用户的纠正措施之后，博彩服务和用户账户将被恢复和解冻。<br /> 15.与外部网站的链接<br />15.1<br />博彩网站可能含有与並非 SunCity 维护的外部网站的链接。与外部网站的链接仅为用户方便而提供， SunCity 不承诺确保上述链接所含內容的准确性、时效性或被维护，且不就此承担任何责任。<br />15.2<br />SunCity 不就外部网站的內容资讯或隐私保护政策或在外部网站宣传、出售或以其他方式开放的任何产品或服务承担任何责任、负责提供或审查、予以批准或核准、或作出任何声明或保证。<br />15.3<br />SunCity 不就用户因使用博彩网站所提供的任何外部网站链接而发生的或与之相关的任何损失或损害承担合约、侵权、疏忽或其他责任。<br />15.4<br />除非明文规定，否则 SunCity 在任何情况下均不得被视为与外部网站上的任何声明、意见、产品或服务商标、标记、标志或其他图案、在外部网站宣传、出售或以其他方式开放的任何产品或服务、外部网站的经营者或所有者、或以任何方式与外部网站相关的任何人具有任何关係或联系。<br /> 16.与博彩网站的链接/框入<br />16.1<br />用户不得就博彩网站或博彩服务的任何部分设置链接、深链接或文中链接(deep or in-line links)、或框入(frame)博彩资讯。<br /> 17.增加或中断博彩种类<br />17.1<br />我们保留自行决定，不经通知用户，于任何时候在博彩网站增加新的博彩种类或功能，或开始、停止、中断、限制联接或修改任何博彩种类或功能的权利，且不就此对任何人承担任何责任。<br /> 18.违反本条规<br />18.1<br />SunCity 保留就违反本条规的行为依法寻求救济（法律及衡平法）的权 利，包括自行决定在任何时候基于任何理由拒絕或限制任何特定的人联接博 彩服务、博彩网站和博彩资讯、阻止通过特定互联网地址或联接设备联接博彩服务、博彩网站和博彩资讯的权利。<br /> 19.优先顺序<br />19.1<br />博彩规则 (若适用) 和适用于使用和联接博彩服务、博彩软件、博彩资讯和博彩网站的任何其他条规均构成本条规的组成部分。<br />19.2<br />若博彩规则和适用于使用和联接博彩服务、博彩软件、博彩资讯和博彩网站的任何其他条规与本条规存有抵触，则除非另行明文规定，否则以本条规为准。<br /> 20.不可抗力<br />20.1<br />若 SunCity 由于发生下列其无法控制的任何性质的事件 (包括但不限于天灾、适用法律法规的变更、政府、民政或军事机关的作为或不作为、法院命令、恐怖活动、闪电或火灾、罢工、停工或其他劳资纠纷、洪水、干旱、战争、暴乱、盗窃、传输或系统故障、通讯或宽带服务故障或中断、电力供应或设备故障或不足、恶劣气候、地震和自然灾害)未能或迟延履行本条规所规定的任何义务，不构成违反本条规。用户同意采取一切必要行动儘量减轻上述事件的后果。<br /> 21.弃权<br />21.1<br />SunCity 在任何时候未能执行本条规任何条款不可视为放弃本条规所规定的权利或以任何方式影响本条规全部或部分的有效性，且不影响 SunCity 采取进一步行动的权利。<br /> 22.可分割性<br />22.1<br />若任何条款或其任何部分被有关机关认定为在任何程度上无效、不合法或不可执行，则该条款或该部分在上述程度上与其他条款分割，其他条款在法律允许的范围內继续完全有效。<br /> 23.适用法律和管辖<br />23.1<br />用户同意，用户联接和使用博彩服务、博彩网站、博彩软件、博彩资讯及有关本条规的解释适用菲律宾法律，並按菲律宾法律解释。<br />23.2<br />因本条规发生或与本条规有关的任何争议：<br /> .    若由用户提起，则提交菲律宾 First Cagayan公司卡卡湾经济区管理局 (Cagayan Economic Zone Authority, First Cagayan Leisure and Resort Corporation) 互动游戏主许可人最终解决。<br />i.    若由 SunCity 提起，则由 SunCity 自行选择：<br />a.根据以上第23.2(i) 条的规定提请仲裁最终解决。<br />b.向用户同意的菲律宾法院提起诉讼或申请，但 SunCity 在其他法律管辖区提起诉讼或法律程序的权利不受影响。</p>','',1,0,0,2,'2011-03-21 02:07:18',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-03-21 02:07:18','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',2,0,8,'','',1,105,'',0,'*',''),(43,52,'百家乐','2011-03-21-15-46-33','','<p>长期以来，百家乐是亚洲、欧洲和拉丁美洲最受欢迎的游戏之一，看似复杂，但事实上，百家乐可能是赌场内最简单的游戏。</p>\r\n<h2>游戏玩法</h2>\r\n<p>发牌员会派出﹝庄家﹞和﹝闲家﹞两份牌，总数得9点或最接近9点的一家胜出 你有七种下注选择：◎闲家◎庄家◎和局◎庄对子◎闲对子◎大◎小</p>\r\n<h2>牌面点数</h2>\r\n<p>所有从2到9的牌，其数值就是他们显示的点数：</p>\r\n<p>A当作是1点，K、Q、J、10是0点，而加起来等于10的也当作是0点。当任何一家头两张牌的点数总和为8或9，就称为﹝天生赢家﹞。</p>\r\n<p>任何一家拿到﹝天生赢家﹞，牌局就算结束，不再补牌。</p>\r\n<p>派出两张牌后，如果需要补牌，将依照补牌规则多发一张牌。</p>\r\n<h2>大小</h2>\r\n<p>指根据当局所开之牌张数的总和为依据，4张牌为小，5张牌或6张牌为大，即增牌为大，不增牌为小。</p>\r\n<h2>派彩</h2>\r\n<ul>\r\n<li>下注闲家赢，1赔1 </li>\r\n<li>下注庄家赢，1赔1，但扣除5%佣金 </li>\r\n<li>下注和局赢，1赔8 </li>\r\n<li>下注庄对子赢，1赔11 </li>\r\n<li>下注闲对子赢，1赔11 </li>\r\n<li>下注大，1赔0.5 </li>\r\n<li>下注小，1赔1.5 </li>\r\n</ul>\r\n<h2>补牌规则</h2>\r\n<table class=\"table_rule\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">\r\n<tbody>\r\n<tr>\r\n<th>闲家头两张牌 合 计 点 数 </th> <th>闲家</th> <th>庄家头两张牌 合 计 点 数</th> <th>庄 家 </th>\r\n</tr>\r\n<tr>\r\n<td>0</td>\r\n<td>必须补牌</td>\r\n<td>0</td>\r\n<td>必须补牌</td>\r\n</tr>\r\n<tr>\r\n<td>1</td>\r\n<td>必须补牌</td>\r\n<td>1</td>\r\n<td>必须补牌</td>\r\n</tr>\r\n<tr>\r\n<td>2</td>\r\n<td>必须补牌</td>\r\n<td>2</td>\r\n<td>必须补牌</td>\r\n</tr>\r\n<tr>\r\n<td>3</td>\r\n<td>必须补牌</td>\r\n<td>3</td>\r\n<td>若闲家补得8，不得补牌</td>\r\n</tr>\r\n<tr>\r\n<td>4</td>\r\n<td>必须补牌</td>\r\n<td>4</td>\r\n<td>若闲家补得0,1,8,9，不得补牌</td>\r\n</tr>\r\n<tr>\r\n<td>5</td>\r\n<td>必须补牌</td>\r\n<td>5</td>\r\n<td>若闲家补得0,1,2,3,8,9，不得补牌</td>\r\n</tr>\r\n<tr>\r\n<td>6</td>\r\n<td>不得补牌</td>\r\n<td>6</td>\r\n<td>若闲家补得6,7，必须补牌</td>\r\n</tr>\r\n<tr>\r\n<td>7</td>\r\n<td>不得补牌</td>\r\n<td>7</td>\r\n<td>不得补牌</td>\r\n</tr>\r\n<tr>\r\n<td>8</td>\r\n<td>例牌，即定输赢</td>\r\n<td>8</td>\r\n<td>例牌，即定输赢</td>\r\n</tr>\r\n<tr>\r\n<td>9</td>\r\n<td>例牌，即定输赢</td>\r\n<td>9</td>\r\n<td>例牌，即定输赢</td>\r\n</tr>\r\n</tbody>\r\n</table>','',1,0,0,12,'2011-03-21 15:42:06',62,'','2012-05-01 10:09:22',42,0,'0000-00-00 00:00:00','2011-03-21 15:42:06','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',2,0,16,'','',1,650,'',0,'*',''),(44,54,'骰宝玩法','2011-03-21-15-51-51','','<p>骰宝也叫赌大小，是中国古老相传的游戏。这个游戏的用具是个密封的骰盅，由各玩家选择筹码下注，猜测经机械摇动后骰子开出的点数或是点数总合。</p>\r\n<h2>游戏玩法</h2>\r\n<ul>\r\n<li>开始新局后即开始下注倒数计时，您可以依照您的猜测，选择筹码下注       。 </li>\r\n<li>倒数时间结束后停止下注，再由荷官按钮经机械自动摇骰。 </li>\r\n<li>待骰盅停止后，视三颗骰子停留开出的点数，由荷官输入三点数，同时画面亮起灯光，可清楚看到胜出注码和赔率；是否与玩家押注的内容相同，来判定输赢。 </li>\r\n<li>若骰子靠在骰盎边缘上而造成有斜骰或迭骰情形发生，无法判断点数时，荷官得重骰一次，采用第二次骰出之结果。 </li>\r\n</ul>\r\n<h2>投注种类</h2>\r\n<p>筹码是放在划有不同赌法的方格的赌桌上，您可以下注在任何的方格，但要在下注时限之内</p>\r\n<h2>派彩</h2>\r\n<table class=\"table_rule\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">\r\n<tbody>\r\n<tr>\r\n<td>下注</td>\r\n<td>说明</td>\r\n<td>赔率</td>\r\n</tr>\r\n<tr>\r\n<td>大 / 小</td>\r\n<td>大 : 总点数 11 至 17 <br /> 小 : 总点数为 4 至 10 ( 遇围骰庄家通吃 )</td>\r\n<td>1 赔 1</td>\r\n</tr>\r\n<tr>\r\n<td>围骰</td>\r\n<td>投注指定的围骰 ( 如 1 围骰 ) ，一定开出 3 颗所投注的骰子</td>\r\n<td>1 赔 150</td>\r\n</tr>\r\n<tr>\r\n<td>全围</td>\r\n<td>3 颗骰子都一样</td>\r\n<td>1 赔 24</td>\r\n</tr>\r\n<tr>\r\n<td colspan=\"3\">\r\n<p>下注在单一个点数 ( 三军 )</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>出现单骰</td>\r\n<td>投注每颗骰子 1 至 6 中指定的点数，点数出现 1 次</td>\r\n<td>1 赔 1</td>\r\n</tr>\r\n<tr>\r\n<td>出现双骰</td>\r\n<td>投注每颗骰子 1 至 6 中指定的点数，点数出现 2 次</td>\r\n<td>1 赔 2</td>\r\n</tr>\r\n<tr>\r\n<td>出现全骰</td>\r\n<td>投注每颗骰子 1 至 6 中指定的点数，点数出现 3 次</td>\r\n<td>1 赔    3</td>\r\n</tr>\r\n<tr>\r\n<td>对子 ( 双骰、长牌 )</td>\r\n<td>投注指定的双骰 ( 如双 1 点 ) ，至少开出 2 颗所投注的骰子</td>\r\n<td>1 赔 8</td>\r\n</tr>\r\n<tr>\r\n<td>牌九式 ( 骨牌、短牌 )</td>\r\n<td>投注 15 种 2 颗骰子可能出现的组合 ( 如 1 ， 2)</td>\r\n<td>1 赔 5</td>\r\n</tr>\r\n<tr>\r\n<td colspan=\"3\">\r\n<p>点数总和</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>4 或17 点</td>\r\n<td>总和为 4 或 17 点</td>\r\n<td>1 赔 50</td>\r\n</tr>\r\n<tr>\r\n<td>5 或 16 点</td>\r\n<td>总和为 5 或 16 点</td>\r\n<td>1 赔 18</td>\r\n</tr>\r\n<tr>\r\n<td>6 或 15 点</td>\r\n<td>总和为 6 或 15 点</td>\r\n<td>1 赔 14</td>\r\n</tr>\r\n<tr>\r\n<td>7 或 14 点</td>\r\n<td>总和为 7 或 14 点</td>\r\n<td>1 赔 12</td>\r\n</tr>\r\n<tr>\r\n<td>8 或 13 点</td>\r\n<td>总和为 8 或 13 点</td>\r\n<td>1 赔 8</td>\r\n</tr>\r\n<tr>\r\n<td>9, 10, 11, 或 12</td>\r\n<td>总和为 9 ， 10 ， 11 或 12 点</td>\r\n<td>1 赔 6</td>\r\n</tr>\r\n</tbody>\r\n</table>','',1,0,0,12,'2011-03-21 15:49:24',62,'','2012-05-01 10:09:46',42,0,'0000-00-00 00:00:00','2011-03-21 15:49:24','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,0,15,'','',1,471,'',0,'*',''),(45,53,'轮盘玩法','2011-03-21-15-55-59','','<p>我们提供的是欧式蒙地卡罗轮盘，转轮有 37个槽，号码为0、1到36，因为只有一个0，这样就可以增加赢取的机会。下注结束后，荷官会把轮盘向一个方向转动，然后把象牙制滚球反方向抛到轮盘的外侧，让滚球在轮盘内转动多周后慢慢停下来，并降落在其中一个细沟内为该局结果。</p>\r\n<h2>游戏玩法</h2>\r\n<ul>\r\n<li>开始新局后，即开始下注倒数计时，请玩家在桌面不同的方格内或方格的边界上押放筹码。 </li>\r\n<li>倒数结束后停止下注，荷官抛出滚球。 </li>\r\n<li>由荷官输入结果数字，同时玩家画面显示结果。 </li>\r\n<li>若滚球停止转动后仍无法判别结果，荷官将重新掷球一次。 </li>\r\n</ul>\r\n<h2>掷球规则</h2>\r\n<ol>\r\n<li>本游戏进行方式为最接近实境赌场之设置，若有发生特殊情形将依本公司公告之办法处理。 </li>\r\n<li>本游戏为实时视讯传输，为让您清楚看到号码特写，于每局游戏结果产生时，荷官在不影响游戏结果的情况下会将结果号码转至定点，然后提供结果特写给所有玩家。 </li>\r\n<li>（a）荷官掷球时若不慎将球掷出轮盘之外视为“飞球”； <br /> （b）圆球若旋转不到三圈即落入号码框格内； <br /> （c）圆球在盘缘上转动不停而未正常落入号码框格内；此时将由荷官停止轮盘运转，并将圆球摆放回上局结果之号码框格内。玩家会在窗口内看到“无法判定结果，重新掷球”等提示后再由荷官重新进行掷球。 </li>\r\n<li>荷官在游戏进行中若因种种因素把输盘停止运转则该局游戏必将重新进行掷球。 </li>\r\n<li>若游戏结果与系统开配有误时，所有游戏结果将以视讯为主并重新派彩。 </li>\r\n<li>游戏进行中因线路问题造成视讯中断:<br /> (a)若圆球已落入号码框格内，则该局游戏视为有效并由系统进行开配； <br /> (b)若圆球还在旋转中未落入号码框格内，则由荷官停止轮盘运转并将圆球摆放回上局结果之号码框格内，等视讯恢复正常后再重新掷球，游戏继续。 </li>\r\n<li>游戏进行中若遇某种因素需暂停游戏而关桌处理时，若游戏尚未有结果则退回所有下注金额 </li>\r\n<li>本公司所提供之每局计算机画面游戏结果与历史赛果纪录仅供参考，所有游戏结果皆以视讯结果为依据。</li>\r\n</ol>\r\n<h2>投注种类</h2>\r\n<table class=\"table_rule\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">\r\n<tbody>\r\n<tr>\r\n<td>名称</td>\r\n<td>说明</td>\r\n</tr>\r\n<tr>\r\n<td>直接注</td>\r\n<td>您可以投注包括 0在内的任意一个数字。下注时将筹码放到那个数字的中心 (如8、23或35)。</td>\r\n</tr>\r\n<tr>\r\n<td>分注</td>\r\n<td>您可以投注于两个号码之间的网格线上 (如2和3，或13和16)。</td>\r\n</tr>\r\n<tr>\r\n<td>街注</td>\r\n<td>您可以投注三个号码。将筹码押在轮盘桌上有三个数字那一行顶部的那条边在线即可 (如7、8和9)。</td>\r\n</tr>\r\n<tr>\r\n<td>三数</td>\r\n<td>您可以投注于 0, 1,    2或0, 2, 3的交接区域。</td>\r\n</tr>\r\n<tr>\r\n<td>角注</td>\r\n<td>您也可以将筹码放到四个数字方框交差的那个角区以下注那四个数字 (如19、20、22和23)。</td>\r\n</tr>\r\n<tr>\r\n<td>四个号码</td>\r\n<td>您可将筹码放到 0和1交线的左侧以下注数字 0, 1, 2 和3。</td>\r\n</tr>\r\n<tr>\r\n<td>线注</td>\r\n<td>您可将筹码下注到两行相交的最顶部的交点处 ， 您可以赌两个街注，也就是两行的六个数字。 (如28、29、30及31、32、33便组成一条Line)。</td>\r\n</tr>\r\n<tr>\r\n<td>列注</td>\r\n<td>桌上每列数字底部都有带‘    2 比 1’ 字样的方框，一共有三个。 如果被击中的号码是那一列中的数位，那?您就按 1:2 的比率赢钱。这种赌区不包括 0 。 (如：3、6、9、12、15、18、21、24、27、30、33、36)。</td>\r\n</tr>\r\n<tr>\r\n<td>下注一打数位</td>\r\n<td>您可以将筹码下到有 “第一打 12”，“第二打 12”和“第三打 12 ”字样的赌区以同时下注 12个数字。 (分别为0-12、13-24及25-36)。</td>\r\n</tr>\r\n<tr>\r\n<td>红色 /黑色</td>\r\n<td>投注中彩号码将为红色或是黑色的，共投注十八个数字。 (0不在内)。</td>\r\n</tr>\r\n<tr>\r\n<td>双数 / 单数</td>\r\n<td>投注中彩号码将为单数或是双数，共投注十八个数字，且不包括 0。</td>\r\n</tr>\r\n<tr>\r\n<td>低注 / 高注</td>\r\n<td>投注中彩号码将算小    (1-18)或是算大(19-36)，共十八个数位。0不是赢取数位。</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h2>派彩</h2>\r\n<table class=\"table_rule\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">\r\n<tbody>\r\n<tr>\r\n<td>投注类型</td>\r\n<td>派彩</td>\r\n</tr>\r\n<tr>\r\n<td>直接注</td>\r\n<td>1:35</td>\r\n</tr>\r\n<tr>\r\n<td>分注</td>\r\n<td>1:17</td>\r\n</tr>\r\n<tr>\r\n<td>街注</td>\r\n<td>1:17</td>\r\n</tr>\r\n<tr>\r\n<td>三数</td>\r\n<td>1:11</td>\r\n</tr>\r\n<tr>\r\n<td>角注</td>\r\n<td>1:8</td>\r\n</tr>\r\n<tr>\r\n<td>四个号码</td>\r\n<td>1:8</td>\r\n</tr>\r\n<tr>\r\n<td>线注</td>\r\n<td>1:5</td>\r\n</tr>\r\n<tr>\r\n<td>列注</td>\r\n<td>1:2</td>\r\n</tr>\r\n<tr>\r\n<td>下注一打数位</td>\r\n<td>1:2</td>\r\n</tr>\r\n<tr>\r\n<td>红色 /黑色</td>\r\n<td>1:1</td>\r\n</tr>\r\n<tr>\r\n<td>双数 / 单数</td>\r\n<td>1:1</td>\r\n</tr>\r\n<tr>\r\n<td>低注 / 高注</td>\r\n<td>1:1</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p> </p>','',1,0,0,12,'2011-03-21 15:52:00',62,'','2012-05-01 10:09:46',42,0,'0000-00-00 00:00:00','2011-03-21 15:52:00','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,0,14,'','',1,445,'',0,'*',''),(46,56,'龙虎斗','2011-03-21-15-58-50','','<p>龙虎</p>\r\n<h2>龙虎游戏简介</h2>\r\n<p>为扑克牌游戏，抽一张比大延伸而来的游戏。</p>\r\n<h2>玩法介绍</h2>\r\n<p>游戏使用八副扑克牌。</p>\r\n<p>玩家可以投注龙、虎、和、三门。</p>\r\n<p>荷官只派两门牌，每门各派一支牌，即龙与虎，双方</p>\r\n<p>斗大</p>\r\n<p>下注龙或虎，出和的情况下算一半的有效投注。</p>\r\n<h2>大小</h2>\r\n<p>最大为K，最小为A，不比花色，只比点数，点数相同为和</p>\r\n<h2>牌面大小</h2>\r\n<p>由小到大依次为：A 2 3 4 5 6 7 8 9 10 J Q K</p>\r\n<h2>派彩</h2>\r\n<p>下注龙，1赔1,开和时输一半下注金额。</p>\r\n<p>下注虎，1赔1,开和时输一半下注金额。</p>\r\n<p>下注和，1赔8.</p>','',1,0,0,12,'2011-03-21 15:57:00',62,'','2012-05-01 10:10:32',42,0,'0000-00-00 00:00:00','2011-03-21 15:57:00','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,0,12,'','',1,7,'',0,'*',''),(47,51,'斗牛游戏','2011-03-21-16-05-10','','<h2>斗牛玩法</h2>\r\n<p>玩家可押注「庄家」、「闲家」、「庄两对」、「庄3条」、「闲两对」、「闲3条」多个区域。</p>\r\n<p>游戏开始后，庄闲家各发牌5张。庄家和闲家从中抽出总和为10的倍数(即10、20、30)之3张牌置于下方，最后剩下的2张牌则置于上方。如下方牌点数总和为10的倍数(即「有牛」)，则可进而以上方2张牌之点数总和进行比对。如下方牌的总和未能为10之倍数(即「无牛」)，就以5张牌中点数最大者进行比对。</p>\r\n<h2>牌面点数</h2>\r\n<p>1.「斗牛」游戏中，A计为1点，2-9牌则以牌面点数计算，而10、J、Q、K牌，皆算为10点。</p>\r\n<p>2. 如押注「两对」或「3条」，遇开「4条」或「葫芦」者，则算两者皆胜。</p>\r\n<h2>牌型类别</h2>\r\n<p>牛牛＞牛9~牛1&gt;无牛</p>\r\n<p>牛牛</p>\r\n<p>若下方3张牌的点数总和为10的倍数(即10、20、30)，进而上方两张牌的点数总和为10的倍数，此类组合即称为「牛牛」。</p>\r\n<p>例子：下方3张牌点数为K、8、2 (10倍数)，上方2张牌点数为10、Q(10的倍数)，此牌型称为「牛牛」。</p>\r\n<h2>牛1~牛9</h2>\r\n<p>若下方3张牌的点数总和为10的倍数(即10、20、30)，即可将上面两张牌点数的总和，与对家进行比对。(若相加后点数大于10，就以其中的个位数字计算)点数分为1~9点。若计算后，个位数字为1，即称为「牛1」，个位数字为2，即称为「牛2」。如此类推，当中又以「牛9」为最大。</p>\r\n<p>例子：下方3张牌点数为Q、4、6(10倍数)，上方两张牌点数为10、2，此牌型称为「牛2」。</p>\r\n<h2>无牛</h2>\r\n<p>若玩家下方3张牌面无法形成10倍数之组合，便不能以上方两张牌点数的总和进行比对，这种牌型称为「无牛」。</p>\r\n<p>例子：整副牌为A、A、2、2、3，由于下方3张牌无法形成10倍数之组合，所以此牌型称为「无牛」。</p>\r\n<p>如双方牌型一样，则以5张牌中最大者作比对。举例，庄家牌为K、Q、7、2、A，闲家牌为Q、J、10、6、4，此局算「庄」胜。如若双方牌中最大者相同，则以第二最大者比对；如若相同，则以第三最大者作比对，如此类推，直到分出胜负为止。如庄闲双方5张牌点数均相同，则作「和局」。注意，此规则适用于所有牌型。</p>\r\n<h2>赔率一览：</h2>\r\n<p>胜方：</p>\r\n<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"40%\">\r\n<tbody>\r\n<tr>\r\n<td width=\"50%\">组合</td>\r\n<td>赔率</td>\r\n</tr>\r\n<tr>\r\n<td>无牛～牛6</td>\r\n<td>1 x 0.95</td>\r\n</tr>\r\n<tr>\r\n<td>牛7</td>\r\n<td>1 x 1.90</td>\r\n</tr>\r\n<tr>\r\n<td>牛8</td>\r\n<td>1 x 1.90</td>\r\n</tr>\r\n<tr>\r\n<td>牛9</td>\r\n<td>1 x 1.90</td>\r\n</tr>\r\n<tr>\r\n<td>牛牛</td>\r\n<td>1 x 2.85</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>负方</p>\r\n<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"40%\">\r\n<tbody>\r\n<tr>\r\n<td width=\"50%\">组合</td>\r\n<td>赔率</td>\r\n</tr>\r\n<tr>\r\n<td>无牛～牛6</td>\r\n<td>1 x 1</td>\r\n</tr>\r\n<tr>\r\n<td>牛7</td>\r\n<td>1 x 2</td>\r\n</tr>\r\n<tr>\r\n<td>牛8</td>\r\n<td>1 x 2</td>\r\n</tr>\r\n<tr>\r\n<td>牛9</td>\r\n<td>1 x 2</td>\r\n</tr>\r\n<tr>\r\n<td>牛牛</td>\r\n<td>1 x 3</td>\r\n</tr>\r\n</tbody>\r\n</table>','',1,0,0,12,'2011-03-21 15:59:02',62,'','2012-05-01 10:09:22',42,0,'0000-00-00 00:00:00','2011-03-21 15:59:02','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,0,11,'','',1,105,'',0,'*',''),(48,55,'三公对对碰','2011-03-21-16-07-39','','<h2>三公对对碰玩法：</h2>\r\n<p><img src=\"images/kings.jpg\" border=\"0\" alt=\"三公对对碰玩法\" /></p>\r\n<p>三公对对碰为太阳城创新的三公游戏，目的是增加其公平性。玩法简易，玩家先选择一门为庄，然后再投注余下的任何一门或多门与庄那门斗大，荷官派六门牌，每门各派三只牌。三公对对碰的牌例与普通三公的牌例相同。三公为最大，其后以三牌合计最近9点为胜，如点数相同，则以多公为胜方。</p>','',1,0,0,12,'2011-03-21 16:05:20',62,'','2012-05-01 10:10:10',42,0,'0000-00-00 00:00:00','2011-03-21 16:05:20','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,0,8,'','',1,430,'',0,'*',''),(49,50,'加勒比海 扑克','2011-03-22-14-49-07','','<p>1.开始新局后，即开始下注倒数计时，请玩家先下第一注即『押注 　』，下注后可选择是否投注下10元的 Jackpot。</p>\r\n<p>2.倒数计结束后，荷官会发庄家及闲家各五张牌，然后打开闲家全 　部牌及庄家一张牌。</p>\r\n<p>3.第二次倒数开始后，玩家可因应闲家牌的好坏决定是否下第二注 　即『加注』来继续玩牌，否则表示放弃及即输『押注』，而『加 　注』金额固定为『押注』的两倍。</p>\r\n<p>4.第二次倒数结束后，荷官会打开庄家其余四张牌，假若庄家的五 　张牌中并没有Ace及King、或一副对子以上，则被判定为「不成局 　」，并只会以1：1的赔率赔偿玩家的『押注』，第二份的『加注 　』则原数退回玩家。相反，如庄家『成局』则以庄家及闲家的牌 　比较大小来决定输赢，如闲家牌胜过庄家牌的话，玩家将赢取『 　押注』的金额加上『各牌局赔率』表上的倍数乘上「加注」的金额。</p>\r\n<p>各牌局赔率表 一对</p>\r\n<p>--   1 比 1 两对</p>\r\n<p>--   2 比 1 三条</p>\r\n<p>--   3 比 1 顺子</p>\r\n<p>--   4 比 1</p>','',1,0,0,12,'2011-03-22 14:47:31',62,'','2012-05-01 10:09:22',42,0,'0000-00-00 00:00:00','2011-03-22 14:47:31','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',3,0,10,'','',1,478,'',0,'*',''),(50,83,'闯关连赢夺大奖','2011-04-06-21-18-17','','<h3>为感谢信老会员对“太阳城线上娱乐城”的厚爱，本公司特推出“闯关连赢夺大奖”活动，无限精彩尽在太阳城线上娱乐。</h3>\r\n<p><img src=\"images/stories/0.jpg\" border=\"0\" width=\"574\" height=\"331\" /> </p>\r\n<p><strong>活动时间</strong>：4月10日-5月10日</p>\r\n<p><strong>活动规则</strong>：在本网站“百家乐，龙虎，”游戏中同一张台同一靴牌局内连投连中且每局投注不低于100元，即可获得额外奖励，活动许可投注项为“庄，闲，龙，虎”（和局，和庄对子，闲对子盈利除外）。</p>\r\n<p><strong>活动须知</strong>：此项优惠仅针对本公司直属会员，投注奖金需全额投注方可提款。</p>\r\n<p>活动奖励彩金：</p>\r\n<h2>连中<strong><span style=\"color: #ff0000;\">8</span></strong>局送<strong><span style=\"color: #ff0000;\">688</span></strong>元奖金</h2>\r\n<h2>连中<strong><span style=\"color: #ff0000;\">12</span></strong>局送<strong><span style=\"color: #ff0000;\">1888</span></strong>元奖金</h2>\r\n<h2>连中<strong><span style=\"color: #ff0000;\">15</span></strong>局送<strong><span style=\"color: #ff0000;\">4888</span></strong>元奖金</h2>\r\n<h2>连中<strong><span style=\"color: #ff0000;\">18</span></strong>局送<strong><span style=\"color: #ff0000;\">8888</span></strong>元奖金</h2>\r\n<p><strong>兑奖方式</strong>：所有客户在投注中达到奖励奖金等级后请立即报知我们的在线客服或者QQ客服9580629为您审核登记您的投注编号和账户信息，当日内有效，逾期作废。</p>\r\n<p><strong>奖金赠送时间</strong>：活动期间，凡是经客服人员核实后的中奖奖金，我们将会在次日的中午12点到14点之间统一为您添加到您指定的游戏账号，并短信通知。</p>\r\n<p> </p>\r\n<p><strong>以上所有内容最终解释权终归太阳城线上娱乐城所有。</strong></p>','',1,0,0,2,'2011-04-06 21:13:31',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-04-06 21:13:31','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',6,0,7,'','',1,53,'',0,'*',''),(51,84,'会员提款','2011-04-27-14-07-38','','<p>{infinityform form=\"888\"}</p>','',1,0,0,2,'2011-04-27 14:06:07',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2011-04-27 14:06:07','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,0,6,'','',1,76,'',0,'*',''),(52,39,'取款流程','deposit-get','','<div class=\"deposit_link clearfix\"><a class=\"put\" href=\"index.php?option=com_content&amp;view=article&amp;id=37&amp;Itemid=103\">put</a> <a class=\"get active\" href=\"index.php?option=com_content&amp;view=article&amp;id=52&amp;Itemid=103\">get</a></div>\r\n<p><strong>取款流程</strong><br />Suncity线上娱乐城致力为会员提供最优质的服务,7×24小时随时提款。,不需要支付任何费用.您只需要联系我们的网页在线客服，QQ客服，或者拨打我们的客服热线15190762555提供您的取款银行信息（包括：银行行别，银行账号，开户姓名，开户省份和城市）游戏账号，提款金额。我们会在接收到您的提款申请后10分钟内为您支付.并会以手机短信的方式通知您注意查收. <br /><br />取款须知：<br />1.每笔取款下限为100元人民币，上限为1000000元人民币<br />2.每个账户每日不限次数申请提款。<br />3.银行帐号持有人姓名必须与在太阳城娱乐城注册的姓名一致，否则无法申请提款。<br />4.请提供有效的手机号码，如有任何问题，方便客服第一时间与您联系。 <br />5.存款后必须经过全额投注，否则无法申请提款，例如您存款1000元，您的有效投注额需达到1000元方可以申请提款。<br />6.为了您的提款方便快捷，请尽量提供此5种银行方便我们转账：工行、建行、农行、招商行、中行，其他银行请提供详细的开户行地址。<br /><br />我们支持中国大陆大部分的借记卡，建议您使用工行，建行，农行，招行，中国银行行进行提款，这样可以更快到帐。其它银行属于跨行转帐，不能保证及时到帐。。<br /><br />如有任何疑问，您可以直接联系24小时在线客服或QQ客服<br />QQ: 9580629、9596730  <br /><br /><br /></p>','',1,0,0,8,'2011-04-28 08:49:31',62,'','2012-04-24 16:35:04',42,0,'0000-00-00 00:00:00','2011-04-28 08:49:31','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":null,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":null,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":null,\"urlctext\":\"\",\"targetc\":\"\"}','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',7,0,9,'','',1,62,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(53,86,'博彩责任','2012-02-25-07-12-49','','<div>\r\n<p align=\"left\">太阳城娱乐网 		积极推行负责任博彩，並极力拒絕未成年玩家使用我们的软体进行网上娱乐。同时，我们更透过专业人员及各种有效方法，以防止问题博彩的发生。 <strong></strong></p>\r\n<p align=\"left\"><strong>1.</strong> <strong>年龄验证</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">太阳城娱乐网 		严格规定每个新玩家必须证明他们已达至所属管辖区內线上娱乐的法定年龄，而且我们会采取所有合理的措施来验证有关资讯。另外， 		太阳城娱乐网 		不会向未成年玩家投放任何广告宣传，更会主动追踪那些试图在 		太阳城娱乐网 		进行娱乐活动的未成年人士，以免在法律上及道德上发生任何错误，並对游戏产生不利影响。</p>\r\n<p align=\"left\">为确保玩家已达合法年龄，我们会要求新用户在登记及出款时，同意 		太阳城娱乐网 		有关的条款及细则，並出示身份证以收集姓名、地址和出生日期，确保他们所提供的个人详细资讯乃正确无误，並会百分百保证他们开户时已年满18岁之合法年龄。</p>\r\n<p align=\"left\">此外，我们为了保证 太阳城娱乐网 		的游戏只开放给所有达至法定年龄的玩家，会积极鼓励用户采取合理的预防措施，以确保未成年人士不能透过任何帐户来访或参与我们的游戏。特別是，我们强烈鼓励当用户在选择登录我们的软体时，尽量隔离所有未成年人士。以免他们得悉任何有关登入资讯。我们建议：</p>\r\n<ul>\r\n<li>在登录我们的系统时，不要让未成人士在萤光幕显示范围內观看或停留。</li>\r\n<li>如果用户需要离开系统的操作范围，请谨记使用密码锁住电脑。</li>\r\n<li>各用户务必将 太阳城娱乐网 		帐户及密码放置在安全地方。</li>\r\n<li>切勿在登录 太阳城娱乐网 		系统时，选择启用「保存密码」功能。</li>\r\n<li>请于电脑使用年龄保护软体，以限制未成年用户到访特定网站及使用相关程式。</li>\r\n<li>切勿与未成年人士分享信用卡或帐户等相关资讯</li>\r\n<li>当用户从他人电脑登入 太阳城娱乐网 		软体时，或从远端位置(无线网吧、机场、酒店或其他公共场所)进行登录及娱乐活动时，请留意是否已隔离任何未成年人士。</li>\r\n</ul>\r\n<p align=\"left\">若用户得悉有任何未成年人使用 太阳城娱乐网 的软体，请主动与我们联络:		<a href=\"mailto:suncitycs888888@gmail.com\">suncitycs888888@gmail.com</a> 该E-mail地址已受到防止垃圾邮件机器人的保护，您必须启用浏览器的Java 		Script才能看到。 		，並提供所有相关资讯，包括该用户到访本网站或进行娱乐活动之名称。然后，我们将会作出全面公正的调查，更会在必要时，冻结该帐户以防止有未成年人士在本网站继续进行任何娱乐活动。</p>\r\n<p align=\"left\"><strong>家长控制</strong> <strong></strong></p>\r\n<p align=\"left\">父母或监护人可透过使用一系列的第三方软体，以有效监控或限制电脑未成年人士对互联网的使用：</p>\r\n<ol>\r\n<li>Net Nanny过滤软体防止未成年瀏览不适宜的网站內容：		<a href=\"http://www.netnanny.com/\" target=\"_blank\">www.netnanny.com</a></li>\r\n<li>CYBERsitter过滤软体允许父母增加自定义过滤网站:		<a href=\"http://www.cybersitter.com/\" target=\"_blank\">www.cybersitter.com</a> </li>\r\n</ol>\r\n<p align=\"left\"><strong>2.</strong> <strong>控制沉迷赌博之行为</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">太阳城娱乐网 		由成立至今，目标也是缔造一种健康的娱乐活动，同时也希望向那些有需要人士予以协助。 		太阳城娱乐网 		承诺会以一切的努力履行社会责任，为玩家提供周全的服务。为了确保每位用户能于本网享受到精采娱乐，所以建议大家于登录前，先确定个人可以承受一定的损失。</p>\r\n<p align=\"left\"><strong> 如用户正处于以下任何一项状况，请立刻停止所有博彩活动： </strong></p>\r\n<ul>\r\n<li>未达合法博彩年龄。</li>\r\n<li>干扰自身的工作和其他职责。</li>\r\n<li>正处于病态博彩的恢复期。</li>\r\n<li>正受酒精或其他物质的影响之下。</li>\r\n<li>企图挽回之前博彩所带来的损失。</li>\r\n</ul>\r\n<p align=\"left\">若博彩对于用户来说已不是一种玩乐意愿，而是一种精神依靠，那务必尽快向匿名赌徒国际服务会（Gamblers 		Anonymous）或有关组织寻求协助。</p>\r\n<p align=\"left\">不少人希望透过博彩娱乐点缀生活。不过，仍有小部分人由于各种原因，成为了问题博彩者。问题/病态博彩不单会破坏了自身的日常生活，更会为网上娱乐的声名带来负面影响。特此， 		太阳城娱乐网 		已为员工提供专门训练，以关注及处理任何有关问题/病态博彩的个案。</p>\r\n<p align=\"left\">有研究证明，全球现今只有百分之一的成年人正面临问题/病态赌博的困窘，但对于 		太阳城娱乐网 		来说，即使只有一个问题/病态博彩者，我们也觉得太多。现今，有很多团体积极帮助问题/病态博彩者。当中较着名的有匿名赌徒国际服务会 		（Gamblers 		Anonymous），而目标就是消除问题博彩。他们透过经验分享、各种训练以协助问题/病态博彩者戒除赌癮。同时，我们的管理层和员工也拥有丰富经验，用不同的方法确认出问题/病态博彩。如各位觉得有需要寻找协助的话，可与匿名赌徒国际服务会或我们联络。 <strong></strong></p>\r\n<p align=\"left\"><strong>3. </strong> <strong>责任感和正直诚信</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">太阳城娱乐网 		致力提高服务水准，並承诺向客户履行最大程度上的责任，包括诚信、透明度、合法性等各方面。如客户遇上任何有关负责任博彩的问题，可24小时向我们的客户服务部联络。我们承诺会于一年365日，不间断地为用户提供技术支援及相关问题解答服务。</p>\r\n</div>','',1,0,0,2,'2012-02-25 07:11:56',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2012-02-25 07:11:56','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',3,0,5,'','',1,8,'',0,'*',''),(54,87,'免责条款','2012-02-25-07-57-52','','<div>\r\n<p align=\"left\">太阳城娱乐网 		对网站的內容及第三者在网站內提供的资料或內容之准确性等，並不会负上任何的法律责任。</p>\r\n<p align=\"left\">太阳城娱乐网 		会尽力确保网站资讯的准确性、完整性以及即时性(一切以发表日期为准)，但本公司並不能保证相关內容的准确性、完整性、即时性、网络技术与排版效能可达致百分百的准确无误。</p>\r\n<p align=\"left\">另外，网站內的部分资讯与其发布的日期和时间是相关的。所以，在特定日期时间之后，相关资讯可能已不再准确真实，本公司亦不承诺会更新该项目，而阁下也有责任在采纳这些资讯前对其真实性进行核对验证。本公司保留在没有预先通知的情况下，修改或更新网站內容资讯的权利。同时，基于某些产品或服务乃受到规章及其他限制约束，所以有关项目並不适合于所有市场。</p>\r\n</div>','',1,0,0,2,'2012-02-25 07:39:24',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2012-02-25 07:39:24','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,0,4,'','',1,4,'',0,'*',''),(55,88,'私隐政策','2012-02-25-08-04-59','','<div>\r\n<p align=\"left\">对于保存客户资料方面， 太阳城娱乐网 		一向采取最谨慎的态度及工作程序作处理。以下的政策说明了我们对客户所肩负起的责任与承诺。另外，也清晰说明了我们处理客户资料的方式。</p>\r\n<p align=\"left\">当阁下使用<span style=\"text-decoration: underline;\"><a href=\"http://818sun.com/sun_new/\">http://818sun.com/sun_new/</a></span> 时，表示您承认並接受 太阳城娱乐网 		隐私政策的规则与条件，並了解收集各项资料之目的及处理之方式。 		<strong></strong></p>\r\n<p align=\"left\"><strong>1.</strong> <strong>资料收集与使用</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">当客户在 太阳城娱乐网 		开设及使用帐户时，我们会收集相关资料，例如姓名、地址、年龄、电邮、电话、IP位置等，而收集这些资料的目为：</p>\r\n<ol>\r\n<li> 保留户口的交易纪录 </li>\r\n<li>协助改善户口管理 </li>\r\n<li>安全理由(包括客户的身份证明) </li>\r\n<li>建立客户档案 </li>\r\n<li>管理客户关係及达至行销目的 </li>\r\n</ol>\r\n<p align=\"left\"><strong>户口的交易状况</strong> <strong></strong></p>\r\n<p align=\"left\">为鉴別客户的兴趣以提供相关优惠及资讯，或基于交易与业务运作等安全理由，我们会保留客户的交易纪录以作分析。</p>\r\n<p align=\"left\"><strong>传送优惠资讯</strong> <strong></strong></p>\r\n<p align=\"left\">在开设户口后，客户将会自动不定期收到由 		太阳城娱乐网 发出之优惠资讯。</p>\r\n<p align=\"left\"><strong>更改您的个人资料</strong> <strong></strong></p>\r\n<p align=\"left\">客户可随时更改个人资料。如有需要，可向我们的客户服务员联络。</p>\r\n<p align=\"left\"><strong>个人资料的安全与准确性</strong> <strong></strong></p>\r\n<p align=\"left\">我们承诺会妥善地保存客户的所有资料，並维护相关资料的准确性。根据法律，客户有权保留个人资料及要求更改任何错误。</p>\r\n<p align=\"left\">同时，我们更会采取所有步骤以确保客户资料在处理过程中，能达至最严格的安全标准。此外，客户资料只有在适用的法律之下方有机会被透露，而资料则主要透露给 		太阳城娱乐网 		等有关部门、商业伙伴、顾问与供应商(如信用卡处理机构)。</p>\r\n<p align=\"left\">我们承诺不会将客户的资料售卖给第三者。</p>\r\n<p align=\"left\"><strong>小型文字档案</strong> <strong>(Cookies)</strong></p>\r\n<p align=\"left\">当客户首次瀏览<a href=\"http://818sun.com/sun_new/\">http://818sun.com/sun_new/</a> 时，一个称为小型文字档案Cookies的资料将会传送到您的瀏览器以对其作出分析。及后，当客户再次瀏览本网站时，小型文字档案拥有一个特別的识別码以鉴別有关用户的电脑。这帮助我们根据客户的喜好及兴趣，以协助提供更佳的上网服务。</p>\r\n<p align=\"left\">纵然客户的瀏览器选择不接受小型文字档案，但亦可流畅地瀏览我们的网页，分別是我们不能提供更佳的上网服务。 		<strong></strong></p>\r\n<p align=\"left\"><strong>2.</strong> <strong>网站信息</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">我们的系统会自动记录 太阳城娱乐网 		瀏览者的网路IP位址，但我们决不会记录网站访问者的电邮地址，而此项主要是用作网站流量统计之用。 		<strong></strong></p>\r\n<p align=\"left\"><strong>3.</strong> <strong>广告系统</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">我们的广告系统会自动记录点击者的网路IP位址，此项主要令网站宣传功能有效发挥。 		<strong></strong></p>\r\n<p align=\"left\"><strong>4.</strong> <strong>彩金</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">我们会严格保密客户所贏取的彩金数额。如根据当地的法律规定，要求客户必须要向当地的政府机构申报所贏取之彩金数额，那么这个申报权益则会留给客户作决定。 		<strong></strong></p>\r\n<p align=\"left\"><strong>5.</strong> <strong>安全性</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">太阳城娱乐网 		为确保客户提供给我们的个人资讯及资料是絕对安全保密。所有传送给我们的相关內容，都必定经过高科技的保密设施后，然后储存进我们的伺服器內。这项保密设施，乃使用目前最先进的防火墙技术来维护。我们的娱乐网站和软体更会采用最佳的保密程式，目的是保证玩家的个人资料不会被第三方胡乱使用。</p>\r\n<p align=\"left\"><strong> 如客户对我们的隐私政策和安全有任何疑问，请随时来信諮询或使用 </strong> <strong> </strong> <strong>太阳城娱乐网</strong> <strong> </strong> <strong><span style=\"text-decoration: underline;\">24</span></strong> <strong><span style=\"text-decoration: underline;\">小时在綫服务</span></strong> <strong>与我们联系。</strong> <strong></strong></p>\r\n</div>','',1,0,0,2,'2012-02-25 08:02:48',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2012-02-25 08:02:48','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,0,3,'','',1,4,'',0,'*',''),(56,89,'服务条款','2012-02-25-09-15-57','','<div>\r\n<p align=\"left\">请仔细阅读本条款，並确认你完全理解其內容。如果对于这一条款所产生的权利和义务有任何疑问，请向你所属法律管辖区域內的法律顾问寻求帮助。 <strong></strong></p>\r\n<p align=\"left\"><strong>1.</strong> <strong>定义</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">1.1</p>\r\n<p align=\"left\">以下条规适用于用户使用、联接和参与由 		太阳城娱乐网 (统称 太阳城娱乐网 		、「我们」及「我们的」，视具体情况而定) 		通过http://818sun.com/sun_new/经营的网站提供的网上博彩服务。本条规须与特定博彩的博彩规则及适用于博彩软件的使用及与连接进入博彩网站和其中所含条规一併阅读。</p>\r\n<p align=\"left\">1.2</p>\r\n<p align=\"left\">「博彩」就本条规而言，包括但不限于通过博彩网站提供的任何及/或一切博彩服务进行的投注、游戏及各类博彩活动；</p>\r\n<p align=\"left\">「联接设备」指任何应用联接设备，包括但不限于为使用和联接博彩网站、参与博彩服务而采用的个人电脑、笔记本电脑、移动电话、个人数码助理、PDA电话、手提设备。</p>\r\n<p align=\"left\">「博彩软件」指经监管机关批准的、安装在用户联接设备上的电脑程序、数据文件或任何其他资讯及信息內容(包括与之有关的任何用户信息)，以便用户通过其使用、联接和参与在博彩网站上提供的博彩服务； <strong></strong></p>\r\n<p align=\"left\"><strong>2.</strong> <strong>同意</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">2.1</p>\r\n<p align=\"left\">用户在注册过程中于「我声明我已年满18岁」及「我同意 		太阳城娱乐网 		的规则与条款。」字样之前的方框內打勾，並点击相应的「提交」按钮，即表示用户确认並同意：</p>\r\n<p align=\"left\">i. 用户已经阅读、完全理解並同意本条规；</p>\r\n<p align=\"left\">ii. 本条规构成用户与 太阳城娱乐网 		之间关于博彩服务使用的具有法律约束力的协议 		(「使用协议」) 。</p>\r\n<p align=\"left\">2.2</p>\r\n<p align=\"left\">如果用户不同意本条规中的任何条款，请不要勾选「我同意 		太阳城娱乐网 		的规则与条款。」及不要点击「提交」按钮，不要试图使用或继续使用任何博彩服务或下载和/或安装博彩软件。 <strong></strong></p>\r\n<p align=\"left\"><strong>3.</strong> <strong>修改</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">3.1</p>\r\n<p align=\"left\">太阳城娱乐网 		保留不时修订、更新和修改本条规和博彩规则 		(或其任何部分) 		的絕对权利。上述任何修订、更新或修改将在博彩网站上公布。经修订、更新或修改的本条规和博彩规则于其在博彩网站上公布时生效。用户在之后继续通过博彩网站和博彩设备使用、联接和参与博彩服务，将视为同意並接受所公布的经修改或更新的本条规和博彩规则。</p>\r\n<p align=\"left\">3.2</p>\r\n<p align=\"left\">用户确认並同意自行负责查阅上述修订、更新和/或修改。 		太阳城娱乐网 		可自主决定将上述修订、更新和修改通知用户。上述修订、更新和修改可由 		太阳城娱乐网 自主决定不时通知用户，但 		太阳城娱乐网 		並无任何义务向用户通知任何更新和修改。 <strong></strong></p>\r\n<p align=\"left\"><strong>4.</strong> <strong>博彩资讯和知识产权</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">4.1</p>\r\n<p align=\"left\">通过博彩网站、博彩服务、博彩设备和/或任何其他方式提供向用户公开、获取、产生和/或收集的信息、资料和数据，包括但不限于营销计划和资料、成绩、统计数据、赛事数据、赛程表、概率和投注数据、文字、图标、音像资讯 		(「博彩资讯」) ，将属于 太阳城娱乐网 		和其许可人所有，仅供用户用于个人非商业性目的。</p>\r\n<p align=\"left\">4.2</p>\r\n<p align=\"left\">除在本条规外，未经我们或第三方资料专有人的事先书面同意，用户不得以任何方式或手段改编、拷贝、修改、复制、储存、散发、展示、公开播放、制入有线节目、出版、传送、出售、出借、出租、许可使用博彩资讯。用户也不得以其他方式使用任何他人或其他网站、网上服务、公告板、任何媒体和/或联接设备可以获得、使用、或连接上述博彩资讯。</p>\r\n<p align=\"left\">4.3</p>\r\n<p align=\"left\">在博彩网站和/或通过联接设备提供的博彩软件、博彩服务和博彩资讯享受着作权、商标和其他形式的知识产权和专利保护。博彩网站上的博彩软件、博彩服务和博彩资讯的所有权利、产权和利益均属 		太阳城娱乐网 		和其许可人所有、使用或控制。用户确认並未通过使用或联接在博彩网站和/或联接设备提供的博彩软件、博彩服务和博彩资讯取得 		太阳城娱乐网 		的博彩软件、博彩服务和博彩资讯的任何权利、利益或许可。 <strong></strong></p>\r\n<p align=\"left\"><strong>5.</strong> <strong>使用条件</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">作为使用博彩服务的条件，用户保证並承诺不得以任何违反适用于用户的任何法律、违反本条规和/或被本条规所禁止的目的使用或联接博彩网站、博彩服务软件、博彩软件服务和博彩资讯。除了本条规中所列一切其他声明和保证之外，用户在此进一步保证並承诺，作为使用博彩服务的条件：</p>\r\n<p align=\"left\">. 		用户以本人的身份及名义进行活动，而非代他人进行交易；</p>\r\n<p align=\"left\">i. 用户的法律行为能力不受限制；</p>\r\n<p align=\"left\">ii. 用户未被诊断或认定为赌博强迫症；</p>\r\n<p align=\"left\">iii. 		用户年龄(a)至少已满18周岁；或(b)已满任何适用于用户的法律所规定的其他法定年龄或成人年龄，以较大者为准(「法定年龄」)；</p>\r\n<p align=\"left\">iv. 		用户充分瞭解在使用博彩服务的过程中亏损资金的风险；</p>\r\n<p align=\"left\">v. 		用户存入的款项並非来源于犯罪或其他非法、未经授权或许可的活动；</p>\r\n<p align=\"left\">vi. 		用户並非从事犯罪或其他非法、未经授权或许可活动和/或企图利用用户在 		太阳城娱乐网 		开立的账户从事上述活动；用户不得利用或允许他人利用博彩服务或用户的博彩账户从事适用于用户或我们的任何法律所规定的任何犯罪或其他非法活动，包括但不限于洗钱；</p>\r\n<p align=\"left\">vii. 		对用户的户名、账号和密码予以保密，防止非法联接或使用，在户名、账号或密码以任何方式失密的情况下立即更改密码或通知我们；</p>\r\n<p align=\"left\">viii. 		对以用户的户名、账号和密码通过博彩网站和/或联接设备联接和使用博彩服务的任何及所有活动自行承担责任，不论上述联接和/或使用是否经用户授权或为用户所知晓；</p>\r\n<p align=\"left\">ix. 		不以任何干扰或可能干扰其他用户使用博彩服务和博彩网站的方式使用博 		彩服务、博彩网站、联接设备、博彩软件和博彩资讯，不实施任何降低或可能降低博彩服务和博彩网站运行效能的行为；</p>\r\n<p align=\"left\">x. 		不徵集或以任何方式企图获取有关其他用户的任何资料；</p>\r\n<p align=\"left\">xi. 		不上传或散发任何含有病毒、已经毁坏或可能影响联接设备、博彩软件、博彩服务和/或博彩网站运行效能的程序、文件或数据；</p>\r\n<p align=\"left\">xii. 		用户通过博彩网站和/或联接设备联接或使用博彩服务和博彩资讯不违反适用于用户的法律；亦不违反对用户个人或用户目前联接博彩网站或使用联接设备所在国家所有人具有约束力的合约义务；同时不受上述法律或合约义务禁止；</p>\r\n<p align=\"left\">xiii. 		不使用任何设备、机械、装置、软件、程序或其他方法 		(或任何具有上述性质的事物) 		干扰或企图干扰博彩服务、联接设备、博彩软件、博彩网站、博彩资讯或博彩网站和/或联接设备提供的任何交易的正常运行；</p>\r\n<p align=\"left\">xiv. 		不向博彩网站和/或联接设备或任何其他用户发布或传送任何违法、骚扰性、侮辱性、威胁性、诬衊性、誹谤性、淫秽、猥褻、煽动性、种族歧视、色情或粗俗的內容，或可构成或教唆犯罪、引发民事责任或以其他方式违反任何法律的內容；</p>\r\n<p align=\"left\">xv. 用户不是 太阳城娱乐网 		或其任何关联公司的管理人员、董事、雇员、顾问、关联人或代理人，或与上述任何人员具有亲属或同屋居住关係；</p>\r\n<p align=\"left\">xvi. 		不干扰其他用户使用博彩服务、博彩网站、博彩软件、联接设备和/或博彩资讯或发起和/或参与调查、竞赛、连锁信或发布/传送「垃圾邮件」或其他未受请求的群发邮件。 <strong></strong></p>\r\n<p align=\"left\"><strong>6.</strong> <strong>注册开立博彩账户和会员资格</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">6.1</p>\r\n<p align=\"left\">欲通过 太阳城娱乐网 		参与博彩、使用博彩服务，用户须按博彩网站所述程序完成开立账户和会员资格的申请 		(「会员资格申请」) 。</p>\r\n<p align=\"left\">6.2</p>\r\n<p align=\"left\">用户声明並承诺，用户在注册和办理会员资格申请时所提供的所有资料，包括会员资格申请所填用户姓名 		(「姓名」) 、资金来源 		(包括有关银行账号和卡号) 		和住址，在一切方面均真实、准确、完整。</p>\r\n<p align=\"left\">6.3</p>\r\n<p align=\"left\">太阳城娱乐网 		将采取必要和适当的措施对用户向我们披露的个人资料予以保密。我们将对所收到的用户个人数据和投注资料予以严格保密，除非法律、法规、规章、法院、监管机关、任何有关博彩管理、执法机关的命令和决定或本条规要求披露。用户对其个人资料的保密自行承担责任。我们保留在完成博彩网站所提供的博彩服务的付款手续所需的范围內向我们支付结算服务提供者和金融机构披露用户个人数据的权利。</p>\r\n<p align=\"left\">6.4</p>\r\n<p align=\"left\">用户还须自行负责确保用户使用和联接博彩网站和其中所含的博彩资讯、下载安装博彩软件和/或使用和参与博彩服务不受适用于用户的法律禁止。</p>\r\n<p align=\"left\">6.5</p>\r\n<p align=\"left\">为验证用户的会员资格申请，我们仍需要用户提供身份和年龄证明 		(如带照片的有效身份证明和借记卡或信用卡) 		。用户提供的具体原始资料如有任何变更，应及时通知我们。为确认用户的姓名和地址， 		太阳城娱乐网 		保留通过邮寄等方式确认用户姓名和地址的权利。 		太阳城娱乐网 		可自行决定采用其他安全措施核实用户提供的任何资料。用户同意本条规，即同时表示同意 		太阳城娱乐网 		联接、使用、处理和储存对用户的任何身份验证或核实结果。</p>\r\n<p align=\"left\">6.6</p>\r\n<p align=\"left\">我们保留基于任何理由拒絕用户会员资格申请的絕对权利。</p>\r\n<p align=\"left\">. 我们仅对在线即时帮助所公布的 		太阳城娱乐网 		官方备用网站负责。会员登录其它任意貌似 		太阳城娱乐网 		网站的链接，所造成的任何损失我们将不承担任何责任。 		如有其他疑问，请直接联络我们的在线客服</p>\r\n<p align=\"left\">i. 		若为曾违反本网站或我们之合作软件商/网站的条款及规则的玩家，其注册将不被接纳。如发现任何此类型之帐户，其将会被封闭及扣除所有赢款及余额。</p>\r\n<p align=\"left\">6.7</p>\r\n<p align=\"left\">用户在 太阳城娱乐网 		仅可开立一个账户。若我们发现用户在 		太阳城娱乐网 		开设不止一个账户，我们保留自行决定将用户在 		太阳城娱乐网 		的所有账户作为一个合併账户处理、取消多余账户或与用户终止本协议的权利。 <strong></strong></p>\r\n<p align=\"left\"><strong>7.</strong> <strong>下注及接受下注</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">7.1</p>\r\n<p align=\"left\">我们于博彩网站上和/或通过联接设备所不时提供的游戏、体育赛事和其他博彩活动开放给用户下注。用户下注须遵守具体游戏或博彩活动的博彩规则以及本条规的规定。若任何赌局出现明显错误或显示错误的参赌人，该赌局的所有下注均告作废。 		太阳城娱乐网 博彩系统发生故障时， 		太阳城娱乐网 		亦有权宣布任何或所有下注无效。</p>\r\n<p align=\"left\">7.2</p>\r\n<p align=\"left\">儘管本条规可能存在其他规定，但 		太阳城娱乐网 		有权基于任何理由酌情拒絕用户的全部或部分下注。</p>\r\n<p align=\"left\">7.3</p>\r\n<p align=\"left\">我们仅接受用户按本条规通过互联网和/或联接设备进行下注。其他下注形式(邮寄、电邮、传真等)一概不予接受。我们即使收到其他形式的下注，不论赌盘最后开出的结果如何，均视为无效。</p>\r\n<p align=\"left\">. 太阳城娱乐网 		有权搁置或拒絕疑用欺骗手段如通过攻击、操纵等破坏操作系统所进行的投注。</p>\r\n<p align=\"left\">i. 		任何不寻常的投注将被取消，而不需另行通知。特此声明，人工智能或软件（机器人\"bots\"）于线上投注服务的使用是被严禁的行为，而任何试图或利用该方式的投注将被取消，相关帐号立即会被关闭。</p>\r\n<p align=\"left\">7.4</p>\r\n<p align=\"left\">受限于本条规其他规定，用户输入正确的用户名和密码且账户內存有足够余额，用户即有效投下注码。</p>\r\n<p align=\"left\">7.5</p>\r\n<p align=\"left\">用户均须对使用下列內容（或其各项结合）所进行的所有活动和交易负责（无论下述使用是否得到授权）：</p>\r\n<p align=\"left\">ii. 用户姓名；和/或</p>\r\n<p align=\"left\">iii. 用户账户号；和/或</p>\r\n<p align=\"left\">iv. 用户的用户名和密码。</p>\r\n<p align=\"left\">7.6</p>\r\n<p align=\"left\">用户自行负责确保其下注细节的准确性。受限于本条规其他规定，一旦用户下注且我们确认接受用户的下注，即为用户下注的最终确证；用户不得取消、撤回下注或更改下注细节。</p>\r\n<p align=\"left\">7.7</p>\r\n<p align=\"left\">所有下注均收录于交易记录数据库。 		太阳城娱乐网 		的交易记录为所有交易及下注的相关信息的最终确证。</p>\r\n<p align=\"left\">7.8</p>\r\n<p align=\"left\">受限于本条规其他规定，当交易代号出现在用户屏幕上並有效显示在用户的交易历史中时，下注即视为有效及被 		太阳城娱乐网 接受。</p>\r\n<p align=\"left\">7.9</p>\r\n<p align=\"left\">比赛开始后和/或下注时比赛结果已被知晓之情况下不得下注。若比赛开始和/或用户下注时已经知晓比赛结果之情况下仍错误地开放给用户下注， 		太阳城娱乐网 		有权不经通知用户即可拒絕用户下注或宣布下注无效； 		太阳城娱乐网 		享有是否接受全部或部分该等下注的自主决定权。为避免疑义，本条款不排除「下半场」投注盘(\"in 		play\" bets)或「半场」投注盘 (\"half time\" bets)。</p>\r\n<p align=\"left\">7.10</p>\r\n<p align=\"left\">博彩网站上预告的开赛时间仅为信息参考之用。若 		太阳城娱乐网 		因任何原因无意中于比赛开始后仍接受下注，则 		太阳城娱乐网 		有权取消和宣布该等下注无效。</p>\r\n<p align=\"left\">7.11</p>\r\n<p align=\"left\">除非有关比赛和游戏的具体规则另有规定，否则为了博彩的目的，开放下注的比赛或游戏的结果将于比赛或游戏实际结束当天决定。 		太阳城娱乐网 		不承认任何后来的可能导致推翻上述结果的质询，原派彩仍然有效。</p>\r\n<p align=\"left\">7.12</p>\r\n<p align=\"left\">体育赛事的比赛地点发生变化的，以原赛场为基础的所有下注均告无效。</p>\r\n<p align=\"left\">7.13</p>\r\n<p align=\"left\">比赛或游戏的贏家将根据博彩规则在上述比赛或游戏实际结束当天予以定。</p>\r\n<p align=\"left\">7.14</p>\r\n<p align=\"left\">为博彩目的， 太阳城娱乐网 		不承认任何延期比赛、抗议或推翻的结果。</p>\r\n<p align=\"left\">7.15</p>\r\n<p align=\"left\">用户下注的多重彩中如包括非参赛者选项或无效选项，派彩将以剩余的有效选项为基础进行结算。</p>\r\n<p align=\"left\">7.16</p>\r\n<p align=\"left\">用户承认所有赔率、指数和让分可不经通知上下浮动，上述赔率、指数和让分仅在用户下注被我们接受时予以确定。</p>\r\n<p align=\"left\">7.17</p>\r\n<p align=\"left\">若明显错误或系统故障造成用户下注的赔率、指数或让分不正确时，则用户的下注或多重彩的部分下注无效。若有关错误或故障及时得到纠正， 		太阳城娱乐网 		有权自主(但无义务)决定尽合理努力和用户联络允许用户以正确的赔率、指数和让分重新下注。</p>\r\n<p align=\"left\">7.18</p>\r\n<p align=\"left\">我们不接受用户同时对同一赛事重复下注。</p>\r\n<p align=\"left\">7.19</p>\r\n<p align=\"left\">就任何下注及其相关交易而言， 		太阳城娱乐网 		享有最后决定权，且其所作决定系终局性並具有最终确定力的。 <strong></strong></p>\r\n<p align=\"left\"><strong>8.</strong> <strong>博彩软件使用权</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">8.1</p>\r\n<p align=\"left\">用户特此确认並同意，用户通过联接设备以下载或其他方式获得的以便其远程使用的博彩网站的博彩软件属于博彩服务的一部分，为 		太阳城娱乐网 		和其许可人的财产；用户对该等博彩软件不享有任何权利。用户不得以任何方式或以任何手段改编、拷贝、修改、复制、储存、散发、展示、公开播放、传播、广播、制入有线节目、出版、传送、出售、出借、出租或许可使用博彩软件。用户不得以其他方式交流或使博彩软件对任何他人或网站、网上服务或公告板或任何其他媒体和/或联接设备开放。</p>\r\n<p align=\"left\">8.2</p>\r\n<p align=\"left\">太阳城娱乐网 		特此授予用户在联连设备上安装和使用博彩软件的非专属性、不可转让的个人使用权 		(「使用权」) 		，但博彩软件的安装和使用所用的联接设备须以用户为主要使用人。</p>\r\n<p align=\"left\">8.3</p>\r\n<p align=\"left\">太阳城娱乐网 		授权和散发博彩软件的目的仅为博彩软件的终端用户能完全连接和使用博彩服务。</p>\r\n<p align=\"left\">8.4</p>\r\n<p align=\"left\">用户不得：</p>\r\n<p align=\"left\">. 		安装或传载博彩软件至其他连网设备的服务器或采取其他步骤使博彩软件可以通过任何形式或公告板、网上服务或远程拨号或网络使他人得到；</p>\r\n<p align=\"left\">i. 		散发、出借、出租、转授权、拷贝、转让、转移或以其他方式使任何其他人得到博彩软件和/或使用博彩软件的使用权；</p>\r\n<p align=\"left\">ii. 允许其他人使用博彩软件；</p>\r\n<p align=\"left\">iii. 设立或提供任何方式 		(包括但不限于仿真程序)使他人使用博彩软件；</p>\r\n<p align=\"left\">iv. 		翻译、反向工程、反向编译，反彙编、修改、破解、全部或部分地以博彩软件和/或其源代码为基础开发衍生产品；或</p>\r\n<p align=\"left\">v. 		拷贝、修改、翻译或全部或部分地以博彩软件的相关用户文件为基础开发衍生产品。</p>\r\n<p align=\"left\">8.5</p>\r\n<p align=\"left\">用户承认並同意，博彩网站上提供的及或通过联连设备或其他方式提供的博彩软件或博彩软件用户方件均归 		太阳城娱乐网 		和其许可人所有，並受着作权、商标权和其他知识产权和专利权的保护。用户特此承认，博彩软件的结构、组织和源代码为 		太阳城娱乐网 		和其许可人的极具价值的商业秘密。用户承认除根据使用权向用户授予的权利外，用户对博彩软件和/或博彩软件用户文件不享有任何权利和权益。</p>\r\n<p align=\"left\">8.6</p>\r\n<p align=\"left\">本协议因任何原因终止，本协议顶下所授予的使用权自动作废，用户应停止使用博彩软件並将博彩软件从联连设备中卸载。 <strong></strong></p>\r\n<p align=\"left\"><strong>9.</strong> <strong>交易结算</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">9.1</p>\r\n<p align=\"left\">用户使用信用卡或借记卡的，持卡人姓名须与会员登记和申请过程中所使用的姓名一致。若发生持卡人姓名和账户登记和会员申请所使用的姓名不一致的情况， 		太阳城娱乐网 		有权拒絕就相关交易进行结算。</p>\r\n<p align=\"left\">9.2</p>\r\n<p align=\"left\">用户承担向 太阳城娱乐网 		和其他用户（视具体情况而定）支付所有应付款项的一切责任。用户同意对任何付款不实施或促使他人实施退款，不拒絕或撤销付款，並向 		太阳城娱乐网 		偿付所有被退还、拒絕或撤销的付款以及由此引起的所有损失和费用。 		太阳城娱乐网 		，根据自主判断，有权终止向个別用户或使用某类信用卡或借记卡付款的用户提供服务或支付款项。</p>\r\n<p align=\"left\">9.3</p>\r\n<p align=\"left\">任何经 太阳城娱乐网 认可的有效：</p>\r\n<p align=\"left\">. 		体育博彩(Sportsbook)下注的最高彩金将根据不同盘口而定。</p>\r\n<p align=\"left\">i. 真人娱乐场 (Live Casino) 		下注的最高彩金将根据不同游戏而定 		(或根据当日所公布的汇率不时确定的其他等额货币。)</p>\r\n<p align=\"left\">9.4</p>\r\n<p align=\"left\">彩金不包括下注额。</p>\r\n<p align=\"left\">9.5</p>\r\n<p align=\"left\">任何款项或彩金在存入帐户的过程中发生错误， 		太阳城娱乐网 		不负任何形式的任何责任，且 		太阳城娱乐网 		有权在任何时候或在事后宣布涉及该等款项的交易无效。用户一旦发现账户內款项汇存有误，有责任立即通知 		太阳城娱乐网 。</p>\r\n<p align=\"left\">9.6</p>\r\n<p align=\"left\">在任何适用法律下就彩金所应缴付的税款和费用均由用户自行负责缴付。 <strong></strong></p>\r\n<p align=\"left\"><strong>10.</strong> <strong>领取彩金</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">10.1</p>\r\n<p align=\"left\">用户的彩金经结算后，将存入用户账户，具体提取办法参照我们彩金提取规定並须出示我们认可的有效带照身份证和/或信用/借记卡。</p>\r\n<p align=\"left\">10.2</p>\r\n<p align=\"left\">根据监管政策的要求及运营的需要，我们在处理您的提款前，您将可能需要提供相关证件信息给KYC【客户身份识别】部门进行身份验证。一旦需要，KYC部门将会主动通过邮件的方式向您提出申请，验证完成后将不需要再次提供。</p>\r\n<p align=\"left\">10.3</p>\r\n<p align=\"left\">在用户所持的信用/借记卡发行银行允许的情况下，彩金可以直接存入用户交纳押金所用的信用/借记卡账户。支票或电汇的收款人以登记或申请会员时所用的姓名为准。以信用卡或借记卡支付押金的，收款人还必须是信用卡或借记卡的登记持卡人。</p>\r\n<p align=\"left\">10.4</p>\r\n<p align=\"left\">投注额必须与存款额相同才能进行提款， 		太阳城娱乐网 		将保留权利，收取必要的提款和存款手续费。</p>\r\n<p align=\"left\">10.5</p>\r\n<p align=\"left\">太阳城娱乐网 		因用户的博彩交易而蒙受的所有银行收费均由用户承担和偿付， 		太阳城娱乐网 		有权从用户彩金或账户中扣除和抵扣上述收费。</p>\r\n<p align=\"left\">10.6</p>\r\n<p align=\"left\">所有拒绝投注、无效投注、打平或是任何出现对赌情况的投注 		（例：於百家乐同时下注庄家及閒家或於轮盘同时下注红及黑等情况），並且赔率不包括本金之下低于0.50，将不计算在任何累积投注要求内。 <strong></strong></p>\r\n<p align=\"left\"><strong>11.</strong> <strong>促销和奖励</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">11.1</p>\r\n<p align=\"left\">所有促销、奖励和特价均须遵守本条规及 		太阳城娱乐网 		针对具体促销活动所不时制定的规定。 		太阳城娱乐网 		保留在任何时候中止、取消或修改该等奖励或促销和/或其相关规定及条款的权力。</p>\r\n<p align=\"left\">11.2</p>\r\n<p align=\"left\">若 太阳城娱乐网 		认定有人滥用或企图滥用某项奖励或促销活动，或可能因该等滥用行为而获利，我们有权自主决定以其认为合适的方式阻止、拒絕，中止、或撤消任何用户参加有关奖励或促销活动.</p>\r\n<p align=\"left\">11.3</p>\r\n<p align=\"left\">如发现任意带有串通勾结以及试图欺诈等嫌疑的个人或团队，我们将保留取消其部份或全部投注的权利。所涉及的个人，亲属，组织，博彩庄家及其员工帐户中的金额会将被立即查封没收。</p>\r\n<p align=\"left\">11.4</p>\r\n<p align=\"left\">作为服务性娱乐网站，太阳城娱乐网 		所公布的服务和优惠活动仅适用于真实玩家，而针对非真实玩家我们的服务与优惠活动将酌情进行调整。 		<br /> 真实的玩家是指真正参与游戏进行有风险的投注，以游戏结果为赢利目的的玩家。 <strong></strong></p>\r\n<p align=\"left\"><strong>12.</strong> <strong>赔偿</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">12.1</p>\r\n<p align=\"left\">用户同意，由于用户连接博彩网站、下载或安装博彩软件、下注和/或以其他方式使用博彩服务、博彩软件和/或博彩资讯、及/或违背本条规和/或博彩规则，而对 		太阳城娱乐网 		、其股东、雇员、管理人员、董事、受许可方、经销商、关联方、子公司和或代理商造成的任何损失、损害或及索赔 		(包括合理的律师费) 		，用户须予以全额赔偿。 <strong></strong></p>\r\n<p align=\"left\"><strong>13.</strong> <strong>免责声明及特別注意事项</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">13.1</p>\r\n<p align=\"left\">博彩完全是一项个人选择，以个人判断与分析为依据，且风险自负的行为。用户下注的同时，即表明用户承认博彩服务、博彩网站和博彩资讯並无冒犯性，且並不令人反感、不公平或有悖公共道德。一些司法管辖区对网上及/或岸外网上博彩的合法性尚无定论；而另一些司法管辖区则明确规定网上博彩（在司法管辖区域內和/或岸外）均属非法行为。我们不鼓励任何人在非法的情况下使用和连接博彩网站、博彩资讯和/或博彩服务。博彩服务、博彩资讯和博彩网站的设立和提供並不构成我们发出要约、招揽或邀请任何人在那些规定使用或连接上述內容为非法行为的国家內使用或连接上述內容。用户独立承担遵守其所适用之相关法律规定的责任，而 		太阳城娱乐网 		不就博彩服务、博彩软件、博彩网站或其中的博彩资讯与用户所适用的法律规定相符作出任何声明。</p>\r\n<p align=\"left\">13.2</p>\r\n<p align=\"left\">博彩服务、博彩软件、博彩网站和博彩资讯均按「原状原则」提供。除本条规明示的外， 		太阳城娱乐网 		不就博彩服务、博彩网站、博彩软件和博彩资讯作出任何声明或保证。故所有有关博彩服务、博彩软件、博彩网站和博彩资讯的声明或保证，不论明示或暗示、法定与否，特此在法律允许的最大范围內予以排除。 		太阳城娱乐网 		不就博彩服务、博彩软件、博彩网站或博彩资讯的准确性、及时性、安全性、连续性、正确性或抗外界干扰性（任何性质），以及更正所发现的任何缺陷作出保证。 		太阳城娱乐网 		亦不保证博彩服务、博彩软件、博彩网站和博彩资讯或提供上述內容的服务器不含有任何病毒、间谍软件、广告软件或其他具恶意性、破坏性或可导致电脑瘫痪的代码、程序、数据、宏指令或可影响任何联接设备和/或其中所存数据的其他软件或特性。用户承诺将自行自费采取预防措施，确保其使用或连接博彩服务所用的过程、方法和/或联接设备、以及博彩软件的安装和博彩网站的使用，均不会带来电脑病毒、间谍软件、广告软件或具恶意性、破坏性或可导致电脑瘫痪的其他代码，或导致其联接设备或其中所存数据受到干扰和破坏的其他风险。</p>\r\n<p align=\"left\">13.3</p>\r\n<p align=\"left\">若发生与账户结算或博彩服务的其他方面有关的系统错误或通讯错误， 		太阳城娱乐网 		不承担由此引起的任何责任。在此情况下， 		太阳城娱乐网 		有权取消所有受上述错误影响的下注並采取任何更正行动。</p>\r\n<p align=\"left\">13.4</p>\r\n<p align=\"left\">在任何情况下，因用户连接、使用或参与博彩服务、博彩网站、博彩软件和博彩资讯而发生任何损害、损失或支出，包括用户之联接设备或所存数据受到任何干扰或破坏， 		太阳城娱乐网 		不承担任何责任。此外，对博彩服务、博彩网站、博彩软件和博彩资讯中由第三方(包括但不限于宽带和电信服务供应商)所提供的內容， 		太阳城娱乐网 		亦不作任何保证和声明且不予负责；在任何情况下， 		太阳城娱乐网 		均不对上述第三方合作者的任何违约、过错或不作为承担责任。</p>\r\n<p align=\"left\">13.5</p>\r\n<p align=\"left\">在任何情况下， 太阳城娱乐网 		、其关联公司、关联方、合伙人、管理人员、雇员和代理均不对任何损害、损失或支出承担责任。上述包括但不限于因用户连接或使用博彩服务、博彩网站、博彩软件和博彩资讯、或与用户连接或使用博彩服务、博彩网站、博彩软件和博彩资讯有关的、或因用户下载、安装或使用博彩软件所引起的任何直接、间接、因果性或特別的损害或经济损失，不论 		太阳城娱乐网 		是否被告知可能发生上述损害、损失或支出。在任何情况下，就与用户下注直接相关的任何事宜、事件或情形所引起或与之相关的任何损失或损害(不论是否基于合约、侵权、严格责任或其他原因)，在法律允许的最大范围內， 		太阳城娱乐网 		对用户的全部责任(如有)应不超过用户的相应下注额。</p>\r\n<p align=\"left\">13.6</p>\r\n<p align=\"left\">用户承认，博彩资讯在性质上可能全部或部分地具有临时性，並且可按本条规予以修订、修改或更改。因此，用户承认博彩资讯仅为参考之用，不构成任何建议、意见或招揽，不构成任何具约束力的声明、保证、合约义务或用户依据的內容和基础。</p>\r\n<p align=\"left\">13.7</p>\r\n<p align=\"left\">用户特此承认並同意，在考虑所有相关因素，包括但不限于用户向 		太阳城娱乐网 		提供对价的价值后，本条规所述之所有责任豁免和义务排除代表用户和 		太阳城娱乐网 		协议中公平、合理的风险分担和利益分配。用户进一步同意上述免责和限制在适用法律允许的最大范围內具有强制执行力。</p>\r\n<p align=\"left\">13.8</p>\r\n<p align=\"left\">如果用户对任何博彩或比赛的结果存有异议，应在该等结果宣布之日后十四(14)天內向我们书面投诉。若出现用户联接设备所显示与 		太阳城娱乐网 		系统的交易记录中所存的交易结果不符的情况(儘管发生这种情况的可能性很小)，用户同意 		太阳城娱乐网 		系统中交易记录所记载的由我们的技术总监认证的交易结果应为该等结果具终局性的不容置疑的证据。 <strong></strong></p>\r\n<p align=\"left\"><strong>14.</strong> <strong>终止、关户及暂停博彩服务</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">14.1</p>\r\n<p align=\"left\">如有充分理由相信或证明以下情形，除本条款项下所享有的其他权利外， 		太阳城娱乐网 		有权，根据自主判断，宣布任何彩金无效並没收用户下注账户中所存余额、终止本协议和/或暂停提供博彩服务/冻结用户账户：</p>\r\n<p align=\"left\">. 用户在 太阳城娱乐网 		拥有不止一个活动账户；</p>\r\n<p align=\"left\">i. 用户姓名与向 太阳城娱乐网 		进行购卖或支付押金所用的信用卡或借记卡或其他付款账户的持有人姓名不符；</p>\r\n<p align=\"left\">ii. 用户参与 太阳城娱乐网 		促销並在未满足促销要求之前退出该促销；</p>\r\n<p align=\"left\">iii. 用户提供不正确或误导性的注册信息；</p>\r\n<p align=\"left\">iv. 用户未提供或遗漏提供必要的身份资料；</p>\r\n<p align=\"left\">v. 用户不满法定年龄；</p>\r\n<p align=\"left\">vi. 		用户连接和使用博彩服务所在的地区在法律上禁止使用博彩服务；</p>\r\n<p align=\"left\">vii. 		用户对我们实施或促使他人对我们实施「退款「，或否认以其账户名义进行的任何交易或押金；</p>\r\n<p align=\"left\">viii. 		用户押金来源于刑事犯罪或其他非法或未经授权的活动；</p>\r\n<p align=\"left\">ix. 		用户被发现欺诈或企图欺诈任何人或已经对任何人实施欺诈，或经 		太阳城娱乐网 		认定用户使用专门设计用以干扰/捣毁系统之人工智能或其他系统(包括机械、电脑、软件或其他自动化系统)，或被发现与其他博彩玩客勾结或企图与其他赌客勾结欺骗 		太阳城娱乐网 或其他博彩玩客；</p>\r\n<p align=\"left\">x. 用户允许(不论是否故意)他人使用其账户；</p>\r\n<p align=\"left\">xi. 用户未遵守本协议项下的任何使用规定；</p>\r\n<p align=\"left\">xii. 		用户未披露其位置在菲律宾、台湾、美国、新加坡及香港境內的事实。</p>\r\n<p align=\"left\">14.2</p>\r\n<p align=\"left\">若我们按第14.1条规定暂停提供博彩服务和/或冻结账户，在用户实施必要的纠正措施 		(如果可以纠正)，且我们确认完全满意用户的纠正措施之后，博彩服务和用户账户将被恢复和解冻。 <strong></strong></p>\r\n<p align=\"left\"><strong>15.</strong> <strong>与外部网站的链接</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">15.1</p>\r\n<p align=\"left\">博彩网站可能含有与並非 太阳城娱乐网 		维护的外部网站的链接。与外部网站的链接仅为用户方便而提供， 		太阳城娱乐网 		不承诺确保上述链接所含內容的准确性、时效性或被维护，且不就此承担任何责任。</p>\r\n<p align=\"left\">15.2</p>\r\n<p align=\"left\">太阳城娱乐网 		不就外部网站的內容资讯或隐私保护政策或在外部网站宣传、出售或以其他方式开放的任何产品或服务承担任何责任、负责提供或审查、予以批准或核准、或作出任何声明或保证。</p>\r\n<p align=\"left\">15.3</p>\r\n<p align=\"left\">太阳城娱乐网 		不就用户因使用博彩网站所提供的任何外部网站链接而发生的或与之相关的任何损失或损害承担合约、侵权、疏忽或其他责任。</p>\r\n<p align=\"left\">15.4</p>\r\n<p align=\"left\">除非明文规定，否则 太阳城娱乐网 		在任何情况下均不得被视为与外部网站上的任何声明、意见、产品或服务商标、标记、标志或其他图案、在外部网站宣传、出售或以其他方式开放的任何产品或服务、外部网站的经营者或所有者、或以任何方式与外部网站相关的任何人具有任何关係或联系。 <strong></strong></p>\r\n<p align=\"left\"><strong>16.</strong> <strong>与博彩网站的链接</strong> <strong>/</strong> <strong>框入</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">16.1</p>\r\n<p align=\"left\">用户不得就博彩网站或博彩服务的任何部分设置链接、深链接或文中链接(deep 		or in-line links)、或框入(frame)博彩资讯。 <strong></strong></p>\r\n<p align=\"left\"><strong>17.</strong> <strong>增加或中断博彩种类</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">17.1</p>\r\n<p align=\"left\">我们保留自行决定，不经通知用户，于任何时候在博彩网站增加新的博彩种类或功能，或开始、停止、中断、限制联接或修改任何博彩种类或功能的权利，且不就此对任何人承担任何责任。 <strong></strong></p>\r\n<p align=\"left\"><strong>18.</strong> <strong>违反本条规</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">18.1</p>\r\n<p align=\"left\">太阳城娱乐网 		保留就违反本条规的行为依法寻求救济（法律及衡平法）的权 		利，包括自行决定在任何时候基于任何理由拒絕或限制任何特定的人联接博 		彩服务、博彩网站和博彩资讯、阻止通过特定互联网地址或联接设备联接博彩服务、博彩网站和博彩资讯的权利。 <strong></strong></p>\r\n<p align=\"left\"><strong>19.</strong> <strong>优先顺序</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">19.1</p>\r\n<p align=\"left\">博彩规则 (若适用) 		和适用于使用和联接博彩服务、博彩软件、博彩资讯和博彩网站的任何其他条规均构成本条规的组成部分。</p>\r\n<p align=\"left\">19.2</p>\r\n<p align=\"left\">若博彩规则和适用于使用和联接博彩服务、博彩软件、博彩资讯和博彩网站的任何其他条规与本条规存有抵触，则除非另行明文规定，否则以本条规为准。 <strong></strong></p>\r\n<p align=\"left\"><strong>20.</strong> <strong>不可抗力</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">20.1</p>\r\n<p align=\"left\">若 太阳城娱乐网 		由于发生下列其无法控制的任何性质的事件 		(包括但不限于天灾、适用法律法规的变更、政府、民政或军事机关的作为或不作为、法院命令、恐怖活动、闪电或火灾、罢工、停工或其他劳资纠纷、洪水、干旱、战争、暴乱、盗窃、传输或系统故障、通讯或宽带服务故障或中断、电力供应或设备故障或不足、恶劣气候、地震和自然灾害)未能或迟延履行本条规所规定的任何义务，不构成违反本条规。用户同意采取一切必要行动儘量减轻上述事件的后果。 <strong></strong></p>\r\n<p align=\"left\"><strong>21.</strong> <strong>弃权</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">21.1</p>\r\n<p align=\"left\">太阳城娱乐网 		在任何时候未能执行本条规任何条款不可视为放弃本条规所规定的权利或以任何方式影响本条规全部或部分的有效性，且不影响 		太阳城娱乐网 采取进一步行动的权利。 <strong></strong></p>\r\n<p align=\"left\"><strong>22.</strong> <strong>可分割性</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">22.1</p>\r\n<p align=\"left\">若任何条款或其任何部分被有关机关认定为在任何程度上无效、不合法或不可执行，则该条款或该部分在上述程度上与其他条款分割，其他条款在法律允许的范围內继续完全有效。 <strong></strong></p>\r\n<p align=\"left\"><strong>23.</strong> <strong>适用法律和管辖</strong></p>\r\n<ul>\r\n</ul>\r\n<p align=\"left\">23.1</p>\r\n<p align=\"left\">用户同意，用户联接和使用博彩服务、博彩网站、博彩软件、博彩资讯及有关本条规的解释适用菲律宾法律，並按菲律宾法律解释。</p>\r\n<p align=\"left\">23.2</p>\r\n<p align=\"left\">因本条规发生或与本条规有关的任何争议：</p>\r\n<p align=\"left\">. 若由用户提起，则提交菲律宾 First 		Cagayan公司卡卡湾经济区管理局 (Cagayan Economic Zone Authority, First Cagayan Leisure 		and Resort Corporation) 互动游戏主许可人最终解决。</p>\r\n<p align=\"left\">i. 若由 太阳城娱乐网 提起，则由 		太阳城娱乐网 自行选择：</p>\r\n<p align=\"left\">a.根据以上第23.2(i) 		条的规定提请仲裁最终解决。</p>\r\n<p align=\"left\">b.向用户同意的菲律宾法院提起诉讼或申请，但 		太阳城娱乐网 		在其他法律管辖区提起诉讼或法律程序的权利不受影响。</p>\r\n</div>','',1,0,0,2,'2012-02-25 08:19:34',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2012-02-25 08:19:34','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',2,0,2,'','',1,3,'',0,'*',''),(57,90,'关于我们','2012-03-03-10-07-32','','<div>\r\n<p>Sun 		City集团为正式注册的网上博彩公司。成立至今，我们不但为客户提供多元化网上娱乐，更承诺配备最优质的投注方法，並辅以最先进的网络技术支援，献上最佳的客户服务和最优惠的支付方案。我们致力于为广大客户提供丰富精彩的博彩活动，並极力以最优质的收费方式及丰富奖赏作回馈。</p>\r\n<p>太阳城的合法网上娱乐埸牌照是由菲律宾政府唯一认可的发牌及监管单位FCLRC(First 		Cagayan Leisure and Resort Corporation 		)签发，FCLRC为卡加延特别经济区及自由港(CSEZFP)之互动总发牌及监管单位，严格要求持牌公司必须使用经 		批准软件，并定时审查各公司的运作情况，确保客户使用的平台达到公平及安全的要求，保证客户与太阳城公司之间的公平 		与公正，这已充份彰显太阳城的公正素质及能力。</p>\r\n<p><img src=\"images/stories/about-us.jpg\" border=\"0\" /></p>\r\n</div>\r\n<div>\r\n<p>菲律宾太阳城是亚洲区规模庞大、最受玩家欢迎的的互联网真人游戏和电子游戏社区之一，致力於互联网为用户提供多 		元化的电子娱乐服务.从2005年开始服务赌城玩家后，我们一直有惊人的成长。一年多来，太阳城一直孜孜不倦地追求技术创 		新，依托强大的技术团队，致力於为用户提高质数的娱乐服务。截止到2006年第三季度，太阳城对真人游戏社区建设投资超 		过五千万港元，拥有超过一千万注册帐户。时至今日，我们於服务水平及客户满意度方面亦已竖立威信，通过强大的游戏营 		运能力，周到的客户服务能力，完善的技术保障和支持能力，高效健全的支付平台，形成了面向用户的综合性互动电子游戏 		平台。各年龄层的玩家均可籍由太阳城真人互动游戏平台与其它成千上万的玩家进行互动，体验互动电子娱乐带来的乐趣。 		作为太阳城实现\"全球最大的真人游戏平台\"的战略目标的重要部分，我们通过对软硬件、内容、网络以及服务的整合，为 		用户提供更高质的娱乐服务！</p>\r\n</div>','',1,0,0,2,'2012-03-03 10:03:35',62,'','2012-04-19 12:36:31',0,0,'0000-00-00 00:00:00','2012-03-03 10:03:35','0000-00-00 00:00:00','','','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_section\":\"\",\"link_section\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_vote\":\"\",\"show_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_pdf_icon\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"language\":\"\",\"keyref\":\"\",\"readmore\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"link_author\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,0,1,'','',1,1,'',0,'*',''),(58,35,'test','test','','<p>1</p>\r\n<hr title=\"1\" class=\"system-pagebreak\" />\r\n<p>2</p>\r\n<hr title=\"2\" class=\"system-pagebreak\" />\r\n<p> </p>','',-2,0,0,2,'2012-04-19 15:26:38',42,'','0000-00-00 00:00:00',0,0,'0000-00-00 00:00:00','2012-04-19 15:26:38','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":null,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":null,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":null,\"urlctext\":\"\",\"targetc\":\"\"}','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,0,0,'','',1,4,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(59,47,'Home','home','','<div></div>','',1,0,0,10,'2012-04-30 14:28:34',42,'','0000-00-00 00:00:00',0,0,'0000-00-00 00:00:00','2012-04-30 14:28:34','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":null,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":null,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":null,\"urlctext\":\"\",\"targetc\":\"\"}','{\"show_title\":\"0\",\"link_titles\":\"0\",\"show_intro\":\"0\",\"show_category\":\"0\",\"link_category\":\"0\",\"show_parent_category\":\"0\",\"link_parent_category\":\"0\",\"show_author\":\"0\",\"link_author\":\"0\",\"show_create_date\":\"0\",\"show_modify_date\":\"0\",\"show_publish_date\":\"0\",\"show_item_navigation\":\"0\",\"show_icons\":\"0\",\"show_print_icon\":\"0\",\"show_email_icon\":\"0\",\"show_vote\":\"0\",\"show_hits\":\"0\",\"show_noauth\":\"0\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"0\",\"show_article_options\":\"0\",\"show_urls_images_backend\":\"0\",\"show_urls_images_frontend\":\"0\"}',1,0,0,'','',1,85,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(60,58,'开户礼金','account-gifts','','<div id=\"offers-content-banner\" class=\"clearfix\">\r\n<div class=\"banner\">&nbsp;</div>\r\n<div class=\"links\"><a href=\"index.php?option=com_content&amp;view=article&amp;id=60&amp;Itemid=104\" class=\"item item1 active\">link</a> <a href=\"index.php?option=com_content&amp;view=article&amp;id=61&amp;Itemid=136\" class=\"item item2\">link</a> <a href=\"index.php?option=com_content&amp;view=article&amp;id=62&amp;Itemid=137\" class=\"item item3\">link</a></div>\r\n</div>\r\n<div>\r\n<h1 align=\"left\">新会员开户成功后的首次存款可选择申请充值金额的 10% 或 30% 礼金</h1>\r\n<p align=\"left\">注意事项:</p>\r\n<p align=\"left\">1. 网站没有规定开户同时必须申请首存优惠，会员可以保留申请此优惠的权利，均可联系在线客服办理优惠申请。（注:必须是第一笔提款之前申请）</p>\r\n<p align=\"left\">2. 享受10%首存礼金后，有效投注额达到存款加礼金的6倍即可申请提款；享受30%首存礼金后，有效投注额达到存款礼金的20倍即可申请提款。</p>\r\n<img src=\"images/credit_table.jpg\" alt=\"\" />\r\n<p align=\"left\">&nbsp;</p>\r\n<p align=\"left\">3. 同一IP、同一会员、同一姓名的收款帐号，只能享受一次首存礼金</p>\r\n<p align=\"left\">4. 开户优惠是不能与洗码优惠同一周享受，会员可以在一周结束后，申请选择其中最大的优惠方式</p>\r\n<p align=\"left\">5. 我们将会员为新帐户充值后的第一笔投注之前的存款看作\"首次存款\"（例如：会员可以分多笔存入款项五万，如果会员在五万存款到帐之前没有参加投注，也没有申请提款，那么这五万即为\"首次存款\"）</p>\r\n<p align=\"left\">6. 如何添加:联系在线客服申请,彩金部门在10-15分钟内审核通过后添加到帐</p>\r\n</div>','',1,0,0,13,'2012-05-05 03:23:25',42,'','2012-05-05 04:46:59',42,0,'0000-00-00 00:00:00','2012-05-05 03:23:25','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":null,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":null,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":null,\"urlctext\":\"\",\"targetc\":\"\"}','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',11,0,1,'','',1,86,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(61,59,'高额洗码','2012-05-05-04-03-26','','<div id=\"offers-content-banner\" class=\"clearfix\">\r\n<div class=\"banner\">&nbsp;</div>\r\n<div class=\"links\"><a href=\"index.php?option=com_content&amp;view=article&amp;id=60&amp;Itemid=104\" class=\"item item1\">link</a> <a href=\"index.php?option=com_content&amp;view=article&amp;id=61&amp;Itemid=136\" class=\"item item2 active\">link</a> <a href=\"index.php?option=com_content&amp;view=article&amp;id=62&amp;Itemid=137\" class=\"item item3\">link</a></div>\r\n</div>\r\n<div>\r\n<h1>太阳城娱乐场更为一直以来支持和关注本公司的新老会员准备了丰厚的洗码回水大礼。</h1>\r\n<h1>洗码是指会员下注有效投注额的退水，不论输赢，只要进行有效投注即可享受洗码(退水)优惠。</h1>\r\n<p>1.所有在太阳城娱乐场注册的真钱会员都享有周有效投注额0.4%的洗码</p>\r\n<p>2.一周内有效投注额达到50万人民币（或首次开户存款5000元，并全额投注），可以享受0.6%的洗码优惠。</p>\r\n<p>3.一周内有效投注额达到300万人民币（或首次开户存款80000元，并全额投注），即为我们的VIP会员，无论每周投注多少都可终身享受0.8%的洗码优惠，并享有随时结算洗码的权利。</p>\r\n<p>4.太阳城将在每周一中午12点开始对上周符合洗码优惠赠送的会员进行结算，并在16点前自动将达到结算条件的会员洗码返点添加到会员的真钱账号上。添加完成后会电话短信通知会员！</p>\r\n<p>有效投注额累计时间为一周，一周是以美东时间的礼拜一到礼拜日为准，（北京时间则为周一中午12点到次周一的中午12点），每周一上午12点后开始对上周达到洗码标准的会员进行结算，如一周内达不到洗码标准（有效投注额10万），则没有洗码结算的。下周将会从零算起，重新累计。上一周的投注金额不能累计至下一周。会员享受了洗码优惠后，可以选择继续投注或是申请提款，洗码提款是不受任何限制的。</p>\r\n<h1>优惠条款细则：</h1>\r\n<p>1.洗码回水优惠以单个会员账号的有效投注额进行结算。</p>\r\n<p>2.只有有效投注额才能享受优惠（无效投注包括在游戏中下注和局、游戏结果为和局、同一局游戏中下注正、反两种结果:如百家乐游戏同一局下注庄闲）。</p>\r\n<p>3.若系统侦测玩家以不正常手段来进行游戏，一经查证属实，会员账号将被永久锁定并取消优惠 。</p>\r\n<p>4.如发现玩家使用不正当手段谋取我们的优惠奖励，太阳城娱乐场将保留取消该玩家获得促销奖励的权利。</p>\r\n<p>如出现争执，太阳城娱乐场的所有决定将是最终决定，会员参加任何优惠活动则被视为认可并同意遵守规则以及太阳城娱乐城有关规定，愿意受其约束，本公司保留最终解释权。</p>\r\n<h2>感谢新老会员对太阳城娱乐场的关注和支持，祝您财源广进，盈利多多。</h2>\r\n</div>','',1,0,0,13,'2012-05-05 03:26:23',42,'','2012-05-05 04:58:22',42,0,'0000-00-00 00:00:00','2012-05-05 03:26:23','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":null,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":null,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":null,\"urlctext\":\"\",\"targetc\":\"\"}','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',9,0,2,'','',1,55,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(62,60,'保险礼金','2012-05-05-04-04-07','','<div id=\"offers-content-banner\" class=\"clearfix\">\r\n<div class=\"banner\">&nbsp;</div>\r\n<div class=\"links\"><a href=\"index.php?option=com_content&amp;view=article&amp;id=60&amp;Itemid=104\" class=\"item item1\">link</a> <a href=\"index.php?option=com_content&amp;view=article&amp;id=61&amp;Itemid=136\" class=\"item item2\">link</a> <a href=\"index.php?option=com_content&amp;view=article&amp;id=62&amp;Itemid=137\" class=\"item item3 active\">link</a></div>\r\n</div>\r\n<div>\r\n<p>保险礼金活动从发布至今，一直广受各位新老客户的欢迎，本公司为感谢新老客户的厚爱将继续延续此活动！ 活动期间，凡充值并全额投注，出现负盈利的会员，都会得到以下比例的保险投注反利。让您有机会返本盈利。 祝您投注愉快，盈利多多。</p>\r\n<h1 align=\"left\">（保险投注）赠送细则：</h1>\r\n<p align=\"left\">活动时间：2012年12月16日起 （具体结束时间以新活动开启为准）</p>\r\n<p align=\"left\">只需全额投注即可享受保险礼包，凡是达到赠送礼金条件的用户我们将在次日下午16:00前将礼金自动结算添加到真钱游戏账号（礼金额度5倍投注即可提款）。具体赠送标准如下：</p>\r\n<img src=\"images/profit_table.jpg\" alt=\"\" />\r\n<h1 align=\"left\">活动条款： <strong> </strong> <strong></strong></h1>\r\n<p align=\"left\">1.玩家只有在活动期间内才有资格获得到此回赠礼包。</p>\r\n<p align=\"left\">2.每位玩家、每户、每一住址、每一电子邮箱地址、每一电话号码、相同支付方式(相同支付卡/信用卡号码)、相同提款账号及共享电脑环境(例如学校、公共图书馆及工作办公场所等)每天只能享受一次优惠。</p>\r\n<p align=\"left\">3.此活动可与本网站其它活动同时享受。</p>\r\n<p align=\"left\">4.如发现个人或团体，有以骗取活动奖金为目的的行为, 本公司将保留取消、收回优惠及产生的红利等，太阳城线上娱乐城的所有决定将是最终决定；</p>\r\n<p align=\"left\">5.本公司可在任何时候终止或修改所有活动规则及内容，最终解释权归本公司所有。</p>\r\n</div>','',1,0,0,13,'2012-05-05 03:28:28',42,'','2012-05-05 06:50:21',42,0,'0000-00-00 00:00:00','2012-05-05 03:28:28','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":null,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":null,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":null,\"urlctext\":\"\",\"targetc\":\"\"}','{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',12,0,0,'','',1,38,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*','');
/*!40000 ALTER TABLE `uxlo0_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_content_frontpage`
--

DROP TABLE IF EXISTS `uxlo0_content_frontpage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_content_frontpage` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_content_frontpage`
--

LOCK TABLES `uxlo0_content_frontpage` WRITE;
/*!40000 ALTER TABLE `uxlo0_content_frontpage` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_content_frontpage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_content_rating`
--

DROP TABLE IF EXISTS `uxlo0_content_rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_content_rating` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `rating_sum` int(10) unsigned NOT NULL DEFAULT '0',
  `rating_count` int(10) unsigned NOT NULL DEFAULT '0',
  `lastip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_content_rating`
--

LOCK TABLES `uxlo0_content_rating` WRITE;
/*!40000 ALTER TABLE `uxlo0_content_rating` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_content_rating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_core_log_searches`
--

DROP TABLE IF EXISTS `uxlo0_core_log_searches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_core_log_searches` (
  `search_term` varchar(128) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_core_log_searches`
--

LOCK TABLES `uxlo0_core_log_searches` WRITE;
/*!40000 ALTER TABLE `uxlo0_core_log_searches` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_core_log_searches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_djimageslider`
--

DROP TABLE IF EXISTS `uxlo0_djimageslider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_djimageslider` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`,`published`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_djimageslider`
--

LOCK TABLES `uxlo0_djimageslider` WRITE;
/*!40000 ALTER TABLE `uxlo0_djimageslider` DISABLE KEYS */;
INSERT INTO `uxlo0_djimageslider` VALUES (1,9,'slide1','slide1','images/banner.jpg','',1,0,'0000-00-00 00:00:00',1,'{\"link_type\":\"\",\"link_menu\":\"101\",\"link_url\":\"\",\"link_article\":\"\"}'),(2,11,'game1','game1','images/game1.jpg','',1,0,'0000-00-00 00:00:00',2,'{\"link_type\":\"article\",\"link_menu\":\"105\",\"link_url\":\"\",\"link_article\":\"47\"}'),(3,11,'game2','game2','images/game2.jpg','',1,0,'0000-00-00 00:00:00',3,'{\"link_type\":\"article\",\"link_menu\":\"105\",\"link_url\":\"\",\"link_article\":\"46\"}'),(4,11,'game3','game3','images/game3.jpg','',1,0,'0000-00-00 00:00:00',4,'{\"link_type\":\"article\",\"link_menu\":\"105\",\"link_url\":\"\",\"link_article\":\"43\"}'),(5,11,'game4','game4','images/game4.jpg','',1,0,'0000-00-00 00:00:00',5,'{\"link_type\":\"article\",\"link_menu\":\"105\",\"link_url\":\"\",\"link_article\":\"46\"}'),(6,11,'game5','game5','images/game5.jpg','',1,0,'0000-00-00 00:00:00',6,'{\"link_type\":\"\",\"link_menu\":\"101\",\"link_url\":\"\",\"link_article\":\"\"}'),(7,11,'game6','game6','images/game6.jpg','',1,0,'0000-00-00 00:00:00',7,'{\"link_type\":\"\",\"link_menu\":\"101\",\"link_url\":\"\",\"link_article\":\"43\"}');
/*!40000 ALTER TABLE `uxlo0_djimageslider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_easybook`
--

DROP TABLE IF EXISTS `uxlo0_easybook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_easybook` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `gbip` varchar(15) NOT NULL DEFAULT '',
  `gbname` varchar(40) NOT NULL DEFAULT '',
  `gbmail` varchar(60) DEFAULT NULL,
  `gbmailshow` tinyint(1) NOT NULL DEFAULT '0',
  `gbloca` varchar(50) DEFAULT NULL,
  `gbpage` varchar(150) DEFAULT NULL,
  `gbvote` int(10) DEFAULT NULL,
  `gbtext` text NOT NULL,
  `gbdate` datetime DEFAULT NULL,
  `gbtitle` varchar(50) DEFAULT NULL,
  `gbcomment` text,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `gbicq` varchar(20) DEFAULT NULL,
  `gbaim` varchar(50) DEFAULT NULL,
  `gbmsn` varchar(50) DEFAULT NULL,
  `gbyah` varchar(50) DEFAULT NULL,
  `gbskype` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_easybook`
--

LOCK TABLES `uxlo0_easybook` WRITE;
/*!40000 ALTER TABLE `uxlo0_easybook` DISABLE KEYS */;
INSERT INTO `uxlo0_easybook` VALUES (1,'127.0.0.1','猫之良品','william0760@qq.com',1,NULL,NULL,0,':eek  :grin','2012-04-25 13:00:30',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL),(2,'127.0.0.1','猫之良品','william0760@qq.com',0,NULL,NULL,0,'8)  8)  8)','2012-04-28 13:34:30',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL),(3,'127.0.0.1','test','test@qq.com',0,'','',0,'留言本内容','2012-05-02 14:26:04','','管理员的回答是神圣的',1,'','','','',''),(4,'127.0.0.1','猫之良品','test@qq.com',0,NULL,NULL,0,'test','2012-05-06 08:58:40',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `uxlo0_easybook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_easybook_badwords`
--

DROP TABLE IF EXISTS `uxlo0_easybook_badwords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_easybook_badwords` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `word` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1387 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_easybook_badwords`
--

LOCK TABLES `uxlo0_easybook_badwords` WRITE;
/*!40000 ALTER TABLE `uxlo0_easybook_badwords` DISABLE KEYS */;
INSERT INTO `uxlo0_easybook_badwords` VALUES (2,'analdrilling'),(3,'20six'),(4,'ndsfrwudG'),(5,'Tadalafil'),(6,'hosting'),(7,'avacor'),(8,'gation'),(9,'ruptcy'),(10,'obli'),(11,'morta'),(12,'remoV'),(13,'fffd5'),(14,'ffffd5'),(15,'Wavefrt'),(16,'Cialis'),(17,'eyebrow-upper-left-corner'),(18,'B0000AZJVC'),(19,'right-topnav-default-2'),(20,'edit1'),(21,'display-variation'),(22,'erection'),(23,'wvvvvv'),(24,'mpage.jp'),(25,'20six.de'),(26,'o o o o o o o o o o o o o'),(27,'aasgeier'),(28,'abspritzer'),(29,'sdfds'),(30,'ackerfresse'),(31,'affenarsch'),(32,'affenhirn'),(33,'affenkotze'),(34,'afterlecker'),(35,'aktivex.info'),(36,'almosenarsch'),(37,'amazing'),(38,'am-sperma-riecher'),(39,'anal*'),(40,'analadmiral'),(41,'analbesamer'),(42,'analbohrer'),(43,'analdrill'),(44,'analentjungferer'),(45,'analerotiker'),(46,'analfetischist'),(47,'analförster'),(48,'anal-frosch'),(49,'analnegerdildo'),(50,'analratte'),(51,'analritter'),(52,'aok-chopper'),(53,'armleuchter'),(54,'arsch'),(55,'arschaufreißer'),(56,'arschbackenschänder'),(57,'arschbesamer'),(58,'ärsche'),(59,'arschentjungferer'),(60,'arschficker'),(61,'arschgeburt'),(62,'arschgefickte gummifotze'),(63,'arschgeige'),(64,'arschgesicht'),(65,'arschhaarfetischist'),(66,'arschhaarrasierer'),(67,'arschhöhlenforscher'),(68,'arschkrampe'),(69,'arschkratzer'),(70,'arschlecker'),(71,'arschloch'),(72,'arschlöcher'),(73,'arschmade'),(74,'arschratte'),(75,'arschzapfen'),(76,'arsebandit'),(77,'arsehole'),(78,'arsejockey'),(79,'arselicker'),(80,'arsenuts'),(81,'arsewipe'),(82,'assel'),(83,'assfuck'),(84,'assfucking'),(85,'assgrabber'),(86,'asshol'),(87,'asshole'),(88,'asshole'),(89,'assi'),(90,'assrammer'),(91,'assreamer'),(92,'asswipe'),(93,'astlochficker'),(94,'auspufflutscher'),(95,'bad motherfucker'),(96,'badass'),(97,'badenutte'),(98,'bananenstecker'),(99,'bastard'),(100,'bastard'),(101,'bauernschlampe'),(102,'beating the meat'),(103,'beef curtains'),(104,'beef flaps'),(105,'behindis'),(106,'bekloppter'),(107,'muttergeficktes'),(108,'beklopter'),(109,'bettnässer'),(110,'betrüger'),(111,'Betrüger'),(112,'bettpisser'),(113,'bettspaltenficker'),(114,'biatch'),(115,'bimbo'),(116,'bitch'),(117,'bitches'),(118,'bitchnutte'),(119,'bitsch'),(120,'bizzach'),(121,'blechfotze'),(122,'blödmann'),(123,'blogspoint'),(124,'blow job'),(125,'bohnenfresser'),(126,'boob'),(127,'boobes'),(128,'boobie'),(129,'boobies'),(130,'boobs'),(131,'booby'),(132,'boy love'),(133,'breasts'),(134,'brechfurz'),(135,'bückfleisch'),(136,'bückstück'),(137,'bückvieh'),(138,'buggery'),(139,'bullensohn'),(140,'bullshit'),(141,'bummsen'),(142,'bumsen'),(143,'bumsklumpen'),(144,'buschnutte'),(145,'busty'),(146,'butt pirate'),(147,'buttfuc'),(148,'buttfuck'),(149,'buttfucker'),(150,'buttfucking'),(151,'carpet muncher'),(152,'carpet munchers'),(153,'carpetlicker'),(154,'carpetlickers'),(155,'chausohn'),(156,'clitsuck'),(157,'clitsucker'),(158,'clitsucking'),(159,'cock'),(160,'cock sucker'),(161,'cockpouch'),(162,'cracka'),(163,'crap'),(164,'craper'),(165,'crapers'),(166,'crapping'),(167,'craps'),(168,'cunt'),(169,'cunt'),(170,'cunts'),(171,'dachlattengesicht'),(172,'dackelficker'),(173,'dickhead'),(174,'dicklicker'),(175,'diplomarschloch'),(176,'doofi'),(177,'douglette'),(178,'drecksack'),(179,'drecksau'),(180,'dreckschlitz'),(181,'dreckschüppengesicht'),(182,'drecksfotze'),(183,'drecksmösendagmar'),(184,'drecksnigger'),(185,'drecksnutte'),(186,'dreckspack'),(187,'dreckstürke'),(188,'dreckvotze'),(189,'dumbo'),(190,'dummschwätzer'),(191,'dumpfbacke'),(192,'dünnpfifftrinker'),(193,'eichellecker'),(194,'eierkopf'),(195,'eierlutscher'),(196,'eiswürfelpisser'),(197,'ejaculate'),(198,'entenfisterer'),(199,'epilepi'),(200,'epilepis'),(201,'epileppis'),(202,'fagette'),(203,'fagitt'),(204,'fäkalerotiker'),(205,'faltenficker'),(206,'fatass'),(207,'ferkelficker'),(208,'ferkel-ficker'),(209,'fettarsch'),(210,'fettsack'),(211,'fettsau'),(212,'feuchtwichser'),(213,'fick'),(214,'fick*'),(215,'fickarsch'),(216,'fickdreck'),(217,'ficken'),(218,'ficker'),(219,'fickfehler'),(220,'fickfetzen'),(221,'fickfresse'),(222,'fickfrosch'),(223,'fickfucker'),(224,'fickgelegenheit'),(225,'fickgesicht'),(226,'fickmatratze'),(227,'ficknudel'),(228,'ficksau'),(229,'fickschlitz'),(230,'fickschnitte'),(231,'fickschnitzel'),(232,'fingerfuck'),(233,'fingerfucking'),(234,'fisch-stinkender hodenfresser'),(235,'fistfuck'),(236,'fistfucking'),(237,'flachtitte'),(238,'flussfotze'),(239,'fotze'),(240,'fotzenforscher'),(241,'fotzenfresse'),(242,'fotzenknecht'),(243,'fotzenkruste'),(244,'fotzenkuchen'),(245,'fotzenlecker'),(246,'fotzenlöckchen'),(247,'fotzenpisser'),(248,'fotzenschmuser'),(249,'fotzhobel'),(250,'frisösenficker'),(251,'frisösenfotze'),(252,'fritzfink'),(253,'froschfotze'),(254,'froschfotzenficker'),(255,'froschfotzenleder'),(256,'fuck'),(257,'fucked'),(258,'fucker'),(259,'fucker'),(260,'fucking'),(261,'fuckup'),(262,'fudgepacker'),(263,'futtgesicht'),(264,'gay lord'),(265,'geilriemen'),(266,'gesichtsfotze'),(267,'göring'),(268,'großmaul'),(269,'gummifotzenficker'),(270,'gummipuppenbumser'),(271,'gummisklave'),(272,'hackfresse'),(273,'hafensau'),(274,'hartgeldhure'),(275,'heil hitler'),(276,'hi hoper'),(277,'hinterlader'),(278,'hirni'),(279,'hitler'),(280,'hodenbeißer'),(281,'hodensohn'),(282,'homo'),(283,'hosenpisser'),(284,'hosenscheißer'),(285,'hühnerficker'),(286,'huhrensohn'),(287,'hundeficker'),(288,'hundesohn'),(289,'hurenlecker'),(290,'hurenpeter'),(291,'hurensohn'),(292,'hurentocher'),(293,'idiot'),(294,'idioten'),(295,'itakker'),(296,'ittaker'),(297,'jack off'),(298,'jackass'),(299,'jackshit'),(300,'jerk off'),(301,'jizz'),(302,'judensau'),(303,'kackarsch'),(304,'kacke'),(305,'kacken'),(306,'kackfass'),(307,'kackfresse'),(308,'kacknoob'),(309,'kaktusficker'),(310,'kanacke'),(311,'kanake'),(312,'kanaken'),(313,'kanaldeckelbefruchter'),(314,'kartoffelficker'),(315,'kinderficken'),(316,'kinderficker'),(317,'kinderporno'),(318,'kitzler fresser'),(319,'klapposkop'),(320,'klolecker'),(321,'klötenlutscher'),(322,'knoblauchfresser'),(323,'konzentrationslager'),(324,'kotgeburt'),(325,'kotnascher'),(326,'kümmeltürke'),(327,'kümmeltürken'),(328,'lackaffe'),(329,'lebensunwert'),(330,'lesbian'),(331,'lurchi'),(332,'lustbolzen'),(333,'lutscher'),(334,'magerschwanz'),(335,'manwhore'),(336,'masturbate'),(337,'meat puppet'),(338,'missgeburt'),(339,'mißgeburt'),(340,'mistsau'),(341,'miststück'),(342,'mitternachtsficker'),(343,'mohrenkopf'),(344,'mokkastübchenveredler'),(345,'mongo'),(346,'möse'),(347,'mösenficker'),(348,'mösenlecker'),(349,'mösenputzer'),(350,'möter'),(351,'mother fucker'),(352,'mother fucking'),(353,'motherfucker'),(354,'muschilecker'),(355,'muschischlitz'),(356,'mutterficker'),(357,'nazi'),(358,'nazis'),(359,'neger'),(360,'nigga'),(361,'nigger'),(362,'niggerlover'),(363,'niggers'),(364,'niggerschlampe'),(365,'nignog'),(366,'nippelsauger'),(367,'nutte'),(368,'nuttensohn'),(369,'nuttenstecher'),(370,'nuttentochter'),(371,'ochsenpimmel'),(372,'ölauge'),(373,'oral sex'),(374,'penis licker'),(375,'penis licking'),(376,'penis sucker'),(377,'penis sucking'),(378,'penis'),(379,'peniskopf'),(380,'penislecker'),(381,'penislutscher'),(382,'penissalat'),(383,'penner'),(384,'pferdearsch'),(385,'phentermine'),(386,'pimmel'),(387,'pimmelkopf'),(388,'pimmellutscher'),(389,'pimmelpirat'),(390,'pimmelprinz'),(391,'pimmelschimmel'),(392,'pimmelvinni'),(393,'pindick'),(394,'piss off'),(395,'piss'),(396,'pissbirne'),(397,'pissbotte'),(398,'pisse'),(399,'pisser'),(400,'pissetrinker'),(401,'pissfisch'),(402,'pissflitsche'),(403,'pissnelke'),(404,'polacke'),(405,'polacken'),(406,'poop'),(407,'popellfresser'),(408,'popostecker'),(409,'popunterlage'),(410,'porn'),(411,'porno'),(412,'pornografie'),(413,'pornoprengel'),(414,'pottsau'),(415,'prärieficker'),(416,'prick'),(417,'quiff'),(418,'randsteinwichser'),(419,'rasierte votzen'),(420,'rimjob'),(421,'rindsriemen'),(422,'ritzenfummler'),(423,'rollbrooden'),(424,'roseten putzer'),(425,'roseten schlemmer'),(426,'rosettenhengst'),(427,'rosettenkönig'),(428,'rosettenlecker'),(429,'rosettentester'),(430,'sackfalter'),(431,'sackgesicht'),(432,'sacklutscher'),(433,'sackratte'),(434,'saftarsch'),(435,'sakfalter'),(436,'schamhaarlecker'),(437,'schamhaarschädel'),(438,'schandmaul'),(439,'scheisse'),(440,'scheisser'),(441,'scheissgesicht'),(442,'scheisshaufen'),(443,'scheißhaufen'),(444,'schlammfotze'),(445,'schlampe'),(446,'schleimmöse'),(447,'schlitzpisser'),(448,'schmalspurficker'),(449,'schmeue'),(450,'schmuckbert'),(451,'schnuddelfresser'),(452,'schnurbeltatz'),(453,'schrumpelfotze'),(454,'schwanzlurch'),(455,'schwanzlutscher'),(456,'schweinepriester'),(457,'schweineschwanzlutscher'),(458,'schwuchtel'),(459,'schwutte'),(460,'sex'),(461,'shiter'),(462,'shiting'),(463,'shitlist'),(464,'shitomatic'),(465,'shits'),(466,'shitty'),(467,'shlong'),(468,'shut the fuckup'),(469,'sieg heil'),(470,'sitzpisser'),(471,'skullfuck'),(472,'skullfucker'),(473,'skullfucking'),(474,'slut'),(475,'smegmafresser'),(476,'spack'),(477,'spacko'),(478,'spaghettifresser'),(479,'spastard'),(480,'spasti'),(481,'spastis'),(482,'spermafresse'),(483,'spermarutsche'),(484,'spritzer'),(485,'stinkschlitz'),(486,'stricher'),(487,'suck my cock'),(488,'suck my dick'),(489,'threesome'),(490,'tittenficker'),(491,'tittenspritzer'),(492,'titties'),(493,'titty'),(494,'tunte'),(495,'untermensch'),(496,'vagina'),(497,'vergasen'),(498,'viagra'),(499,'volldepp'),(500,'volldeppen'),(501,'vollhorst'),(502,'vollidiot'),(503,'vollpfosten'),(504,'vollspack'),(505,'vollspacken'),(506,'vollspasti'),(507,'vorhaut'),(508,'votze'),(509,'votzenkopf'),(510,'wanker'),(511,'wankers'),(512,'weichei'),(513,'whoar'),(514,'whore'),(515,'wichsbart'),(516,'wichsbirne'),(517,'wichser'),(518,'wichsfrosch'),(519,'wichsgriffel'),(520,'wichsvorlage'),(521,'wickspickel'),(522,'wixa'),(523,'wixen'),(524,'wixer'),(525,'wixxer'),(526,'wixxxer'),(527,'wixxxxer'),(528,'wurstsemmelfresser'),(529,'yankee'),(530,'zappler'),(531,'zyclon b'),(532,'zyklon b'),(533,'x x x'),(1000,'анал'),(1001,'анальная'),(1002,'анальный'),(1003,'аннал'),(1004,'аннал'),(1005,'аннальная'),(1006,'аннальный'),(1007,'анус'),(1008,'ара'),(1009,'ахуе'),(1010,'ахуеннейшая'),(1011,'ахуеннейший'),(1012,'ахуенный'),(1013,'ахуй'),(1014,'бледям'),(1015,'бля'),(1016,'бля*'),(1017,'блядво'),(1018,'бляди'),(1019,'блядская'),(1020,'блядский'),(1021,'блядство'),(1022,'блядь'),(1023,'блядью'),(1024,'блядям'),(1025,'вагина'),(1026,'вагинальная'),(1027,'вагинальный'),(1028,'влагалище'),(1029,'въебывал'),(1030,'въебывать'),(1031,'выебнулась'),(1032,'выебнулся'),(1033,'выебывается'),(1034,'выёбывается'),(1035,'выебывался'),(1036,'выёбывался'),(1037,'выебываться'),(1038,'выёбываться'),(1039,'групповичок'),(1040,'групповуха'),(1041,'дефларировал'),(1042,'дефлорация'),(1043,'дефлорировал'),(1044,'дефлорированая'),(1045,'дефлорированная'),(1046,'долбоеб'),(1047,'долбоёб'),(1048,'долбоебизм'),(1049,'ебал'),(1050,'ебанулась'),(1051,'ебанулся'),(1052,'ебануться'),(1053,'ебаный'),(1054,'ёбаный'),(1055,'ебарем'),(1056,'ёбарем'),(1057,'ебарь'),(1058,'ёбарь'),(1059,'ебать'),(1060,'ебаться'),(1061,'ебет'),(1062,'ебёт'),(1063,'ебля'),(1064,'ебнулась'),(1065,'ёбнулась'),(1066,'ебнулся'),(1067,'ёбнулся'),(1068,'ебут'),(1069,'елда'),(1070,'елдою'),(1071,'жид'),(1072,'жидовка'),(1073,'жидовская'),(1074,'жидовский'),(1075,'жидовское'),(1076,'жиды'),(1077,'жопа'),(1078,'жопа*'),(1079,'жопо*'),(1080,'жопах'),(1081,'жопе'),(1082,'жопу'),(1083,'жопы'),(1084,'жыд'),(1085,'жыдовка'),(1086,'жыдовская'),(1087,'жыдовский'),(1088,'жыдовское'),(1089,'жыды'),(1090,'заебала'),(1091,'заебали'),(1092,'заебало'),(1093,'заебался'),(1094,'заебись'),(1095,'заебло'),(1096,'залупа'),(1097,'залупе'),(1098,'залупил'),(1099,'залупилась'),(1100,'залупился'),(1101,'залупу'),(1102,'затрахал'),(1103,'затрахала'),(1104,'затрахало'),(1105,'изъебнулась'),(1106,'изъебнулся'),(1107,'изъебыватся'),(1108,'изъёбыватся'),(1109,'изъебываться'),(1110,'изъёбываться'),(1111,'индевидуалки'),(1112,'индиведуалки'),(1113,'индивидуалки'),(1114,'копро'),(1115,'копрофаг'),(1116,'кунилингус'),(1117,'куннилингус'),(1118,'лезбеянка'),(1119,'лезбеянки'),(1120,'лезби'),(1121,'лезбиянка'),(1122,'лезбиянки'),(1123,'лезбо'),(1124,'лесбеянка'),(1125,'лесбеянки'),(1126,'лесби'),(1127,'лесбиянка'),(1128,'лесбиянки'),(1129,'лесбо'),(1130,'мазо'),(1131,'мазохизм'),(1132,'манда'),(1133,'манде'),(1134,'манду'),(1135,'манды'),(1136,'менет'),(1137,'менстра'),(1138,'менструация'),(1139,'менструирующая'),(1140,'менструирующие'),(1141,'меньет'),(1142,'минет'),(1143,'миньет'),(1144,'мозгоеб'),(1145,'мозгоёб'),(1146,'мозгоебля'),(1147,'мозгоебство'),(1148,'мозгоёбство'),(1149,'мудак'),(1150,'мудаковатая'),(1151,'мудаковатый'),(1152,'муде'),(1153,'мудила'),(1154,'наебал'),(1155,'наебали'),(1156,'наебать'),(1157,'наебли'),(1158,'наебнулась'),(1159,'наебнулся'),(1160,'насрал'),(1161,'насрала'),(1162,'насрать'),(1163,'настапиздил'),(1164,'настапиздило'),(1165,'настопиздил'),(1166,'настопиздило'),(1167,'нахуй'),(1168,'нахуя'),(1169,'невъебеная'),(1170,'невъебенная'),(1171,'невъебенно'),(1172,'невъебенный'),(1173,'невъебено'),(1174,'невъебеный'),(1175,'немфетка'),(1176,'немфетки'),(1177,'нивъебенная'),(1178,'нивъебенно'),(1179,'нивъебенный'),(1180,'нимфетка'),(1181,'нимфетки'),(1182,'опезденевшая'),(1183,'опезденевший'),(1184,'опезденел'),(1185,'опезденела'),(1186,'опизденевшая'),(1187,'опизденевший'),(1188,'опизденел'),(1189,'опизденела'),(1190,'оргии'),(1191,'оргия'),(1192,'отпиздил'),(1193,'отпиздила'),(1194,'отпиздили'),(1195,'отпизженая'),(1196,'отпизженная'),(1197,'отпизженный'),(1198,'отпизженый'),(1199,'отсасал'),(1200,'отсасала'),(1201,'отсасывает'),(1202,'отсосал'),(1203,'отсосала'),(1204,'оттрахал'),(1205,'оттраханая'),(1206,'оттраханная'),(1207,'оттраханные'),(1208,'оттраханые'),(1209,'отъебал'),(1210,'отъебалась'),(1211,'отъебать'),(1212,'отъебись'),(1213,'охуеваю'),(1214,'охуевший'),(1215,'охуел'),(1216,'охуенейшая'),(1217,'охуенейший'),(1218,'охуеннейшая'),(1219,'охуеннейший'),(1220,'охуенный'),(1221,'охуеный'),(1222,'пархатая'),(1223,'пархатый'),(1224,'педераз'),(1225,'педераст'),(1226,'педораз'),(1227,'педорас'),(1228,'педораст'),(1229,'пезда'),(1230,'пездабол'),(1231,'пездаболка'),(1232,'пездато'),(1233,'пезде'),(1234,'пезденыш'),(1235,'пезду'),(1236,'пёзды'),(1237,'пездюк'),(1238,'пездюкам'),(1239,'пездюку'),(1240,'пездючка'),(1241,'пездючкам'),(1242,'пелотка'),(1243,'пидар'),(1244,'пидар*'),(1245,'пидарас'),(1246,'пидараст'),(1247,'пидераз'),(1248,'пидор'),(1249,'пидор*'),(1250,'пидораз'),(1251,'пидорас'),(1252,'пидораст'),(1253,'пизда'),(1254,'пизда*'),(1255,'пиздабол'),(1256,'пиздаболка'),(1257,'пиздам'),(1258,'пиздатая'),(1259,'пиздато'),(1260,'пиздатый'),(1261,'пизде'),(1262,'пиздел'),(1263,'пиздела'),(1264,'пизденыш'),(1265,'пиздеть'),(1266,'пиздец'),(1267,'пиздил'),(1268,'пиздить'),(1269,'пиздобол'),(1270,'пиздоболка'),(1271,'пизду'),(1272,'пиздюк'),(1273,'пиздюкам'),(1274,'пиздюку'),(1275,'пиздючка'),(1276,'пиздючкам'),(1277,'пипка'),(1278,'пипки'),(1279,'плева'),(1280,'подзалупная'),(1281,'подзалупный'),(1282,'подъебка'),(1283,'подъёбка'),(1284,'поебался'),(1285,'поебок'),(1286,'порево'),(1287,'порно'),(1288,'порнуха'),(1289,'порхатая'),(1290,'порхатый'),(1291,'промандиблядская'),(1292,'промандиблядский'),(1293,'проститутка'),(1294,'проститутки'),(1295,'разъебал'),(1296,'разъебать'),(1297,'распездил'),(1298,'распиздил'),(1299,'сасал'),(1300,'сасала'),(1301,'сасет'),(1302,'сасёт'),(1303,'секс'),(1304,'сиська'),(1305,'сиськи'),(1306,'сперма'),(1307,'сперме'),(1308,'сперму'),(1309,'сраная'),(1310,'сраное'),(1311,'сраный'),(1312,'срать'),(1313,'ссучившийся'),(1314,'ссучилась'),(1315,'ссучился'),(1316,'сука'),(1317,'сукам'),(1318,'суке'),(1319,'суки'),(1320,'сцука'),(1321,'сцуко'),(1322,'съебал'),(1323,'съебала'),(1324,'съебать'),(1325,'трахает'),(1326,'трахал'),(1327,'трахали'),(1328,'трахать'),(1329,'уебали'),(1330,'уебало'),(1331,'уебался'),(1332,'уебище'),(1333,'уёбище'),(1334,'уебищная'),(1335,'уёбищная'),(1336,'уебищные'),(1337,'уёбищные'),(1338,'уебищный'),(1339,'уёбищный'),(1340,'уебла'),(1341,'уебли'),(1342,'уебло'),(1343,'уебок'),(1344,'уёбок'),(1345,'фистинг'),(1346,'хер'),(1347,'хера'),(1348,'хером'),(1349,'хуе*'),(1350,'хуё*'),(1351,'хуево'),(1352,'хуем'),(1353,'хуеплет'),(1354,'хуеплёт'),(1355,'хуесос'),(1356,'хуесоска'),(1357,'хуета'),(1358,'хуй'),(1359,'хуй*'),(1360,'хуйне'),(1361,'хуйнею'),(1362,'хуйня'),(1363,'хуита'),(1364,'хую'),(1365,'хуя'),(1366,'хуя*'),(1367,'хуякс'),(1368,'хХХ'),(1369,'Ххх'),(1370,'целка'),(1371,'целках'),(1372,'целке'),(1373,'целки'),(1374,'целку'),(1375,'черножопая'),(1376,'черножопое'),(1377,'черножопый'),(1378,'член'),(1379,'чурка'),(1380,'чуркам'),(1381,'чурке'),(1382,'чурки'),(1383,'шлюха'),(1384,'шлюхи'),(1385,'ялда'),(1386,'ялдою');
/*!40000 ALTER TABLE `uxlo0_easybook_badwords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_extensions`
--

DROP TABLE IF EXISTS `uxlo0_extensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_extensions` (
  `extension_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL,
  `element` varchar(100) NOT NULL,
  `folder` varchar(100) NOT NULL,
  `client_id` tinyint(3) NOT NULL,
  `enabled` tinyint(3) NOT NULL DEFAULT '1',
  `access` int(10) unsigned NOT NULL DEFAULT '1',
  `protected` tinyint(3) NOT NULL DEFAULT '0',
  `manifest_cache` text NOT NULL,
  `params` text NOT NULL,
  `custom_data` text NOT NULL,
  `system_data` text NOT NULL,
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) DEFAULT '0',
  `state` int(11) DEFAULT '0',
  PRIMARY KEY (`extension_id`),
  KEY `element_clientid` (`element`,`client_id`),
  KEY `element_folder_clientid` (`element`,`folder`,`client_id`),
  KEY `extension` (`type`,`element`,`folder`,`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10012 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_extensions`
--

LOCK TABLES `uxlo0_extensions` WRITE;
/*!40000 ALTER TABLE `uxlo0_extensions` DISABLE KEYS */;
INSERT INTO `uxlo0_extensions` VALUES (1,'com_mailto','component','com_mailto','',0,1,1,1,'{\"legacy\":false,\"name\":\"com_mailto\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"COM_MAILTO_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(2,'com_wrapper','component','com_wrapper','',0,1,1,1,'{\"legacy\":false,\"name\":\"com_wrapper\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\n\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"COM_WRAPPER_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(3,'com_admin','component','com_admin','',1,1,1,1,'{\"legacy\":false,\"name\":\"com_admin\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\n\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"COM_ADMIN_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(4,'com_banners','component','com_banners','',1,1,1,0,'{\"legacy\":false,\"name\":\"com_banners\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\n\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"COM_BANNERS_XML_DESCRIPTION\",\"group\":\"\"}','{\"purchase_type\":\"3\",\"track_impressions\":\"0\",\"track_clicks\":\"0\",\"metakey_prefix\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(5,'com_cache','component','com_cache','',1,1,1,1,'{\"legacy\":false,\"name\":\"com_cache\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"COM_CACHE_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(6,'com_categories','component','com_categories','',1,1,1,1,'{\"legacy\":false,\"name\":\"com_categories\",\"type\":\"component\",\"creationDate\":\"December 2007\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"COM_CATEGORIES_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(7,'com_checkin','component','com_checkin','',1,1,1,1,'{\"legacy\":false,\"name\":\"com_checkin\",\"type\":\"component\",\"creationDate\":\"Unknown\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2008 Open Source Matters. All rights reserved.\\n\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"COM_CHECKIN_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(8,'com_contact','component','com_contact','',1,1,1,0,'{\"legacy\":false,\"name\":\"com_contact\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\n\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"COM_CONTACT_XML_DESCRIPTION\",\"group\":\"\"}','{\"contact_layout\":\"_:default\",\"show_contact_category\":\"hide\",\"show_contact_list\":\"0\",\"presentation_style\":\"sliders\",\"show_name\":\"0\",\"show_position\":\"0\",\"show_email\":\"0\",\"show_street_address\":\"0\",\"show_suburb\":\"0\",\"show_state\":\"0\",\"show_postcode\":\"0\",\"show_country\":\"0\",\"show_telephone\":\"0\",\"show_mobile\":\"0\",\"show_fax\":\"0\",\"show_webpage\":\"0\",\"show_misc\":\"0\",\"show_image\":\"0\",\"image\":\"\",\"allow_vcard\":\"0\",\"show_articles\":\"0\",\"show_profile\":\"1\",\"show_links\":\"0\",\"linka_name\":\"\",\"linkb_name\":\"\",\"linkc_name\":\"\",\"linkd_name\":\"\",\"linke_name\":\"\",\"contact_icons\":\"0\",\"icon_address\":\"\",\"icon_email\":\"\",\"icon_telephone\":\"\",\"icon_mobile\":\"\",\"icon_fax\":\"\",\"icon_misc\":\"\",\"category_layout\":\"_:default\",\"show_category_title\":\"1\",\"show_description\":\"1\",\"show_description_image\":\"0\",\"maxLevel\":\"-1\",\"show_empty_categories\":\"0\",\"show_subcat_desc\":\"1\",\"show_cat_items\":\"1\",\"show_base_description\":\"1\",\"maxLevelcat\":\"-1\",\"show_empty_categories_cat\":\"0\",\"show_subcat_desc_cat\":\"1\",\"show_cat_items_cat\":\"1\",\"show_pagination_limit\":\"0\",\"show_headings\":\"0\",\"show_position_headings\":\"0\",\"show_email_headings\":\"0\",\"show_telephone_headings\":\"0\",\"show_mobile_headings\":\"0\",\"show_fax_headings\":\"0\",\"show_suburb_headings\":\"0\",\"show_state_headings\":\"0\",\"show_country_headings\":\"0\",\"show_pagination\":\"2\",\"show_pagination_results\":\"1\",\"initial_sort\":\"ordering\",\"captcha\":\"\",\"show_email_form\":\"1\",\"show_email_copy\":\"1\",\"banned_email\":\"\",\"banned_subject\":\"\",\"banned_text\":\"\",\"validate_session\":\"1\",\"custom_reply\":\"0\",\"redirect\":\"\",\"show_feed_link\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(9,'com_cpanel','component','com_cpanel','',1,1,1,1,'{\"legacy\":false,\"name\":\"com_cpanel\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"COM_CPANEL_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(10,'com_installer','component','com_installer','',1,1,1,1,'{\"legacy\":false,\"name\":\"com_installer\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"COM_INSTALLER_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(11,'com_languages','component','com_languages','',1,1,1,1,'{\"legacy\":false,\"name\":\"com_languages\",\"type\":\"component\",\"creationDate\":\"2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\n\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"COM_LANGUAGES_XML_DESCRIPTION\",\"group\":\"\"}','{\"administrator\":\"en-GB\",\"site\":\"zh-CN\"}','','',0,'0000-00-00 00:00:00',0,0),(12,'com_login','component','com_login','',1,1,1,1,'{\"legacy\":false,\"name\":\"com_login\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"COM_LOGIN_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(13,'com_media','component','com_media','',1,1,0,1,'{\"legacy\":false,\"name\":\"com_media\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"COM_MEDIA_XML_DESCRIPTION\",\"group\":\"\"}','{\"upload_extensions\":\"bmp,csv,doc,gif,ico,jpg,jpeg,odg,odp,ods,odt,pdf,png,ppt,swf,txt,xcf,xls,BMP,CSV,DOC,GIF,ICO,JPG,JPEG,ODG,ODP,ODS,ODT,PDF,PNG,PPT,SWF,TXT,XCF,XLS\",\"upload_maxsize\":\"10\",\"file_path\":\"images\",\"image_path\":\"images\",\"restrict_uploads\":\"1\",\"allowed_media_usergroup\":\"3\",\"check_mime\":\"1\",\"image_extensions\":\"bmp,gif,jpg,png\",\"ignore_extensions\":\"\",\"upload_mime\":\"image\\/jpeg,image\\/gif,image\\/png,image\\/bmp,application\\/x-shockwave-flash,application\\/msword,application\\/excel,application\\/pdf,application\\/powerpoint,text\\/plain,application\\/x-zip\",\"upload_mime_illegal\":\"text\\/html\",\"enable_flash\":\"0\"}','','',0,'0000-00-00 00:00:00',0,0),(14,'com_menus','component','com_menus','',1,1,1,1,'{\"legacy\":false,\"name\":\"com_menus\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"COM_MENUS_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(15,'com_messages','component','com_messages','',1,1,1,1,'{\"legacy\":false,\"name\":\"com_messages\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"COM_MESSAGES_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(16,'com_modules','component','com_modules','',1,1,1,1,'{\"legacy\":false,\"name\":\"com_modules\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"COM_MODULES_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(17,'com_newsfeeds','component','com_newsfeeds','',1,1,1,0,'{\"legacy\":false,\"name\":\"com_newsfeeds\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"COM_NEWSFEEDS_XML_DESCRIPTION\",\"group\":\"\"}','{\"show_feed_image\":\"1\",\"show_feed_description\":\"1\",\"show_item_description\":\"1\",\"feed_word_count\":\"0\",\"show_headings\":\"1\",\"show_name\":\"1\",\"show_articles\":\"0\",\"show_link\":\"1\",\"show_description\":\"1\",\"show_description_image\":\"1\",\"display_num\":\"\",\"show_pagination_limit\":\"1\",\"show_pagination\":\"1\",\"show_pagination_results\":\"1\",\"show_cat_items\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(18,'com_plugins','component','com_plugins','',1,1,1,1,'{\"legacy\":false,\"name\":\"com_plugins\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"COM_PLUGINS_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(19,'com_search','component','com_search','',1,1,1,1,'{\"legacy\":false,\"name\":\"com_search\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\n\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"COM_SEARCH_XML_DESCRIPTION\",\"group\":\"\"}','{\"enabled\":\"0\",\"show_date\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(20,'com_templates','component','com_templates','',1,1,1,1,'{\"legacy\":false,\"name\":\"com_templates\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"COM_TEMPLATES_XML_DESCRIPTION\",\"group\":\"\"}','{\"template_positions_display\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(21,'com_weblinks','component','com_weblinks','',1,1,1,0,'{\"legacy\":false,\"name\":\"com_weblinks\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\n\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"COM_WEBLINKS_XML_DESCRIPTION\",\"group\":\"\"}','{\"show_comp_description\":\"1\",\"comp_description\":\"\",\"show_link_hits\":\"1\",\"show_link_description\":\"1\",\"show_other_cats\":\"0\",\"show_headings\":\"0\",\"show_numbers\":\"0\",\"show_report\":\"1\",\"count_clicks\":\"1\",\"target\":\"0\",\"link_icons\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(22,'com_content','component','com_content','',1,1,0,1,'{\"legacy\":false,\"name\":\"com_content\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"COM_CONTENT_XML_DESCRIPTION\",\"group\":\"\"}','{\"article_layout\":\"_:default\",\"show_title\":\"0\",\"link_titles\":\"0\",\"show_intro\":\"0\",\"show_category\":\"0\",\"link_category\":\"0\",\"show_parent_category\":\"0\",\"link_parent_category\":\"0\",\"show_author\":\"0\",\"link_author\":\"0\",\"show_create_date\":\"0\",\"show_modify_date\":\"0\",\"show_publish_date\":\"0\",\"show_item_navigation\":\"0\",\"show_vote\":\"0\",\"show_readmore\":\"0\",\"show_readmore_title\":\"0\",\"readmore_limit\":\"100\",\"show_icons\":\"0\",\"show_print_icon\":\"0\",\"show_email_icon\":\"0\",\"show_hits\":\"0\",\"show_noauth\":\"0\",\"urls_position\":\"0\",\"show_publishing_options\":\"1\",\"show_article_options\":\"1\",\"show_urls_images_frontend\":\"0\",\"show_urls_images_backend\":\"1\",\"targeta\":0,\"targetb\":0,\"targetc\":0,\"float_intro\":\"left\",\"float_fulltext\":\"left\",\"category_layout\":\"_:blog\",\"show_category_title\":\"0\",\"show_description\":\"0\",\"show_description_image\":\"0\",\"maxLevel\":\"1\",\"show_empty_categories\":\"0\",\"show_no_articles\":\"1\",\"show_subcat_desc\":\"1\",\"show_cat_num_articles\":\"0\",\"show_base_description\":\"1\",\"maxLevelcat\":\"-1\",\"show_empty_categories_cat\":\"0\",\"show_subcat_desc_cat\":\"1\",\"show_cat_num_articles_cat\":\"1\",\"num_leading_articles\":\"1\",\"num_intro_articles\":\"4\",\"num_columns\":\"2\",\"num_links\":\"4\",\"multi_column_order\":\"0\",\"show_subcategory_content\":\"0\",\"show_pagination_limit\":\"1\",\"filter_field\":\"hide\",\"show_headings\":\"1\",\"list_show_date\":\"0\",\"date_format\":\"\",\"list_show_hits\":\"1\",\"list_show_author\":\"1\",\"orderby_pri\":\"order\",\"orderby_sec\":\"rdate\",\"order_date\":\"published\",\"show_pagination\":\"2\",\"show_pagination_results\":\"1\",\"show_feed_link\":\"1\",\"feed_summary\":\"0\"}','','',0,'0000-00-00 00:00:00',0,0),(23,'com_config','component','com_config','',1,1,0,1,'{\"legacy\":false,\"name\":\"com_config\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"COM_CONFIG_XML_DESCRIPTION\",\"group\":\"\"}','{\"filters\":{\"1\":{\"filter_type\":\"NH\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"6\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"7\":{\"filter_type\":\"NONE\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"2\":{\"filter_type\":\"NH\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"3\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"4\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"5\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"8\":{\"filter_type\":\"NONE\",\"filter_tags\":\"\",\"filter_attributes\":\"\"}}}','','',0,'0000-00-00 00:00:00',0,0),(24,'com_redirect','component','com_redirect','',1,1,0,1,'{\"legacy\":false,\"name\":\"com_redirect\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"COM_REDIRECT_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(25,'com_users','component','com_users','',1,1,0,1,'{\"legacy\":false,\"name\":\"com_users\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"COM_USERS_XML_DESCRIPTION\",\"group\":\"\"}','{\"allowUserRegistration\":\"1\",\"new_usertype\":\"2\",\"guest_usergroup\":\"1\",\"useractivation\":\"2\",\"mail_to_admin\":\"0\",\"captcha\":\"\",\"frontend_userparams\":\"1\",\"site_language\":\"0\",\"mailSubjectPrefix\":\"\",\"mailBodySuffix\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(27,'com_finder','component','com_finder','',1,1,0,0,'{\"legacy\":false,\"name\":\"com_finder\",\"type\":\"component\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"COM_FINDER_XML_DESCRIPTION\",\"group\":\"\"}','{\"show_description\":\"1\",\"description_length\":255,\"allow_empty_query\":\"0\",\"show_url\":\"1\",\"show_advanced\":\"1\",\"expand_advanced\":\"0\",\"show_date_filters\":\"0\",\"highlight_terms\":\"1\",\"opensearch_name\":\"\",\"opensearch_description\":\"\",\"batch_size\":\"50\",\"memory_table_limit\":30000,\"title_multiplier\":\"1.7\",\"text_multiplier\":\"0.7\",\"meta_multiplier\":\"1.2\",\"path_multiplier\":\"2.0\",\"misc_multiplier\":\"0.3\",\"stemmer\":\"snowball\"}','','',0,'0000-00-00 00:00:00',0,0),(28,'com_joomlaupdate','component','com_joomlaupdate','',1,1,0,1,'{\"legacy\":false,\"name\":\"com_joomlaupdate\",\"type\":\"component\",\"creationDate\":\"February 2012\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"COM_JOOMLAUPDATE_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(100,'PHPMailer','library','phpmailer','',0,1,1,1,'{\"legacy\":false,\"name\":\"PHPMailer\",\"type\":\"library\",\"creationDate\":\"2008\",\"author\":\"PHPMailer\",\"copyright\":\"Copyright (C) PHPMailer.\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/phpmailer.codeworxtech.com\\/\",\"version\":\"2.5.0\",\"description\":\"LIB_PHPMAILER_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(101,'SimplePie','library','simplepie','',0,1,1,1,'{\"legacy\":false,\"name\":\"SimplePie\",\"type\":\"library\",\"creationDate\":\"2008\",\"author\":\"SimplePie\",\"copyright\":\"Copyright (C) 2008 SimplePie\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/simplepie.org\\/\",\"version\":\"1.0.1\",\"description\":\"LIB_SIMPLEPIE_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(102,'phputf8','library','phputf8','',0,1,1,1,'{\"legacy\":false,\"name\":\"phputf8\",\"type\":\"library\",\"creationDate\":\"2008\",\"author\":\"Harry Fuecks\",\"copyright\":\"Copyright various authors\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/sourceforge.net\\/projects\\/phputf8\",\"version\":\"2.5.0\",\"description\":\"LIB_PHPUTF8_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(103,'Joomla! Web Application Framework','library','joomla','',0,1,1,1,'{\"legacy\":false,\"name\":\"Joomla! Web Application Framework\",\"type\":\"library\",\"creationDate\":\"2008\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"http:\\/\\/www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"LIB_JOOMLA_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(200,'mod_articles_archive','module','mod_articles_archive','',0,1,1,1,'{\"legacy\":false,\"name\":\"mod_articles_archive\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters.\\n\\t\\tAll rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_ARTICLES_ARCHIVE_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(201,'mod_articles_latest','module','mod_articles_latest','',0,1,1,1,'{\"legacy\":false,\"name\":\"mod_articles_latest\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_LATEST_NEWS_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(202,'mod_articles_popular','module','mod_articles_popular','',0,1,1,0,'{\"legacy\":false,\"name\":\"mod_articles_popular\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_POPULAR_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(203,'mod_banners','module','mod_banners','',0,1,1,1,'{\"legacy\":false,\"name\":\"mod_banners\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_BANNERS_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(204,'mod_breadcrumbs','module','mod_breadcrumbs','',0,1,1,1,'{\"legacy\":false,\"name\":\"mod_breadcrumbs\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_BREADCRUMBS_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(205,'mod_custom','module','mod_custom','',0,1,1,1,'{\"legacy\":false,\"name\":\"mod_custom\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_CUSTOM_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(206,'mod_feed','module','mod_feed','',0,1,1,1,'{\"legacy\":false,\"name\":\"mod_feed\",\"type\":\"module\",\"creationDate\":\"July 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_FEED_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(207,'mod_footer','module','mod_footer','',0,1,1,1,'{\"legacy\":false,\"name\":\"mod_footer\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_FOOTER_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(208,'mod_login','module','mod_login','',0,1,1,1,'{\"legacy\":false,\"name\":\"mod_login\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_LOGIN_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(209,'mod_menu','module','mod_menu','',0,1,1,1,'{\"legacy\":false,\"name\":\"mod_menu\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_MENU_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(210,'mod_articles_news','module','mod_articles_news','',0,1,1,0,'{\"legacy\":false,\"name\":\"mod_articles_news\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_ARTICLES_NEWS_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(211,'mod_random_image','module','mod_random_image','',0,1,1,0,'{\"legacy\":false,\"name\":\"mod_random_image\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_RANDOM_IMAGE_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(212,'mod_related_items','module','mod_related_items','',0,1,1,0,'{\"legacy\":false,\"name\":\"mod_related_items\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_RELATED_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(213,'mod_search','module','mod_search','',0,1,1,0,'{\"legacy\":false,\"name\":\"mod_search\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_SEARCH_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(214,'mod_stats','module','mod_stats','',0,1,1,0,'{\"legacy\":false,\"name\":\"mod_stats\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_STATS_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(215,'mod_syndicate','module','mod_syndicate','',0,1,1,1,'{\"legacy\":false,\"name\":\"mod_syndicate\",\"type\":\"module\",\"creationDate\":\"May 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_SYNDICATE_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(216,'mod_users_latest','module','mod_users_latest','',0,1,1,1,'{\"legacy\":false,\"name\":\"mod_users_latest\",\"type\":\"module\",\"creationDate\":\"December 2009\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_USERS_LATEST_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(217,'mod_weblinks','module','mod_weblinks','',0,1,1,0,'{\"legacy\":false,\"name\":\"mod_weblinks\",\"type\":\"module\",\"creationDate\":\"July 2009\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_WEBLINKS_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(218,'mod_whosonline','module','mod_whosonline','',0,1,1,0,'{\"legacy\":false,\"name\":\"mod_whosonline\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_WHOSONLINE_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(219,'mod_wrapper','module','mod_wrapper','',0,1,1,0,'{\"legacy\":false,\"name\":\"mod_wrapper\",\"type\":\"module\",\"creationDate\":\"October 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_WRAPPER_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(220,'mod_articles_category','module','mod_articles_category','',0,1,1,1,'{\"legacy\":false,\"name\":\"mod_articles_category\",\"type\":\"module\",\"creationDate\":\"February 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_ARTICLES_CATEGORY_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(221,'mod_articles_categories','module','mod_articles_categories','',0,1,1,1,'{\"legacy\":false,\"name\":\"mod_articles_categories\",\"type\":\"module\",\"creationDate\":\"February 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_ARTICLES_CATEGORIES_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(222,'mod_languages','module','mod_languages','',0,1,1,1,'{\"legacy\":false,\"name\":\"mod_languages\",\"type\":\"module\",\"creationDate\":\"February 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_LANGUAGES_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(223,'mod_finder','module','mod_finder','',0,1,0,0,'{\"legacy\":false,\"name\":\"mod_finder\",\"type\":\"module\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_FINDER_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(300,'mod_custom','module','mod_custom','',1,1,1,1,'{\"legacy\":false,\"name\":\"mod_custom\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_CUSTOM_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(301,'mod_feed','module','mod_feed','',1,1,1,0,'{\"legacy\":false,\"name\":\"mod_feed\",\"type\":\"module\",\"creationDate\":\"July 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_FEED_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(302,'mod_latest','module','mod_latest','',1,1,1,0,'{\"legacy\":false,\"name\":\"mod_latest\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_LATEST_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(303,'mod_logged','module','mod_logged','',1,1,1,0,'{\"legacy\":false,\"name\":\"mod_logged\",\"type\":\"module\",\"creationDate\":\"January 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_LOGGED_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(304,'mod_login','module','mod_login','',1,1,1,1,'{\"legacy\":false,\"name\":\"mod_login\",\"type\":\"module\",\"creationDate\":\"March 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_LOGIN_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(305,'mod_menu','module','mod_menu','',1,1,1,0,'{\"legacy\":false,\"name\":\"mod_menu\",\"type\":\"module\",\"creationDate\":\"March 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_MENU_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(307,'mod_popular','module','mod_popular','',1,1,1,0,'{\"legacy\":false,\"name\":\"mod_popular\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_POPULAR_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(308,'mod_quickicon','module','mod_quickicon','',1,1,1,1,'{\"legacy\":false,\"name\":\"mod_quickicon\",\"type\":\"module\",\"creationDate\":\"Nov 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_QUICKICON_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(309,'mod_status','module','mod_status','',1,1,1,0,'{\"legacy\":false,\"name\":\"mod_status\",\"type\":\"module\",\"creationDate\":\"Feb 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_STATUS_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(310,'mod_submenu','module','mod_submenu','',1,1,1,0,'{\"legacy\":false,\"name\":\"mod_submenu\",\"type\":\"module\",\"creationDate\":\"Feb 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_SUBMENU_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(311,'mod_title','module','mod_title','',1,1,1,0,'{\"legacy\":false,\"name\":\"mod_title\",\"type\":\"module\",\"creationDate\":\"Nov 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_TITLE_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(312,'mod_toolbar','module','mod_toolbar','',1,1,1,1,'{\"legacy\":false,\"name\":\"mod_toolbar\",\"type\":\"module\",\"creationDate\":\"Nov 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_TOOLBAR_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(313,'mod_multilangstatus','module','mod_multilangstatus','',1,1,1,0,'{\"legacy\":false,\"name\":\"mod_multilangstatus\",\"type\":\"module\",\"creationDate\":\"September 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_MULTILANGSTATUS_XML_DESCRIPTION\",\"group\":\"\"}','{\"cache\":\"0\"}','','',0,'0000-00-00 00:00:00',0,0),(314,'mod_version','module','mod_version','',1,1,1,0,'{\"legacy\":false,\"name\":\"mod_version\",\"type\":\"module\",\"creationDate\":\"January 2012\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"MOD_VERSION_XML_DESCRIPTION\",\"group\":\"\"}','{\"format\":\"short\",\"product\":\"1\",\"cache\":\"0\"}','','',0,'0000-00-00 00:00:00',0,0),(400,'plg_authentication_gmail','plugin','gmail','authentication',0,0,1,0,'{\"legacy\":false,\"name\":\"plg_authentication_gmail\",\"type\":\"plugin\",\"creationDate\":\"February 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_GMAIL_XML_DESCRIPTION\",\"group\":\"\"}','{\"applysuffix\":\"0\",\"suffix\":\"\",\"verifypeer\":\"1\",\"user_blacklist\":\"\"}','','',0,'0000-00-00 00:00:00',1,0),(401,'plg_authentication_joomla','plugin','joomla','authentication',0,1,1,1,'{\"legacy\":false,\"name\":\"plg_authentication_joomla\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_AUTH_JOOMLA_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(402,'plg_authentication_ldap','plugin','ldap','authentication',0,0,1,0,'{\"legacy\":false,\"name\":\"plg_authentication_ldap\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_LDAP_XML_DESCRIPTION\",\"group\":\"\"}','{\"host\":\"\",\"port\":\"389\",\"use_ldapV3\":\"0\",\"negotiate_tls\":\"0\",\"no_referrals\":\"0\",\"auth_method\":\"bind\",\"base_dn\":\"\",\"search_string\":\"\",\"users_dn\":\"\",\"username\":\"admin\",\"password\":\"bobby7\",\"ldap_fullname\":\"fullName\",\"ldap_email\":\"mail\",\"ldap_uid\":\"uid\"}','','',0,'0000-00-00 00:00:00',3,0),(404,'plg_content_emailcloak','plugin','emailcloak','content',0,1,1,0,'{\"legacy\":false,\"name\":\"plg_content_emailcloak\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_CONTENT_EMAILCLOAK_XML_DESCRIPTION\",\"group\":\"\"}','{\"mode\":\"1\"}','','',0,'0000-00-00 00:00:00',1,0),(405,'plg_content_geshi','plugin','geshi','content',0,0,1,0,'{\"legacy\":false,\"name\":\"plg_content_geshi\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"\",\"authorUrl\":\"qbnz.com\\/highlighter\",\"version\":\"2.5.0\",\"description\":\"PLG_CONTENT_GESHI_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',2,0),(406,'plg_content_loadmodule','plugin','loadmodule','content',0,1,1,0,'{\"legacy\":false,\"name\":\"plg_content_loadmodule\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_LOADMODULE_XML_DESCRIPTION\",\"group\":\"\"}','{\"style\":\"xhtml\"}','','',0,'2011-09-18 15:22:50',0,0),(407,'plg_content_pagebreak','plugin','pagebreak','content',0,1,1,1,'{\"legacy\":false,\"name\":\"plg_content_pagebreak\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_CONTENT_PAGEBREAK_XML_DESCRIPTION\",\"group\":\"\"}','{\"title\":\"0\",\"article_index\":\"0\",\"article_index_text\":\"\",\"multipage_toc\":\"0\",\"showall\":\"0\",\"style\":\"pages\"}','','',42,'2012-04-24 13:52:58',4,0),(408,'plg_content_pagenavigation','plugin','pagenavigation','content',0,1,1,1,'{\"legacy\":false,\"name\":\"plg_content_pagenavigation\",\"type\":\"plugin\",\"creationDate\":\"January 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_PAGENAVIGATION_XML_DESCRIPTION\",\"group\":\"\"}','{\"position\":\"1\"}','','',0,'0000-00-00 00:00:00',5,0),(409,'plg_content_vote','plugin','vote','content',0,1,1,1,'{\"legacy\":false,\"name\":\"plg_content_vote\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_VOTE_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',6,0),(410,'plg_editors_codemirror','plugin','codemirror','editors',0,1,1,1,'{\"legacy\":false,\"name\":\"plg_editors_codemirror\",\"type\":\"plugin\",\"creationDate\":\"28 March 2011\",\"author\":\"Marijn Haverbeke\",\"copyright\":\"\",\"authorEmail\":\"N\\/A\",\"authorUrl\":\"\",\"version\":\"1.0\",\"description\":\"PLG_CODEMIRROR_XML_DESCRIPTION\",\"group\":\"\"}','{\"linenumbers\":\"0\",\"tabmode\":\"indent\"}','','',0,'0000-00-00 00:00:00',1,0),(411,'plg_editors_none','plugin','none','editors',0,1,1,1,'{\"legacy\":false,\"name\":\"plg_editors_none\",\"type\":\"plugin\",\"creationDate\":\"August 2004\",\"author\":\"Unknown\",\"copyright\":\"\",\"authorEmail\":\"N\\/A\",\"authorUrl\":\"\",\"version\":\"2.5.0\",\"description\":\"PLG_NONE_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',2,0),(412,'plg_editors_tinymce','plugin','tinymce','editors',0,1,1,1,'{\"legacy\":false,\"name\":\"plg_editors_tinymce\",\"type\":\"plugin\",\"creationDate\":\"2005-2012\",\"author\":\"Moxiecode Systems AB\",\"copyright\":\"Moxiecode Systems AB\",\"authorEmail\":\"N\\/A\",\"authorUrl\":\"tinymce.moxiecode.com\\/\",\"version\":\"3.4.9\",\"description\":\"PLG_TINY_XML_DESCRIPTION\",\"group\":\"\"}','{\"mode\":\"1\",\"skin\":\"0\",\"entity_encoding\":\"raw\",\"lang_mode\":\"0\",\"lang_code\":\"en\",\"text_direction\":\"ltr\",\"content_css\":\"1\",\"content_css_custom\":\"\",\"relative_urls\":\"1\",\"newlines\":\"0\",\"invalid_elements\":\"script,applet,iframe\",\"extended_elements\":\"\",\"toolbar\":\"top\",\"toolbar_align\":\"left\",\"html_height\":\"550\",\"html_width\":\"750\",\"resizing\":\"true\",\"resize_horizontal\":\"false\",\"element_path\":\"1\",\"fonts\":\"1\",\"paste\":\"1\",\"searchreplace\":\"1\",\"insertdate\":\"1\",\"format_date\":\"%Y-%m-%d\",\"inserttime\":\"1\",\"format_time\":\"%H:%M:%S\",\"colors\":\"1\",\"table\":\"1\",\"smilies\":\"1\",\"media\":\"1\",\"hr\":\"1\",\"directionality\":\"1\",\"fullscreen\":\"1\",\"style\":\"1\",\"layer\":\"1\",\"xhtmlxtras\":\"1\",\"visualchars\":\"1\",\"nonbreaking\":\"1\",\"template\":\"1\",\"blockquote\":\"1\",\"wordcount\":\"1\",\"advimage\":\"1\",\"advlink\":\"1\",\"advlist\":\"1\",\"autosave\":\"1\",\"contextmenu\":\"1\",\"inlinepopups\":\"1\",\"custom_plugin\":\"\",\"custom_button\":\"\"}','','',0,'0000-00-00 00:00:00',3,0),(413,'plg_editors-xtd_article','plugin','article','editors-xtd',0,1,1,1,'{\"legacy\":false,\"name\":\"plg_editors-xtd_article\",\"type\":\"plugin\",\"creationDate\":\"October 2009\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_ARTICLE_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',1,0),(414,'plg_editors-xtd_image','plugin','image','editors-xtd',0,1,1,0,'{\"legacy\":false,\"name\":\"plg_editors-xtd_image\",\"type\":\"plugin\",\"creationDate\":\"August 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_IMAGE_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',2,0),(415,'plg_editors-xtd_pagebreak','plugin','pagebreak','editors-xtd',0,1,1,0,'{\"legacy\":false,\"name\":\"plg_editors-xtd_pagebreak\",\"type\":\"plugin\",\"creationDate\":\"August 2004\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_EDITORSXTD_PAGEBREAK_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',3,0),(416,'plg_editors-xtd_readmore','plugin','readmore','editors-xtd',0,1,1,0,'{\"legacy\":false,\"name\":\"plg_editors-xtd_readmore\",\"type\":\"plugin\",\"creationDate\":\"March 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_READMORE_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',4,0),(417,'plg_search_categories','plugin','categories','search',0,1,1,0,'{\"legacy\":false,\"name\":\"plg_search_categories\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_SEARCH_CATEGORIES_XML_DESCRIPTION\",\"group\":\"\"}','{\"search_limit\":\"50\",\"search_content\":\"1\",\"search_archived\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(418,'plg_search_contacts','plugin','contacts','search',0,1,1,0,'{\"legacy\":false,\"name\":\"plg_search_contacts\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_SEARCH_CONTACTS_XML_DESCRIPTION\",\"group\":\"\"}','{\"search_limit\":\"50\",\"search_content\":\"1\",\"search_archived\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(419,'plg_search_content','plugin','content','search',0,1,1,0,'{\"legacy\":false,\"name\":\"plg_search_content\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_SEARCH_CONTENT_XML_DESCRIPTION\",\"group\":\"\"}','{\"search_limit\":\"50\",\"search_content\":\"1\",\"search_archived\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(420,'plg_search_newsfeeds','plugin','newsfeeds','search',0,1,1,0,'{\"legacy\":false,\"name\":\"plg_search_newsfeeds\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_SEARCH_NEWSFEEDS_XML_DESCRIPTION\",\"group\":\"\"}','{\"search_limit\":\"50\",\"search_content\":\"1\",\"search_archived\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(421,'plg_search_weblinks','plugin','weblinks','search',0,1,1,0,'{\"legacy\":false,\"name\":\"plg_search_weblinks\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_SEARCH_WEBLINKS_XML_DESCRIPTION\",\"group\":\"\"}','{\"search_limit\":\"50\",\"search_content\":\"1\",\"search_archived\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(422,'plg_system_languagefilter','plugin','languagefilter','system',0,0,1,1,'{\"legacy\":false,\"name\":\"plg_system_languagefilter\",\"type\":\"plugin\",\"creationDate\":\"July 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_SYSTEM_LANGUAGEFILTER_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',1,0),(423,'plg_system_p3p','plugin','p3p','system',0,1,1,1,'{\"legacy\":false,\"name\":\"plg_system_p3p\",\"type\":\"plugin\",\"creationDate\":\"September 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_P3P_XML_DESCRIPTION\",\"group\":\"\"}','{\"headers\":\"NOI ADM DEV PSAi COM NAV OUR OTRo STP IND DEM\"}','','',0,'0000-00-00 00:00:00',2,0),(424,'plg_system_cache','plugin','cache','system',0,0,1,1,'{\"legacy\":false,\"name\":\"plg_system_cache\",\"type\":\"plugin\",\"creationDate\":\"February 2007\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_CACHE_XML_DESCRIPTION\",\"group\":\"\"}','{\"browsercache\":\"0\",\"cachetime\":\"15\"}','','',0,'0000-00-00 00:00:00',9,0),(425,'plg_system_debug','plugin','debug','system',0,1,1,0,'{\"legacy\":false,\"name\":\"plg_system_debug\",\"type\":\"plugin\",\"creationDate\":\"December 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_DEBUG_XML_DESCRIPTION\",\"group\":\"\"}','{\"profile\":\"1\",\"queries\":\"1\",\"memory\":\"1\",\"language_files\":\"1\",\"language_strings\":\"1\",\"strip-first\":\"1\",\"strip-prefix\":\"\",\"strip-suffix\":\"\"}','','',0,'0000-00-00 00:00:00',4,0),(426,'plg_system_log','plugin','log','system',0,1,1,1,'{\"legacy\":false,\"name\":\"plg_system_log\",\"type\":\"plugin\",\"creationDate\":\"April 2007\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_LOG_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',5,0),(427,'plg_system_redirect','plugin','redirect','system',0,1,1,1,'{\"legacy\":false,\"name\":\"plg_system_redirect\",\"type\":\"plugin\",\"creationDate\":\"April 2009\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_REDIRECT_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',6,0),(428,'plg_system_remember','plugin','remember','system',0,1,1,1,'{\"legacy\":false,\"name\":\"plg_system_remember\",\"type\":\"plugin\",\"creationDate\":\"April 2007\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_REMEMBER_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',7,0),(429,'plg_system_sef','plugin','sef','system',0,1,1,0,'{\"legacy\":false,\"name\":\"plg_system_sef\",\"type\":\"plugin\",\"creationDate\":\"December 2007\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_SEF_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',8,0),(430,'plg_system_logout','plugin','logout','system',0,1,1,1,'{\"legacy\":false,\"name\":\"plg_system_logout\",\"type\":\"plugin\",\"creationDate\":\"April 2009\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_SYSTEM_LOGOUT_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',3,0),(431,'plg_user_contactcreator','plugin','contactcreator','user',0,0,1,1,'{\"legacy\":false,\"name\":\"plg_user_contactcreator\",\"type\":\"plugin\",\"creationDate\":\"August 2009\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_CONTACTCREATOR_XML_DESCRIPTION\",\"group\":\"\"}','{\"autowebpage\":\"\",\"category\":\"34\",\"autopublish\":\"0\"}','','',0,'0000-00-00 00:00:00',1,0),(432,'plg_user_joomla','plugin','joomla','user',0,1,1,0,'{\"legacy\":false,\"name\":\"plg_user_joomla\",\"type\":\"plugin\",\"creationDate\":\"December 2006\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2009 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_USER_JOOMLA_XML_DESCRIPTION\",\"group\":\"\"}','{\"autoregister\":\"1\"}','','',0,'0000-00-00 00:00:00',2,0),(433,'plg_user_profile','plugin','profile','user',0,0,1,1,'{\"legacy\":false,\"name\":\"plg_user_profile\",\"type\":\"plugin\",\"creationDate\":\"January 2008\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_USER_PROFILE_XML_DESCRIPTION\",\"group\":\"\"}','{\"register-require_address1\":\"1\",\"register-require_address2\":\"1\",\"register-require_city\":\"1\",\"register-require_region\":\"1\",\"register-require_country\":\"1\",\"register-require_postal_code\":\"1\",\"register-require_phone\":\"1\",\"register-require_website\":\"1\",\"register-require_favoritebook\":\"1\",\"register-require_aboutme\":\"1\",\"register-require_tos\":\"1\",\"register-require_dob\":\"1\",\"profile-require_address1\":\"1\",\"profile-require_address2\":\"1\",\"profile-require_city\":\"1\",\"profile-require_region\":\"1\",\"profile-require_country\":\"1\",\"profile-require_postal_code\":\"1\",\"profile-require_phone\":\"1\",\"profile-require_website\":\"1\",\"profile-require_favoritebook\":\"1\",\"profile-require_aboutme\":\"1\",\"profile-require_tos\":\"1\",\"profile-require_dob\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(434,'plg_extension_joomla','plugin','joomla','extension',0,1,1,1,'{\"legacy\":false,\"name\":\"plg_extension_joomla\",\"type\":\"plugin\",\"creationDate\":\"May 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_EXTENSION_JOOMLA_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',1,0),(435,'plg_content_joomla','plugin','joomla','content',0,1,1,0,'{\"legacy\":false,\"name\":\"plg_content_joomla\",\"type\":\"plugin\",\"creationDate\":\"November 2010\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_CONTENT_JOOMLA_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(436,'plg_system_languagecode','plugin','languagecode','system',0,0,1,0,'{\"legacy\":false,\"name\":\"plg_system_languagecode\",\"type\":\"plugin\",\"creationDate\":\"November 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_SYSTEM_LANGUAGECODE_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',10,0),(437,'plg_quickicon_joomlaupdate','plugin','joomlaupdate','quickicon',0,1,1,1,'{\"legacy\":false,\"name\":\"plg_quickicon_joomlaupdate\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_QUICKICON_JOOMLAUPDATE_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(438,'plg_quickicon_extensionupdate','plugin','extensionupdate','quickicon',0,1,1,1,'{\"legacy\":false,\"name\":\"plg_quickicon_extensionupdate\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_QUICKICON_EXTENSIONUPDATE_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(439,'plg_captcha_recaptcha','plugin','recaptcha','captcha',0,1,1,0,'{\"legacy\":false,\"name\":\"plg_captcha_recaptcha\",\"type\":\"plugin\",\"creationDate\":\"December 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_CAPTCHA_RECAPTCHA_XML_DESCRIPTION\",\"group\":\"\"}','{\"public_key\":\"\",\"private_key\":\"\",\"theme\":\"clean\"}','','',0,'0000-00-00 00:00:00',0,0),(440,'plg_system_highlight','plugin','highlight','system',0,1,1,0,'{\"legacy\":false,\"name\":\"plg_system_highlight\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_SYSTEM_HIGHLIGHT_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',7,0),(441,'plg_content_finder','plugin','finder','content',0,0,1,0,'{\"legacy\":false,\"name\":\"plg_content_finder\",\"type\":\"plugin\",\"creationDate\":\"December 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_CONTENT_FINDER_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(442,'plg_finder_categories','plugin','categories','finder',0,1,1,0,'{\"legacy\":false,\"name\":\"plg_finder_categories\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_FINDER_CATEGORIES_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',1,0),(443,'plg_finder_contacts','plugin','contacts','finder',0,1,1,0,'{\"legacy\":false,\"name\":\"plg_finder_contacts\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_FINDER_CONTACTS_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',2,0),(444,'plg_finder_content','plugin','content','finder',0,1,1,0,'{\"legacy\":false,\"name\":\"plg_finder_content\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_FINDER_CONTENT_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',3,0),(445,'plg_finder_newsfeeds','plugin','newsfeeds','finder',0,1,1,0,'{\"legacy\":false,\"name\":\"plg_finder_newsfeeds\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_FINDER_NEWSFEEDS_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',4,0),(446,'plg_finder_weblinks','plugin','weblinks','finder',0,1,1,0,'{\"legacy\":false,\"name\":\"plg_finder_weblinks\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PLG_FINDER_WEBLINKS_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',5,0),(500,'atomic','template','atomic','',0,1,1,0,'{\"legacy\":false,\"name\":\"atomic\",\"type\":\"template\",\"creationDate\":\"10\\/10\\/09\",\"author\":\"Ron Severdia\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"contact@kontentdesign.com\",\"authorUrl\":\"http:\\/\\/www.kontentdesign.com\",\"version\":\"2.5.0\",\"description\":\"TPL_ATOMIC_XML_DESCRIPTION\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(502,'bluestork','template','bluestork','',1,1,1,0,'{\"legacy\":false,\"name\":\"bluestork\",\"type\":\"template\",\"creationDate\":\"07\\/02\\/09\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"TPL_BLUESTORK_XML_DESCRIPTION\",\"group\":\"\"}','{\"useRoundedCorners\":\"1\",\"showSiteName\":\"0\",\"textBig\":\"0\",\"highContrast\":\"0\"}','','',0,'0000-00-00 00:00:00',0,0),(504,'hathor','template','hathor','',1,1,1,0,'{\"legacy\":false,\"name\":\"hathor\",\"type\":\"template\",\"creationDate\":\"May 2010\",\"author\":\"Andrea Tarr\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"hathor@tarrconsulting.com\",\"authorUrl\":\"http:\\/\\/www.tarrconsulting.com\",\"version\":\"2.5.0\",\"description\":\"TPL_HATHOR_XML_DESCRIPTION\",\"group\":\"\"}','{\"showSiteName\":\"0\",\"colourChoice\":\"0\",\"boldText\":\"0\"}','','',0,'0000-00-00 00:00:00',0,0),(600,'English (United Kingdom)','language','en-GB','',0,1,1,1,'{\"legacy\":false,\"name\":\"English (United Kingdom)\",\"type\":\"language\",\"creationDate\":\"2008-03-15\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"en-GB site language\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(601,'English (United Kingdom)','language','en-GB','',1,1,1,1,'{\"legacy\":false,\"name\":\"English (United Kingdom)\",\"type\":\"language\",\"creationDate\":\"2008-03-15\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"en-GB administrator language\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(700,'files_joomla','file','joomla','',0,1,1,1,'{\"legacy\":false,\"name\":\"files_joomla\",\"type\":\"file\",\"creationDate\":\"April 2012\",\"author\":\"Joomla! Project\",\"copyright\":\"(C) 2005 - 2012 Open Source Matters. All rights reserved\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"2.5.4\",\"description\":\"FILES_JOOMLA_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(800,'PKG_JOOMLA','package','pkg_joomla','',0,1,1,1,'{\"legacy\":false,\"name\":\"PKG_JOOMLA\",\"type\":\"package\",\"creationDate\":\"2006\",\"author\":\"Joomla! Project\",\"copyright\":\"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"http:\\/\\/www.joomla.org\",\"version\":\"2.5.0\",\"description\":\"PKG_JOOMLA_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(10000,'','language','zh-CN','',0,1,0,0,'{\"legacy\":true,\"name\":\"\\u7b80\\u4f53\\u4e2d\\u6587\",\"type\":\"language\",\"creationDate\":\"2012-01-22\",\"author\":\"CHN Translation Team\",\"copyright\":\"Copyright (C) 2010 CHN Joomla Translation Team  (http:\\/\\/joomlacode.org\\/gf\\/project\\/choice\\/). All rights reserved.\",\"authorEmail\":\"zhous1998@sohu.com\",\"authorUrl\":\"www.joomla.cn\",\"version\":\"2.5.0\",\"description\":\"\\n    \\n<div align=\\\"center\\\">\\n <table border=\\\"0\\\" width=\\\"90%\\\">\\n  <table width=\\\"100%\\\" border=\\\"0\\\">\\n  <tr>\\n    <td colspan=\\\"2\\\">Chinese language for Joomla 1.6 back-end. Translated by CHN Joomla Translation Team, one of Joomla Accredited Translations.<\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">Joomla 2.5 \\u7b80\\u4f53\\u4e2d\\u6587\\u8bed\\u8a00\\u662f\\u7531Joomla\\u6388\\u6743\\u7ffb\\u8bd1\\u7ec4\\u7684Derek Joe\\u5728Joomla 1.6\\u7ffb\\u8bd1\\u5de5\\u4f5c\\u7684\\u57fa\\u7840\\u4e0a\\u8865\\u5145\\u7ffb\\u8bd1\\u3002<\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">Joomla 1.6\\u7b80\\u4f53\\u4e2d\\u6587\\u8bed\\u8a00\\u5305\\u7684\\u4e3b\\u8981\\u8d21\\u732e\\u4eba\\uff1a<\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">\\u524d\\u53f0\\uff1a <a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/wuyujie\\/\\\" target=\\\"_blank\\\">\\u6b66\\u7389\\u6770<\\/a>(wuyujie)\\u3001 <a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/gzpan123\\/\\\" target=\\\"_blank\\\">\\u90ed\\u5fd7\\u6500<\\/a><\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">\\u540e\\u53f0\\uff1a <a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/keydiagram\\/\\\" target=\\\"_blank\\\">Key Diagram<\\/a>\\u3001<a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/tchyusuf\\/\\\">Yusuf  Wang<\\/a><\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">\\u5b89\\u88c5\\uff1a <a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/freechoice\\/\\\" target=\\\"_blank\\\">Johnathan Cheun<\\/a>\\u3001<a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/tchyusuf\\/\\\">Yusuf  Wang<\\/a>\\u3001 <a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/zhous\\/\\\" target=\\\"_blank\\\">Derek Joe<\\/a><\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">\\u793a\\u8303\\u5185\\u5bb9\\u53ca\\u7f16\\u8f91\\u5668\\uff1a <a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/zhous\\/\\\" target=\\\"_blank\\\">Derek Joe<\\/a><\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">\\u591a\\u8c22\\u5927\\u5bb6\\u7684\\u8f9b\\u52e4\\u52b3\\u52a8\\uff01\\u8c22\\u8c22wayne82\\u7684\\u53cd\\u9988\\u4e0e\\u5efa\\u8bae\\uff01<\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td width=\\\"132\\\"><p><a href=\\\"http:\\/\\/www.joomla.cn\\/index.php?option=com_kunena&func=showcat&catid=34&Itemid=46&lang=zh\\\" target=\\\"_blank\\\"><img src=\\\"http:\\/\\/www.joomla.cn\\/images\\/aboutjoomlacn.png\\\" alt=\\\"\\u56e7\\u5566!\\u4e2d\\u56fd\\\" width=\\\"130\\\" height=\\\"70\\\" align=\\\"left\\\" longdesc=\\\"http:\\/\\/www.joomla.cn\\\"><br \\/>\\n    <\\/a><\\/p><\\/td>\\n    <td valign=\\\"middle\\\"><a href=\\\"http:\\/\\/www.joomla.cn\\/index.php?option=com_kunena&func=showcat&catid=34&Itemid=46&lang=zh\\\" target=\\\"_blank\\\">Joomla\\u53ca\\u5176\\u6269\\u5c55\\u6c49\\u5316\\u7684\\u5206\\u4eab\\u4e0e\\u8ba8\\u8bba\\u8bf7\\u8bbf\\u95ee\\\"\\u56e7\\u5566!\\u4e2d\\u56fd\\\"<\\/a><br \\/>\\n      <b>\\u6b22\\u8fce\\u559c\\u6b22\\u7ffb\\u8bd1\\u4e14\\u61c2\\u5f97\\u4f7f\\u7528SVN\\u7684\\u670b\\u53cb<\\/b><br \\/>\\n    <a href=\\\"http:\\/\\/www.joomla.cn\\/index.php?option=com_kunena&func=view&catid=34&id=9537&Itemid=46\\\" target=\\\"_blank\\\"><b>\\u52a0\\u5165\\u6211\\u4eec\\u7684\\u7ffb\\u8bd1\\u7ec4\\uff08\\u771f\\u6b63\\u81ea\\u4e3b\\u7684\\u534f\\u4f5c\\u65b9\\u5f0f\\uff09<\\/b><\\/a><\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">&nbsp;<\\/td>\\n  <\\/tr>\\n<\\/table>\\n <\\/div>\\n  \\n\\t\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10001,'','language','zh-CN','',1,1,0,0,'{\"legacy\":true,\"name\":\"\\u7b80\\u4f53\\u4e2d\\u6587\",\"type\":\"language\",\"creationDate\":\"2012-01-22\",\"author\":\"Derek Joe(zhous)\",\"copyright\":\"Copyright (C) 2010 CHN Joomla Translation (http:\\/\\/joomlacode.org\\/gf\\/project\\/choice\\/). All rights reserved.\",\"authorEmail\":\"zhous1998@sohu.com\",\"authorUrl\":\"\",\"version\":\"2.5.0\",\"description\":\"\\n\\t    \\n<div align=\\\"center\\\">\\n <table border=\\\"0\\\" width=\\\"90%\\\">\\n  <table width=\\\"100%\\\" border=\\\"0\\\">\\n  <tr>\\n    <td colspan=\\\"2\\\">Chinese language for Joomla 2.5 back-end. Translated by CHN Joomla Translation Team, one of Joomla Accredited Translations.<\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">Joomla 2.5 \\u7b80\\u4f53\\u4e2d\\u6587\\u8bed\\u8a00\\u662f\\u7531Joomla\\u6388\\u6743\\u7ffb\\u8bd1\\u7ec4\\u7684Derek Joe\\u5728Joomla 1.6\\u7ffb\\u8bd1\\u5de5\\u4f5c\\u7684\\u57fa\\u7840\\u4e0a\\u8865\\u5145\\u7ffb\\u8bd1\\u3002<\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">Joomla 1.6\\u7b80\\u4f53\\u4e2d\\u6587\\u8bed\\u8a00\\u5305\\u7684\\u4e3b\\u8981\\u8d21\\u732e\\u4eba\\uff1a<\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">\\u524d\\u53f0\\uff1a <a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/wuyujie\\/\\\" target=\\\"_blank\\\">\\u6b66\\u7389\\u6770<\\/a>(wuyujie)\\u3001 <a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/gzpan123\\/\\\" target=\\\"_blank\\\">\\u90ed\\u5fd7\\u6500<\\/a><\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">\\u540e\\u53f0\\uff1a <a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/keydiagram\\/\\\" target=\\\"_blank\\\">Key Diagram<\\/a>\\u3001<a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/tchyusuf\\/\\\">Yusuf  Wang<\\/a><\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">\\u5b89\\u88c5\\uff1a <a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/freechoice\\/\\\" target=\\\"_blank\\\">Johnathan Cheun<\\/a>\\u3001<a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/tchyusuf\\/\\\">Yusuf  Wang<\\/a>\\u3001 <a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/zhous\\/\\\" target=\\\"_blank\\\">Derek Joe<\\/a><\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">\\u793a\\u8303\\u5185\\u5bb9\\u53ca\\u7f16\\u8f91\\u5668\\uff1a <a href=\\\"http:\\/\\/joomlacode.org\\/gf\\/user\\/zhous\\/\\\" target=\\\"_blank\\\">Derek Joe<\\/a><\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">\\u591a\\u8c22\\u5927\\u5bb6\\u7684\\u8f9b\\u52e4\\u52b3\\u52a8\\uff01\\u8c22\\u8c22wayne82\\u7684\\u53cd\\u9988\\u4e0e\\u5efa\\u8bae\\uff01<\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td width=\\\"132\\\"><p><a href=\\\"http:\\/\\/www.joomla.cn\\/index.php?option=com_kunena&func=showcat&catid=34&Itemid=46&lang=zh\\\" target=\\\"_blank\\\"><img src=\\\"http:\\/\\/www.joomla.cn\\/images\\/aboutjoomlacn.png\\\" alt=\\\"\\u56e7\\u5566!\\u4e2d\\u56fd\\\" width=\\\"130\\\" height=\\\"70\\\" align=\\\"left\\\" longdesc=\\\"http:\\/\\/www.joomla.cn\\\"><br \\/>\\n    <\\/a><\\/p><\\/td>\\n    <td valign=\\\"middle\\\"><a href=\\\"http:\\/\\/www.joomla.cn\\/index.php?option=com_kunena&func=showcat&catid=34&Itemid=46&lang=zh\\\" target=\\\"_blank\\\">Joomla\\u53ca\\u5176\\u6269\\u5c55\\u6c49\\u5316\\u7684\\u5206\\u4eab\\u4e0e\\u8ba8\\u8bba\\u8bf7\\u8bbf\\u95ee\\\"\\u56e7\\u5566!\\u4e2d\\u56fd\\\"<\\/a><br \\/>\\n      <b>\\u6b22\\u8fce\\u559c\\u6b22\\u7ffb\\u8bd1\\u4e14\\u61c2\\u5f97\\u4f7f\\u7528SVN\\u7684\\u670b\\u53cb<\\/b><br \\/>\\n    <a href=\\\"http:\\/\\/www.joomla.cn\\/index.php?option=com_kunena&func=view&catid=34&id=9537&Itemid=46\\\" target=\\\"_blank\\\"><b>\\u52a0\\u5165\\u6211\\u4eec\\u7684\\u7ffb\\u8bd1\\u7ec4\\uff08\\u771f\\u6b63\\u81ea\\u4e3b\\u7684\\u534f\\u4f5c\\u65b9\\u5f0f\\uff09<\\/b><\\/a><\\/td>\\n  <\\/tr>\\n  <tr>\\n    <td colspan=\\\"2\\\">&nbsp;<\\/td>\\n  <\\/tr>\\n<\\/table>\\n <\\/div>\\n  \\n\\t\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10002,'zh-CN','package','pkg_zh-CN','',0,1,1,0,'{\"legacy\":false,\"name\":\"\\u7b80\\u4f53\\u4e2d\\u6587Simplified Chinese\",\"type\":\"package\",\"creationDate\":\"2012-01-24\",\"author\":\"CHN Translation Team\",\"copyright\":\"Copyright (C) 2010 CHN Joomla Translation Team  (http:\\/\\/joomlacode.org\\/gf\\/project\\/choice\\/). All rights reserved.\",\"authorEmail\":\"zhous1998@sohu.com\",\"authorUrl\":\"www.joomla.cn\",\"version\":\"2.5.0v1\",\"description\":\"Joomla 2.5.0\\u8bed\\u8a00\\u662f\\u7531Joomla\\u5b98\\u65b9\\u7ffb\\u8bd1\\u7ec4\\u7684Derek Joe\\u7ec4\\u7ec7\\u7ffb\\u8bd1\\u3002\\u5de5\\u4f5c\\u662f\\u5728Joomla1.6\\u7684\\u57fa\\u7840\\u4e0a\\u8fdb\\u884c\\u7684\\u3002Joomla 2.5.0\\u8bed\\u8a00\\u7684\\u8865\\u5145\\u7531Derek Joe\\u5b8c\\u6210\\uff0cEric Wong\\uff08http:\\/\\/berocks2.com\\/\\uff09\\u534f\\u52a9\\u6821\\u5bf9\\u3002\\u611f\\u8c22Joomla 1.6\\u7ffb\\u8bd1\\u7ec4\\u7684\\u6240\\u6709\\u5fd7\\u613f\\u8005\\uff1a\\u6b66\\u7389\\u6770\\u3001Key Diagram\\u3001Yusuf  Wang\\u3001\\u90ed\\u5fd7\\u6500\\uff01\\u8c22\\u8c22wayne82\\u7684\\u53cd\\u9988\\u4e0e\\u5efa\\u8bae\\uff01\\u7ffb\\u8bd1\\u57fa\\u5730\\uff1a\\u56e7\\u5566!\\u4e2d\\u56fd\\uff08Joomla.cn\\uff09\\u3002\\u6b22\\u8fce\\u559c\\u6b22\\u7ffb\\u8bd1\\u4e14\\u61c2\\u5f97\\u4f7f\\u7528SVN\\u7684\\u670b\\u53cb\\u968f\\u65f6\\u53ef\\u4ee5\\u52a0\\u5165\\u6211\\u4eec\\u7684\\u5f00\\u6e90\\u7ffb\\u8bd1\\u7ec4\\u3002\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10003,'Editor - JCE','plugin','jce','editors',0,1,1,0,'{\"legacy\":true,\"name\":\"Editor - JCE\",\"type\":\"plugin\",\"creationDate\":\"15 February 2012\",\"author\":\"Ryan Demmer\",\"copyright\":\"2006-2010 Ryan Demmer\",\"authorEmail\":\"info@joomlacontenteditor.net\",\"authorUrl\":\"http:\\/\\/www.joomlacontenteditor.net\",\"version\":\"2.0.21\",\"description\":\"WF_EDITOR_PLUGIN_DESC\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10004,'jce','component','com_jce','',1,1,0,0,'{\"legacy\":true,\"name\":\"JCE\",\"type\":\"component\",\"creationDate\":\"15 February 2012\",\"author\":\"Ryan Demmer\",\"copyright\":\"Copyright (C) 2006 - 2011 Ryan Demmer. All rights reserved\",\"authorEmail\":\"info@joomlacontenteditor.net\",\"authorUrl\":\"www.joomlacontenteditor.net\",\"version\":\"2.0.21\",\"description\":\"WF_ADMIN_DESC\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10005,'xcloner-backupandrestore','component','com_xcloner-backupandrestore','',1,1,0,0,'{\"legacy\":true,\"name\":\"XCloner-BackupandRestore\",\"type\":\"component\",\"creationDate\":\"Mar 2012\",\"author\":\"XCloner.com\",\"copyright\":\"XCloner.com\",\"authorEmail\":\"\",\"authorUrl\":\"\",\"version\":\"3.1.1\",\"description\":\"\\n      <h2>XCloner Backup&Restore Utility<\\/h2>\\n      <pre>XCloner is a tool that will help you manage your website backups, generate\\/restore\\/move so your website will be always secured!\\n\\t   <a href=\\\"http:\\/\\/www.xcloner.com\\\"><img src=\\\"http:\\/\\/www.xcloner.com\\/xcloner_p.jpg\\\" border=0 style=\\\"float:left; padding-right:10px;padding-bottom: 100px;padding-top:20px;\\\"><\\/a>\\n      Features:\\n       -cron script to generate backup\\n       -multiple backup options\\n       -restore tool to move the website rapidly to other locations\\n       -multiple locations of where you could store the backup safelly\\n       -comnpatible with both Joomla 1.5.x and 1.6.x\\n\\n       For reports and suggestions please contact us at info@xcloner.com or visit us on <a href=\'http:\\/\\/www.xcloner.com\'>http:\\/\\/www.xcloner.com<\\/a>\\n        <\\/pre>\\n      <br\\/>\\n\\n      XCloner.com &copy; 2006-2011 | <a href=\\\"http:\\/\\/www.xcloner.com\\\">www.xcloner.com<\\/a>\\n      <br\\/><p\\/><br\\/>\\n\\t\\n    \",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10007,'sun','template','sun','',0,1,1,0,'{\"legacy\":false,\"name\":\"sun\",\"type\":\"template\",\"creationDate\":\"2012-4-20\",\"author\":\"william\",\"copyright\":\"Copyright \\u00a9 william wen\",\"authorEmail\":\"william0760@qq.com\",\"authorUrl\":\"\",\"version\":\"1.0.0\",\"description\":\"\",\"group\":\"\"}','[]','','',0,'0000-00-00 00:00:00',0,0),(10008,'com_easybookreloaded','component','com_easybookreloaded','',1,1,0,0,'{\"legacy\":false,\"name\":\"com_easybookreloaded\",\"type\":\"component\",\"creationDate\":\"26-Jan-2012\",\"author\":\"Kubik-Rubik.de - Viktor Vogel\",\"copyright\":\"Copyright 2012 Viktor Vogel - All rights reserved\",\"authorEmail\":\"admin@kubik-rubik.de\",\"authorUrl\":\"http:\\/\\/www.kubik-rubik.de\",\"version\":\"2.5-1\",\"description\":\"COM_EASYBOOKRELOADED_XML_DESCRIPTION\",\"group\":\"\"}','{\"offline\":\"0\",\"add_acl\":[\"1\"],\"admin_acl\":[\"8\"],\"default_published\":\"1\",\"send_mail\":\"0\",\"send_mail_html\":\"0\",\"emailfornotification\":\"\",\"secret_word\":\"\",\"valid_time_emailnot\":\"1\",\"badwordfilter\":\"1\",\"entries_perpage\":\"10\",\"entries_order\":\"DESC\",\"show_page_title\":\"0\",\"show_introtext\":\"0\",\"introtext\":\"\",\"support_bbcode\":\"0\",\"support_smilie\":\"0\",\"smilie_set\":\"0\",\"support_link\":\"1\",\"support_mail\":\"1\",\"support_pic\":\"0\",\"support_code\":\"0\",\"support_youtube\":\"0\",\"geshi_lines\":\"1\",\"wordwrap\":\"1\",\"maxlength\":\"75\",\"template\":\"2\",\"date_format\":\"0\",\"show_count_entries\":\"1\",\"show_logo\":\"0\",\"show_rating\":\"0\",\"rating_max\":\"5\",\"show_rating_type\":\"1\",\"enable_log\":\"1\",\"enable_log_notice\":\"0\",\"registered_username\":\"0\",\"show_mail\":\"0\",\"require_mail\":\"1\",\"show_title\":\"0\",\"require_title\":\"0\",\"show_loca\":\"0\",\"show_home\":\"0\",\"nofollow_home\":\"1\",\"show_icq\":\"0\",\"show_aim\":\"0\",\"show_msn\":\"0\",\"show_yah\":\"0\",\"show_skype\":\"0\",\"enable_spam\":\"1\",\"max_value\":\"20\",\"operator\":\"0\",\"type_time_sec\":\"5\",\"enable_spam_reg\":\"1\",\"maxnumberlinks\":\"2\",\"block_ip\":\"\",\"timelock_ip\":\"30\"}','','',0,'0000-00-00 00:00:00',0,0),(10009,'aicontactsafe','component','com_aicontactsafe','',1,1,0,0,'{\"legacy\":true,\"name\":\"aiContactSafe\",\"type\":\"component\",\"creationDate\":\"April 2010\",\"author\":\"Algis Info Grup SRL\",\"copyright\":\"(c)2010 Algis Info Grup SRL. All rights reserved.\",\"authorEmail\":\"contact@algis.ro\",\"authorUrl\":\"www.algis.ro\",\"version\":\"2.0.17.stable\",\"description\":\"A contact form in which you can add any number of custom fields.\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10010,'com_djimageslider','component','com_djimageslider','',1,1,0,0,'{\"legacy\":false,\"name\":\"com_djimageslider\",\"type\":\"component\",\"creationDate\":\"January 2011\",\"author\":\"Blue Constant Media LTD\",\"copyright\":\"Copyright (C) 2010 Blue Constant Media LTD, All rights reserved.\",\"authorEmail\":\"contact@design-joomla.eu\",\"authorUrl\":\"http:\\/\\/design-joomla.eu\",\"version\":\"1.3.0 RC1\",\"description\":\"Create custom slides for DJ Image Slider module\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10011,'DJ-Image Slider','module','mod_djimageslider','',0,1,0,0,'{\"legacy\":false,\"name\":\"DJ-Image Slider\",\"type\":\"module\",\"creationDate\":\"January 2011\",\"author\":\"Blue Constant Media LTD\",\"copyright\":\"Copyright (C) 2010 Blue Constant Media LTD, All rights reserved.\",\"authorEmail\":\"contact@design-joomla.eu\",\"authorUrl\":\"http:\\/\\/design-joomla.eu\",\"version\":\"1.3.RC6\",\"description\":\"DJ-Image Slider Module\",\"group\":\"\"}','{\"slider_source\":\"0\",\"slider_type\":\"0\",\"link_image\":\"1\",\"image_folder\":\"images\\/sampledata\\/fruitshop\",\"link\":\"\",\"show_title\":\"1\",\"show_desc\":\"1\",\"show_readmore\":\"0\",\"link_title\":\"1\",\"link_desc\":\"0\",\"limit_desc\":\"\",\"image_width\":\"150\",\"image_height\":\"90\",\"fit_to\":\"0\",\"visible_images\":\"3\",\"space_between_images\":\"10\",\"max_images\":\"20\",\"sort_by\":\"1\",\"effect\":\"Cubic\",\"autoplay\":\"1\",\"show_buttons\":\"1\",\"show_arrows\":\"1\",\"show_custom_nav\":\"0\",\"desc_width\":\"\",\"desc_bottom\":\"0\",\"desc_horizontal\":\"0\",\"left_arrow\":\"\",\"right_arrow\":\"\",\"play_button\":\"\",\"pause_button\":\"\",\"arrows_top\":\"30\",\"arrows_horizontal\":\"5\",\"effect_type\":\"0\",\"duration\":\"\",\"delay\":\"\",\"preload\":\"800\",\"cache\":\"0\"}','','',0,'0000-00-00 00:00:00',0,0);
/*!40000 ALTER TABLE `uxlo0_extensions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_finder_filters`
--

DROP TABLE IF EXISTS `uxlo0_finder_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_finder_filters` (
  `filter_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL,
  `created_by_alias` varchar(255) NOT NULL,
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `map_count` int(10) unsigned NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  `params` mediumtext,
  PRIMARY KEY (`filter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_finder_filters`
--

LOCK TABLES `uxlo0_finder_filters` WRITE;
/*!40000 ALTER TABLE `uxlo0_finder_filters` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_finder_filters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_finder_links`
--

DROP TABLE IF EXISTS `uxlo0_finder_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_finder_links` (
  `link_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `route` varchar(255) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `indexdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `md5sum` varchar(32) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `state` int(5) DEFAULT '1',
  `access` int(5) DEFAULT '0',
  `language` varchar(8) NOT NULL,
  `publish_start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `list_price` double unsigned NOT NULL DEFAULT '0',
  `sale_price` double unsigned NOT NULL DEFAULT '0',
  `type_id` int(11) NOT NULL,
  `object` mediumblob NOT NULL,
  PRIMARY KEY (`link_id`),
  KEY `idx_type` (`type_id`),
  KEY `idx_title` (`title`),
  KEY `idx_md5` (`md5sum`),
  KEY `idx_url` (`url`(75)),
  KEY `idx_published_list` (`published`,`state`,`access`,`publish_start_date`,`publish_end_date`,`list_price`),
  KEY `idx_published_sale` (`published`,`state`,`access`,`publish_start_date`,`publish_end_date`,`sale_price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_finder_links`
--

LOCK TABLES `uxlo0_finder_links` WRITE;
/*!40000 ALTER TABLE `uxlo0_finder_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_finder_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_finder_links_terms0`
--

DROP TABLE IF EXISTS `uxlo0_finder_links_terms0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_finder_links_terms0` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_finder_links_terms0`
--

LOCK TABLES `uxlo0_finder_links_terms0` WRITE;
/*!40000 ALTER TABLE `uxlo0_finder_links_terms0` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_finder_links_terms0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_finder_links_terms1`
--

DROP TABLE IF EXISTS `uxlo0_finder_links_terms1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_finder_links_terms1` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_finder_links_terms1`
--

LOCK TABLES `uxlo0_finder_links_terms1` WRITE;
/*!40000 ALTER TABLE `uxlo0_finder_links_terms1` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_finder_links_terms1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_finder_links_terms2`
--

DROP TABLE IF EXISTS `uxlo0_finder_links_terms2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_finder_links_terms2` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_finder_links_terms2`
--

LOCK TABLES `uxlo0_finder_links_terms2` WRITE;
/*!40000 ALTER TABLE `uxlo0_finder_links_terms2` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_finder_links_terms2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_finder_links_terms3`
--

DROP TABLE IF EXISTS `uxlo0_finder_links_terms3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_finder_links_terms3` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_finder_links_terms3`
--

LOCK TABLES `uxlo0_finder_links_terms3` WRITE;
/*!40000 ALTER TABLE `uxlo0_finder_links_terms3` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_finder_links_terms3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_finder_links_terms4`
--

DROP TABLE IF EXISTS `uxlo0_finder_links_terms4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_finder_links_terms4` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_finder_links_terms4`
--

LOCK TABLES `uxlo0_finder_links_terms4` WRITE;
/*!40000 ALTER TABLE `uxlo0_finder_links_terms4` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_finder_links_terms4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_finder_links_terms5`
--

DROP TABLE IF EXISTS `uxlo0_finder_links_terms5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_finder_links_terms5` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_finder_links_terms5`
--

LOCK TABLES `uxlo0_finder_links_terms5` WRITE;
/*!40000 ALTER TABLE `uxlo0_finder_links_terms5` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_finder_links_terms5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_finder_links_terms6`
--

DROP TABLE IF EXISTS `uxlo0_finder_links_terms6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_finder_links_terms6` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_finder_links_terms6`
--

LOCK TABLES `uxlo0_finder_links_terms6` WRITE;
/*!40000 ALTER TABLE `uxlo0_finder_links_terms6` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_finder_links_terms6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_finder_links_terms7`
--

DROP TABLE IF EXISTS `uxlo0_finder_links_terms7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_finder_links_terms7` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_finder_links_terms7`
--

LOCK TABLES `uxlo0_finder_links_terms7` WRITE;
/*!40000 ALTER TABLE `uxlo0_finder_links_terms7` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_finder_links_terms7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_finder_links_terms8`
--

DROP TABLE IF EXISTS `uxlo0_finder_links_terms8`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_finder_links_terms8` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_finder_links_terms8`
--

LOCK TABLES `uxlo0_finder_links_terms8` WRITE;
/*!40000 ALTER TABLE `uxlo0_finder_links_terms8` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_finder_links_terms8` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_finder_links_terms9`
--

DROP TABLE IF EXISTS `uxlo0_finder_links_terms9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_finder_links_terms9` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_finder_links_terms9`
--

LOCK TABLES `uxlo0_finder_links_terms9` WRITE;
/*!40000 ALTER TABLE `uxlo0_finder_links_terms9` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_finder_links_terms9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_finder_links_termsa`
--

DROP TABLE IF EXISTS `uxlo0_finder_links_termsa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_finder_links_termsa` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_finder_links_termsa`
--

LOCK TABLES `uxlo0_finder_links_termsa` WRITE;
/*!40000 ALTER TABLE `uxlo0_finder_links_termsa` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_finder_links_termsa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_finder_links_termsb`
--

DROP TABLE IF EXISTS `uxlo0_finder_links_termsb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_finder_links_termsb` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_finder_links_termsb`
--

LOCK TABLES `uxlo0_finder_links_termsb` WRITE;
/*!40000 ALTER TABLE `uxlo0_finder_links_termsb` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_finder_links_termsb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_finder_links_termsc`
--

DROP TABLE IF EXISTS `uxlo0_finder_links_termsc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_finder_links_termsc` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_finder_links_termsc`
--

LOCK TABLES `uxlo0_finder_links_termsc` WRITE;
/*!40000 ALTER TABLE `uxlo0_finder_links_termsc` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_finder_links_termsc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_finder_links_termsd`
--

DROP TABLE IF EXISTS `uxlo0_finder_links_termsd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_finder_links_termsd` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_finder_links_termsd`
--

LOCK TABLES `uxlo0_finder_links_termsd` WRITE;
/*!40000 ALTER TABLE `uxlo0_finder_links_termsd` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_finder_links_termsd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_finder_links_termse`
--

DROP TABLE IF EXISTS `uxlo0_finder_links_termse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_finder_links_termse` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_finder_links_termse`
--

LOCK TABLES `uxlo0_finder_links_termse` WRITE;
/*!40000 ALTER TABLE `uxlo0_finder_links_termse` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_finder_links_termse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_finder_links_termsf`
--

DROP TABLE IF EXISTS `uxlo0_finder_links_termsf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_finder_links_termsf` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_finder_links_termsf`
--

LOCK TABLES `uxlo0_finder_links_termsf` WRITE;
/*!40000 ALTER TABLE `uxlo0_finder_links_termsf` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_finder_links_termsf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_finder_taxonomy`
--

DROP TABLE IF EXISTS `uxlo0_finder_taxonomy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_finder_taxonomy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `state` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `access` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `state` (`state`),
  KEY `ordering` (`ordering`),
  KEY `access` (`access`),
  KEY `idx_parent_published` (`parent_id`,`state`,`access`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_finder_taxonomy`
--

LOCK TABLES `uxlo0_finder_taxonomy` WRITE;
/*!40000 ALTER TABLE `uxlo0_finder_taxonomy` DISABLE KEYS */;
INSERT INTO `uxlo0_finder_taxonomy` VALUES (1,0,'ROOT',0,0,0);
/*!40000 ALTER TABLE `uxlo0_finder_taxonomy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_finder_taxonomy_map`
--

DROP TABLE IF EXISTS `uxlo0_finder_taxonomy_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_finder_taxonomy_map` (
  `link_id` int(10) unsigned NOT NULL,
  `node_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`node_id`),
  KEY `link_id` (`link_id`),
  KEY `node_id` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_finder_taxonomy_map`
--

LOCK TABLES `uxlo0_finder_taxonomy_map` WRITE;
/*!40000 ALTER TABLE `uxlo0_finder_taxonomy_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_finder_taxonomy_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_finder_terms`
--

DROP TABLE IF EXISTS `uxlo0_finder_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_finder_terms` (
  `term_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` float unsigned NOT NULL DEFAULT '0',
  `soundex` varchar(75) NOT NULL,
  `links` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `idx_term` (`term`),
  KEY `idx_term_phrase` (`term`,`phrase`),
  KEY `idx_stem_phrase` (`stem`,`phrase`),
  KEY `idx_soundex_phrase` (`soundex`,`phrase`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_finder_terms`
--

LOCK TABLES `uxlo0_finder_terms` WRITE;
/*!40000 ALTER TABLE `uxlo0_finder_terms` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_finder_terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_finder_terms_common`
--

DROP TABLE IF EXISTS `uxlo0_finder_terms_common`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_finder_terms_common` (
  `term` varchar(75) NOT NULL,
  `language` varchar(3) NOT NULL,
  KEY `idx_word_lang` (`term`,`language`),
  KEY `idx_lang` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_finder_terms_common`
--

LOCK TABLES `uxlo0_finder_terms_common` WRITE;
/*!40000 ALTER TABLE `uxlo0_finder_terms_common` DISABLE KEYS */;
INSERT INTO `uxlo0_finder_terms_common` VALUES ('a','en'),('about','en'),('after','en'),('ago','en'),('all','en'),('am','en'),('an','en'),('and','en'),('ani','en'),('any','en'),('are','en'),('aren\'t','en'),('as','en'),('at','en'),('be','en'),('but','en'),('by','en'),('for','en'),('from','en'),('get','en'),('go','en'),('how','en'),('if','en'),('in','en'),('into','en'),('is','en'),('isn\'t','en'),('it','en'),('its','en'),('me','en'),('more','en'),('most','en'),('must','en'),('my','en'),('new','en'),('no','en'),('none','en'),('not','en'),('noth','en'),('nothing','en'),('of','en'),('off','en'),('often','en'),('old','en'),('on','en'),('onc','en'),('once','en'),('onli','en'),('only','en'),('or','en'),('other','en'),('our','en'),('ours','en'),('out','en'),('over','en'),('page','en'),('she','en'),('should','en'),('small','en'),('so','en'),('some','en'),('than','en'),('thank','en'),('that','en'),('the','en'),('their','en'),('theirs','en'),('them','en'),('then','en'),('there','en'),('these','en'),('they','en'),('this','en'),('those','en'),('thus','en'),('time','en'),('times','en'),('to','en'),('too','en'),('true','en'),('under','en'),('until','en'),('up','en'),('upon','en'),('use','en'),('user','en'),('users','en'),('veri','en'),('version','en'),('very','en'),('via','en'),('want','en'),('was','en'),('way','en'),('were','en'),('what','en'),('when','en'),('where','en'),('whi','en'),('which','en'),('who','en'),('whom','en'),('whose','en'),('why','en'),('wide','en'),('will','en'),('with','en'),('within','en'),('without','en'),('would','en'),('yes','en'),('yet','en'),('you','en'),('your','en'),('yours','en');
/*!40000 ALTER TABLE `uxlo0_finder_terms_common` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_finder_tokens`
--

DROP TABLE IF EXISTS `uxlo0_finder_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_finder_tokens` (
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` float unsigned NOT NULL DEFAULT '1',
  `context` tinyint(1) unsigned NOT NULL DEFAULT '2',
  KEY `idx_word` (`term`),
  KEY `idx_context` (`context`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_finder_tokens`
--

LOCK TABLES `uxlo0_finder_tokens` WRITE;
/*!40000 ALTER TABLE `uxlo0_finder_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_finder_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_finder_tokens_aggregate`
--

DROP TABLE IF EXISTS `uxlo0_finder_tokens_aggregate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_finder_tokens_aggregate` (
  `term_id` int(10) unsigned NOT NULL,
  `map_suffix` char(1) NOT NULL,
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `term_weight` float unsigned NOT NULL,
  `context` tinyint(1) unsigned NOT NULL DEFAULT '2',
  `context_weight` float unsigned NOT NULL,
  `total_weight` float unsigned NOT NULL,
  KEY `token` (`term`),
  KEY `keyword_id` (`term_id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_finder_tokens_aggregate`
--

LOCK TABLES `uxlo0_finder_tokens_aggregate` WRITE;
/*!40000 ALTER TABLE `uxlo0_finder_tokens_aggregate` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_finder_tokens_aggregate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_finder_types`
--

DROP TABLE IF EXISTS `uxlo0_finder_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_finder_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `mime` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_finder_types`
--

LOCK TABLES `uxlo0_finder_types` WRITE;
/*!40000 ALTER TABLE `uxlo0_finder_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_finder_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_languages`
--

DROP TABLE IF EXISTS `uxlo0_languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_languages` (
  `lang_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `lang_code` char(7) NOT NULL,
  `title` varchar(50) NOT NULL,
  `title_native` varchar(50) NOT NULL,
  `sef` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `description` varchar(512) NOT NULL,
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `sitename` varchar(1024) NOT NULL DEFAULT '',
  `published` int(11) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang_id`),
  UNIQUE KEY `idx_sef` (`sef`),
  UNIQUE KEY `idx_image` (`image`),
  UNIQUE KEY `idx_langcode` (`lang_code`),
  KEY `idx_access` (`access`),
  KEY `idx_ordering` (`ordering`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_languages`
--

LOCK TABLES `uxlo0_languages` WRITE;
/*!40000 ALTER TABLE `uxlo0_languages` DISABLE KEYS */;
INSERT INTO `uxlo0_languages` VALUES (1,'en-GB','English (UK)','English (UK)','en','en','','','','',1,0,1);
/*!40000 ALTER TABLE `uxlo0_languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_menu`
--

DROP TABLE IF EXISTS `uxlo0_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menutype` varchar(24) NOT NULL COMMENT 'The type of menu this item belongs to. FK to #__menu_types.menutype',
  `title` varchar(255) NOT NULL COMMENT 'The display title of the menu item.',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'The SEF alias of the menu item.',
  `note` varchar(255) NOT NULL DEFAULT '',
  `path` varchar(1024) NOT NULL COMMENT 'The computed path of the menu item based on the alias field.',
  `link` varchar(1024) NOT NULL COMMENT 'The actually link the menu item refers to.',
  `type` varchar(16) NOT NULL COMMENT 'The type of link: Component, URL, Alias, Separator',
  `published` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'The published state of the menu link.',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '1' COMMENT 'The parent menu item in the menu tree.',
  `level` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The relative level in the tree.',
  `component_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to #__extensions.id',
  `ordering` int(11) NOT NULL DEFAULT '0' COMMENT 'The relative ordering of the menu item in the tree.',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to #__users.id',
  `checked_out_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'The time the menu item was checked out.',
  `browserNav` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'The click behaviour of the link.',
  `access` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The access level required to view the menu item.',
  `img` varchar(255) NOT NULL COMMENT 'The image of the menu item.',
  `template_style_id` int(10) unsigned NOT NULL DEFAULT '0',
  `params` text NOT NULL COMMENT 'JSON encoded data for the menu item.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `home` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Indicates if this menu item is the home or default page.',
  `language` char(7) NOT NULL DEFAULT '',
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_client_id_parent_id_alias_language` (`client_id`,`parent_id`,`alias`,`language`),
  KEY `idx_componentid` (`component_id`,`menutype`,`published`,`access`),
  KEY `idx_menutype` (`menutype`),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`),
  KEY `idx_path` (`path`(255)),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB AUTO_INCREMENT=138 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_menu`
--

LOCK TABLES `uxlo0_menu` WRITE;
/*!40000 ALTER TABLE `uxlo0_menu` DISABLE KEYS */;
INSERT INTO `uxlo0_menu` VALUES (1,'','Menu_Item_Root','root','','','','',1,0,0,0,0,0,'0000-00-00 00:00:00',0,0,'',0,'',0,117,0,'*',0),(2,'menu','com_banners','Banners','','Banners','index.php?option=com_banners','component',0,1,1,4,0,0,'0000-00-00 00:00:00',0,0,'class:banners',0,'',1,10,0,'*',1),(3,'menu','com_banners','Banners','','Banners/Banners','index.php?option=com_banners','component',0,2,2,4,0,0,'0000-00-00 00:00:00',0,0,'class:banners',0,'',2,3,0,'*',1),(4,'menu','com_banners_categories','Categories','','Banners/Categories','index.php?option=com_categories&extension=com_banners','component',0,2,2,6,0,0,'0000-00-00 00:00:00',0,0,'class:banners-cat',0,'',4,5,0,'*',1),(5,'menu','com_banners_clients','Clients','','Banners/Clients','index.php?option=com_banners&view=clients','component',0,2,2,4,0,0,'0000-00-00 00:00:00',0,0,'class:banners-clients',0,'',6,7,0,'*',1),(6,'menu','com_banners_tracks','Tracks','','Banners/Tracks','index.php?option=com_banners&view=tracks','component',0,2,2,4,0,0,'0000-00-00 00:00:00',0,0,'class:banners-tracks',0,'',8,9,0,'*',1),(7,'menu','com_contact','Contacts','','Contacts','index.php?option=com_contact','component',0,1,1,8,0,0,'0000-00-00 00:00:00',0,0,'class:contact',0,'',11,16,0,'*',1),(8,'menu','com_contact','Contacts','','Contacts/Contacts','index.php?option=com_contact','component',0,7,2,8,0,0,'0000-00-00 00:00:00',0,0,'class:contact',0,'',12,13,0,'*',1),(9,'menu','com_contact_categories','Categories','','Contacts/Categories','index.php?option=com_categories&extension=com_contact','component',0,7,2,6,0,0,'0000-00-00 00:00:00',0,0,'class:contact-cat',0,'',14,15,0,'*',1),(10,'menu','com_messages','Messaging','','Messaging','index.php?option=com_messages','component',0,1,1,15,0,0,'0000-00-00 00:00:00',0,0,'class:messages',0,'',17,22,0,'*',1),(11,'menu','com_messages_add','New Private Message','','Messaging/New Private Message','index.php?option=com_messages&task=message.add','component',0,10,2,15,0,0,'0000-00-00 00:00:00',0,0,'class:messages-add',0,'',18,19,0,'*',1),(12,'menu','com_messages_read','Read Private Message','','Messaging/Read Private Message','index.php?option=com_messages','component',0,10,2,15,0,0,'0000-00-00 00:00:00',0,0,'class:messages-read',0,'',20,21,0,'*',1),(13,'menu','com_newsfeeds','News Feeds','','News Feeds','index.php?option=com_newsfeeds','component',0,1,1,17,0,0,'0000-00-00 00:00:00',0,0,'class:newsfeeds',0,'',23,28,0,'*',1),(14,'menu','com_newsfeeds_feeds','Feeds','','News Feeds/Feeds','index.php?option=com_newsfeeds','component',0,13,2,17,0,0,'0000-00-00 00:00:00',0,0,'class:newsfeeds',0,'',24,25,0,'*',1),(15,'menu','com_newsfeeds_categories','Categories','','News Feeds/Categories','index.php?option=com_categories&extension=com_newsfeeds','component',0,13,2,6,0,0,'0000-00-00 00:00:00',0,0,'class:newsfeeds-cat',0,'',26,27,0,'*',1),(16,'menu','com_redirect','Redirect','','Redirect','index.php?option=com_redirect','component',0,1,1,24,0,0,'0000-00-00 00:00:00',0,0,'class:redirect',0,'',43,44,0,'*',1),(17,'menu','com_search','Basic Search','','Basic Search','index.php?option=com_search','component',0,1,1,19,0,0,'0000-00-00 00:00:00',0,0,'class:search',0,'',33,34,0,'*',1),(18,'menu','com_weblinks','Weblinks','','Weblinks','index.php?option=com_weblinks','component',0,1,1,21,0,0,'0000-00-00 00:00:00',0,0,'class:weblinks',0,'',35,40,0,'*',1),(19,'menu','com_weblinks_links','Links','','Weblinks/Links','index.php?option=com_weblinks','component',0,18,2,21,0,0,'0000-00-00 00:00:00',0,0,'class:weblinks',0,'',36,37,0,'*',1),(20,'menu','com_weblinks_categories','Categories','','Weblinks/Categories','index.php?option=com_categories&extension=com_weblinks','component',0,18,2,6,0,0,'0000-00-00 00:00:00',0,0,'class:weblinks-cat',0,'',38,39,0,'*',1),(21,'menu','com_finder','Smart Search','','Smart Search','index.php?option=com_finder','component',0,1,1,27,0,0,'0000-00-00 00:00:00',0,0,'class:finder',0,'',31,32,0,'*',1),(22,'menu','com_joomlaupdate','Joomla! Update','','Joomla! Update','index.php?option=com_joomlaupdate','component',0,1,1,28,0,0,'0000-00-00 00:00:00',0,0,'class:joomlaupdate',0,'',41,42,0,'*',1),(101,'mainmenu','网站首页','home','','home','index.php?option=com_content&view=article&id=59','component',1,1,1,22,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"front\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',29,30,1,'*',0),(102,'mainmenu','关于我们','about-us','','about-us','index.php?option=com_content&view=article&id=35','component',1,1,1,22,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',45,46,0,'*',0),(103,'mainmenu','存款取款','deposit','','deposit','index.php?option=com_content&view=article&id=37','component',1,1,1,22,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',47,48,0,'*',0),(104,'mainmenu','最新优惠','favorable','','favorable','index.php?option=com_content&view=article&id=60','component',1,1,1,22,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',49,54,0,'*',0),(105,'mainmenu','游戏规则','rule','','rule','index.php?option=com_content&view=article&id=36','component',1,1,1,22,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',55,56,0,'*',0),(106,'mainmenu','联系我们','contact','','contact','index.php?option=com_content&view=article&id=40','component',1,1,1,22,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',57,58,0,'*',0),(107,'mainmenu','留言板','feedback','','feedback','index.php?option=com_easybookreloaded&view=easybookreloaded','component',1,1,1,10008,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',59,60,0,'*',0),(108,'main','JCE','jce','','jce','index.php?option=com_jce','component',0,1,1,10004,0,0,'0000-00-00 00:00:00',0,1,'components/com_jce/media/img/menu/logo.png',0,'',61,70,0,'',1),(109,'main','WF_MENU_CPANEL','wf-menu-cpanel','','jce/wf-menu-cpanel','index.php?option=com_jce','component',0,108,2,10004,0,0,'0000-00-00 00:00:00',0,1,'components/com_jce/media/img/menu/jce-cpanel.png',0,'',62,63,0,'',1),(110,'main','WF_MENU_CONFIG','wf-menu-config','','jce/wf-menu-config','index.php?option=com_jce&view=config','component',0,108,2,10004,0,0,'0000-00-00 00:00:00',0,1,'components/com_jce/media/img/menu/jce-config.png',0,'',64,65,0,'',1),(111,'main','WF_MENU_PROFILES','wf-menu-profiles','','jce/wf-menu-profiles','index.php?option=com_jce&view=profiles','component',0,108,2,10004,0,0,'0000-00-00 00:00:00',0,1,'components/com_jce/media/img/menu/jce-profiles.png',0,'',66,67,0,'',1),(112,'main','WF_MENU_INSTALL','wf-menu-install','','jce/wf-menu-install','index.php?option=com_jce&view=installer','component',0,108,2,10004,0,0,'0000-00-00 00:00:00',0,1,'components/com_jce/media/img/menu/jce-install.png',0,'',68,69,0,'',1),(113,'main','.XCloner-Backup and Restore','xcloner-backup-and-restore','','xcloner-backup-and-restore','index.php?option=com_xcloner-backupandrestore','component',0,1,1,10005,0,0,'0000-00-00 00:00:00',0,1,'components/com_xcloner-backupandrestore/images/xcloner.png',0,'',71,72,0,'',1),(114,'sidebar-menu','试玩体验','2012-04-21-09-11-35','','2012-04-21-09-11-35','http://chat8.live800.com/live800/chatClient/chatbox.jsp?companyID=89088&jid=4491931779&enterurl=http%3A%2F%2Fchat8%2Elive800%2Ecom%3A8080%2Flive800%2Fpreview%2Ejsp&pagereferrer=http%3A%2F%2Fchat8%2Elive800%2Ecom%3A8080%2Flive800%2FembedScript%2Ejsp%3Ft%3D1325844263148&tm=1325845562953','url',1,1,1,0,0,0,'0000-00-00 00:00:00',1,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1}',73,74,0,'*',0),(115,'sidebar-menu','我要开户','register','','register','index.php?option=com_users&view=active','component',1,1,1,25,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',75,76,0,'*',0),(116,'sidebar-menu','游戏登录','2012-04-21-09-13-18','','2012-04-21-09-13-18','http://www.yuguzhi.com/sun/game.htm','url',1,1,1,0,0,0,'0000-00-00 00:00:00',1,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1}',77,78,0,'*',0),(117,'sidebar-menu','客户端下载','2012-04-21-09-14-04','','2012-04-21-09-14-04','http://www.83suncity.com/air-bin/SuncityGameSetup1.4.1062.exe','url',1,1,1,0,0,0,'0000-00-00 00:00:00',1,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1}',79,80,0,'*',0),(118,'sidebar-menu','会员存款','user-deposit','','user-deposit','index.php?option=com_content&view=article&id=52','component',1,1,1,22,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',81,82,0,'*',0),(119,'sidebar-menu','会员提款','user-withdraw','','user-withdraw','index.php?option=com_aicontactsafe&view=message&layout=message&pf=3&redirect_on_success=','component',1,1,1,10009,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',83,84,0,'*',0),(120,'main','COM_EASYBOOKRELOADED','com-easybookreloaded','','com-easybookreloaded','index.php?option=com_easybookreloaded','component',0,1,1,10008,0,0,'0000-00-00 00:00:00',0,1,'components/com_easybookreloaded/images/easybook_ico.png',0,'',85,94,0,'',1),(121,'main','COM_EASYBOOKRELOADED_MANAGE_ENTRIES','com-easybookreloaded-manage-entries','','com-easybookreloaded/com-easybookreloaded-manage-entries','index.php?option=com_easybookreloaded','component',0,120,2,10008,0,0,'0000-00-00 00:00:00',0,1,'components/com_easybookreloaded/images/easybook_edit.png',0,'',86,87,0,'',1),(122,'main','COM_EASYBOOKRELOADED_CONFIG','com-easybookreloaded-config','','com-easybookreloaded/com-easybookreloaded-config','index.php?option=com_easybookreloaded&task=config','component',0,120,2,10008,0,0,'0000-00-00 00:00:00',0,1,'components/com_easybookreloaded/images/easybook_config.png',0,'',88,89,0,'',1),(123,'main','COM_EASYBOOKRELOADED_BADWORDFILTER','com-easybookreloaded-badwordfilter','','com-easybookreloaded/com-easybookreloaded-badwordfilter','index.php?option=com_easybookreloaded&controller=badwords','component',0,120,2,10008,0,0,'0000-00-00 00:00:00',0,1,'components/com_easybookreloaded/images/easybook_unhappy.png',0,'',90,91,0,'',1),(124,'main','COM_EASYBOOKRELOADED_ABOUT','com-easybookreloaded-about','','com-easybookreloaded/com-easybookreloaded-about','index.php?option=com_easybookreloaded&task=about','component',0,120,2,10008,0,0,'0000-00-00 00:00:00',0,1,'components/com_easybookreloaded/images/easybook_info.png',0,'',92,93,0,'',1),(125,'main','COM_AICONTACTSAFE','com-aicontactsafe','','com-aicontactsafe','index.php?option=com_aicontactsafe','component',0,1,1,10009,0,0,'0000-00-00 00:00:00',0,1,'components/com_aicontactsafe/images/aicontactsafe_icon.gif',0,'',95,110,0,'',1),(126,'main','COM_AICONTACTSAFE_MESSAGES','com-aicontactsafe-messages','','com-aicontactsafe/com-aicontactsafe-messages','index.php?option=com_aicontactsafe&sTask=messages','component',0,125,2,10009,0,0,'0000-00-00 00:00:00',0,1,'components/com_aicontactsafe/images/aicontactsafe_icon.gif',0,'',96,97,0,'',1),(127,'main','COM_AICONTACTSAFE_ATTACHMENTS','com-aicontactsafe-attachments','','com-aicontactsafe/com-aicontactsafe-attachments','index.php?option=com_aicontactsafe&sTask=attachments','component',0,125,2,10009,0,0,'0000-00-00 00:00:00',0,1,'components/com_aicontactsafe/images/aicontactsafe_icon.gif',0,'',98,99,0,'',1),(128,'main','COM_AICONTACTSAFE_PROFILES','com-aicontactsafe-profiles','','com-aicontactsafe/com-aicontactsafe-profiles','index.php?option=com_aicontactsafe&sTask=profiles','component',0,125,2,10009,0,0,'0000-00-00 00:00:00',0,1,'components/com_aicontactsafe/images/aicontactsafe_icon.gif',0,'',100,101,0,'',1),(129,'main','COM_AICONTACTSAFE_FIELDS','com-aicontactsafe-fields','','com-aicontactsafe/com-aicontactsafe-fields','index.php?option=com_aicontactsafe&sTask=fields','component',0,125,2,10009,0,0,'0000-00-00 00:00:00',0,1,'components/com_aicontactsafe/images/aicontactsafe_icon.gif',0,'',102,103,0,'',1),(130,'main','COM_AICONTACTSAFE_STATUSES','com-aicontactsafe-statuses','','com-aicontactsafe/com-aicontactsafe-statuses','index.php?option=com_aicontactsafe&sTask=statuses','component',0,125,2,10009,0,0,'0000-00-00 00:00:00',0,1,'components/com_aicontactsafe/images/aicontactsafe_icon.gif',0,'',104,105,0,'',1),(131,'main','COM_AICONTACTSAFE_CONTROL_PANEL','com-aicontactsafe-control-panel','','com-aicontactsafe/com-aicontactsafe-control-panel','index.php?option=com_aicontactsafe&sTask=control_panel','component',0,125,2,10009,0,0,'0000-00-00 00:00:00',0,1,'components/com_aicontactsafe/images/aicontactsafe_icon.gif',0,'',106,107,0,'',1),(132,'main','COM_AICONTACTSAFE_ABOUT','com-aicontactsafe-about','','com-aicontactsafe/com-aicontactsafe-about','index.php?option=com_aicontactsafe&sTask=about','component',0,125,2,10009,0,0,'0000-00-00 00:00:00',0,1,'components/com_aicontactsafe/images/aicontactsafe_icon.gif',0,'',108,109,0,'',1),(133,'main','COM_DJIMAGESLIDER','com-djimageslider','','com-djimageslider','index.php?option=com_djimageslider','component',0,1,1,10010,0,0,'0000-00-00 00:00:00',0,1,'components/com_djimageslider/assets/icon-16-dj.png',0,'',111,116,0,'',1),(134,'main','SLIDES','slides','','com-djimageslider/slides','index.php?option=com_djimageslider&view=items','component',0,133,2,10010,0,0,'0000-00-00 00:00:00',0,1,'class:component',0,'',112,113,0,'',1),(135,'main','CATEGORIES','categories','','com-djimageslider/categories','index.php?option=com_categories&extension=com_djimageslider','component',0,133,2,10010,0,0,'0000-00-00 00:00:00',0,1,'class:category',0,'',114,115,0,'',1),(136,'mainmenu','高额洗码','wash-code','','favorable/wash-code','index.php?option=com_content&view=article&id=61','component',1,104,2,22,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',50,51,0,'*',0),(137,'mainmenu','保险礼金','insurance-gifts','','favorable/insurance-gifts','index.php?option=com_content&view=article&id=62','component',1,104,2,22,0,0,'0000-00-00 00:00:00',0,1,'',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',52,53,0,'*',0);
/*!40000 ALTER TABLE `uxlo0_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_menu_types`
--

DROP TABLE IF EXISTS `uxlo0_menu_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_menu_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menutype` varchar(24) NOT NULL,
  `title` varchar(48) NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_menutype` (`menutype`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_menu_types`
--

LOCK TABLES `uxlo0_menu_types` WRITE;
/*!40000 ALTER TABLE `uxlo0_menu_types` DISABLE KEYS */;
INSERT INTO `uxlo0_menu_types` VALUES (1,'mainmenu','Main Menu','The main menu for the site'),(2,'sidebar-menu','Sidebar Menu','');
/*!40000 ALTER TABLE `uxlo0_menu_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_messages`
--

DROP TABLE IF EXISTS `uxlo0_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_messages` (
  `message_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id_from` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id_to` int(10) unsigned NOT NULL DEFAULT '0',
  `folder_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `priority` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  PRIMARY KEY (`message_id`),
  KEY `useridto_state` (`user_id_to`,`state`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_messages`
--

LOCK TABLES `uxlo0_messages` WRITE;
/*!40000 ALTER TABLE `uxlo0_messages` DISABLE KEYS */;
INSERT INTO `uxlo0_messages` VALUES (1,42,42,0,'2012-04-30 13:27:52',0,0,'发送邮件失败','发送用户注册邮件失败。错误为：无法示例邮件功能 用户尝试注册的用户名是：catcat');
/*!40000 ALTER TABLE `uxlo0_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_messages_cfg`
--

DROP TABLE IF EXISTS `uxlo0_messages_cfg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_messages_cfg` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `cfg_name` varchar(100) NOT NULL DEFAULT '',
  `cfg_value` varchar(255) NOT NULL DEFAULT '',
  UNIQUE KEY `idx_user_var_name` (`user_id`,`cfg_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_messages_cfg`
--

LOCK TABLES `uxlo0_messages_cfg` WRITE;
/*!40000 ALTER TABLE `uxlo0_messages_cfg` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_messages_cfg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_modules`
--

DROP TABLE IF EXISTS `uxlo0_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `position` varchar(50) NOT NULL DEFAULT '',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `module` varchar(50) DEFAULT NULL,
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `showtitle` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `published` (`published`,`access`),
  KEY `newsfeeds` (`module`,`published`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_modules`
--

LOCK TABLES `uxlo0_modules` WRITE;
/*!40000 ALTER TABLE `uxlo0_modules` DISABLE KEYS */;
INSERT INTO `uxlo0_modules` VALUES (1,'Main Menu','','',1,'header',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_menu',1,0,'{\"menutype\":\"mainmenu\",\"startLevel\":\"1\",\"endLevel\":\"1\",\"showAllChildren\":\"0\",\"tag_id\":\"\",\"class_sfx\":\"\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"_menu\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\"}',0,'*'),(2,'Login','','',1,'login',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_login',1,1,'',1,'*'),(3,'Popular Articles','','',3,'cpanel',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_popular',3,1,'{\"count\":\"5\",\"catid\":\"\",\"user_id\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"automatic_title\":\"1\"}',1,'*'),(4,'Recently Added Articles','','',4,'cpanel',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_latest',3,1,'{\"count\":\"5\",\"ordering\":\"c_dsc\",\"catid\":\"\",\"user_id\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"automatic_title\":\"1\"}',1,'*'),(8,'Toolbar','','',1,'toolbar',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_toolbar',3,1,'',1,'*'),(9,'Quick Icons','','',1,'icon',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_quickicon',3,1,'',1,'*'),(10,'Logged-in Users','','',2,'cpanel',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_logged',3,1,'{\"count\":\"5\",\"name\":\"1\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"automatic_title\":\"1\"}',1,'*'),(12,'Admin Menu','','',1,'menu',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_menu',3,1,'{\"layout\":\"\",\"moduleclass_sfx\":\"\",\"shownew\":\"1\",\"showhelp\":\"1\",\"cache\":\"0\"}',1,'*'),(13,'Admin Submenu','','',1,'submenu',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_submenu',3,1,'',1,'*'),(14,'User Status','','',2,'status',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_status',3,1,'',1,'*'),(15,'Title','','',1,'title',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_title',3,1,'',1,'*'),(16,'Login Form','','',7,'position-7',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',-2,'mod_login',1,1,'{\"greeting\":\"1\",\"name\":\"0\"}',0,'*'),(17,'Breadcrumbs','','',1,'content-top',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_breadcrumbs',1,1,'{\"showHere\":\"1\",\"showHome\":\"1\",\"homeText\":\"\\u7f51\\u7ad9\\u9996\\u9875\",\"showLast\":\"1\",\"separator\":\">\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\"}',0,'*'),(79,'Multilanguage status','','',1,'status',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_multilangstatus',3,1,'{\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\"}',1,'*'),(86,'Joomla Version','','',1,'footer',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_version',3,1,'{\"format\":\"short\",\"product\":\"1\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\"}',1,'*'),(87,'Logo','','<a href=\"index.php\"><img src=\"images/logo.jpg\" alt=\"\" /></a>',1,'header',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"_logo\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(88,'slogan','','太阳城公告：亲爱的朋友，现在开户即可申请首存30%开户优惠，每天更有高额保险礼金为您送出，祝您好运',1,'header',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"_slogan\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(89,'Sidebar Menu','','',1,'sidebar',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_menu',1,0,'{\"menutype\":\"sidebar-menu\",\"startLevel\":\"1\",\"endLevel\":\"0\",\"showAllChildren\":\"0\",\"tag_id\":\"\",\"class_sfx\":\"_sidebar\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\"}',0,'*'),(90,'Content Top Background','','',2,'content-top',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"_content-top\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(91,'Content Bottom Background','','',0,'content-bottom',42,'2012-05-01 09:55:08','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"_content-bottom\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(92,'Footer Menu','','',1,'footer',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_menu',1,0,'{\"menutype\":\"mainmenu\",\"startLevel\":\"1\",\"endLevel\":\"1\",\"showAllChildren\":\"0\",\"tag_id\":\"\",\"class_sfx\":\"_footer\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\"}',0,'*'),(93,'Copyright','','Copyright © 2010菲律宾太阳城娱乐城-菲律宾太阳城代理开户818sun.com All rights reserved',1,'footer',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"_copyright\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(94,'Home Top Slideshow','','',3,'content-top',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_djimageslider',1,0,'{\"slider_source\":\"1\",\"itemid\":\"0\",\"slider_type\":\"2\",\"link_image\":\"0\",\"image_folder\":\"images\\/sampledata\\/fruitshop\",\"link\":\"\",\"category\":\"9\",\"show_title\":\"0\",\"show_desc\":\"0\",\"show_readmore\":\"0\",\"link_title\":\"0\",\"link_desc\":\"0\",\"limit_desc\":\"\",\"image_width\":\"733\",\"image_height\":\"405\",\"fit_to\":\"0\",\"visible_images\":\"3\",\"space_between_images\":\"10\",\"max_images\":\"20\",\"sort_by\":\"1\",\"effect\":\"Cubic\",\"autoplay\":\"0\",\"show_buttons\":\"0\",\"show_arrows\":\"0\",\"show_custom_nav\":\"0\",\"desc_width\":\"\",\"desc_bottom\":\"0\",\"desc_horizontal\":\"0\",\"left_arrow\":\"\",\"right_arrow\":\"\",\"play_button\":\"\",\"pause_button\":\"\",\"arrows_top\":\"30\",\"arrows_horizontal\":\"5\",\"effect_type\":\"0\",\"duration\":\"\",\"delay\":\"\",\"preload\":\"800\",\"moduleclass_sfx\":\"\",\"cache\":\"0\"}',0,'*'),(97,'Home Bottom Slideshow','','',1,'footer-top',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_djimageslider',1,0,'{\"slider_source\":\"1\",\"itemid\":\"105\",\"slider_type\":\"0\",\"link_image\":\"1\",\"image_folder\":\"images\\/sampledata\\/fruitshop\",\"link\":\"\",\"category\":\"11\",\"show_title\":\"0\",\"show_desc\":\"0\",\"show_readmore\":\"0\",\"link_title\":\"0\",\"link_desc\":\"0\",\"limit_desc\":\"\",\"image_width\":\"208\",\"image_height\":\"163\",\"fit_to\":\"2\",\"visible_images\":\"4\",\"space_between_images\":\"16\",\"max_images\":\"20\",\"sort_by\":\"1\",\"effect\":\"Cubic\",\"autoplay\":\"0\",\"show_buttons\":\"0\",\"show_arrows\":\"2\",\"show_custom_nav\":\"0\",\"desc_width\":\"\",\"desc_bottom\":\"0\",\"desc_horizontal\":\"0\",\"left_arrow\":\"Prev\",\"right_arrow\":\"Next\",\"play_button\":\"\",\"pause_button\":\"\",\"arrows_top\":\"30\",\"arrows_horizontal\":\"5\",\"effect_type\":\"0\",\"duration\":\"\",\"delay\":\"\",\"preload\":\"800\",\"moduleclass_sfx\":\"\",\"cache\":\"0\"}',0,'*'),(98,'浮动联系方式','','<div id=\"float-contactus\">\r\n<div class=\"block\">\r\n<a target=\"_blank\" href=\"contact.html\">\r\n<img src=\"templates/sun/images/feedback.png\" />\r\n</a>\r\n</div>\r\n<div class=\"block\">\r\n<a target=\"_blank\" href=\"http://chat8.live800.com/live800/chatClient/chatbox.jsp?companyID=89088&configID=115266&jid=4491931779&enterurl=http%3A%2F%2Fchat8%2Elive800%2Ecom%3A8080%2Flive800%2Fpreview%2Ejsp&timestamp=1300780173062\' target=\'chat61815096\">\r\n<img src=\"templates/sun/images/contactus.png\" />\r\n</a>\r\n</div>\r\n</div>',1,'footer',42,'2012-05-02 14:23:40','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*'),(99,'feedback top','','	<div id=\"easybook_header\">\r\n		<a href=\"#entry_container_title\">Submit</a>\r\n	</div>',4,'content-top',42,'2012-05-06 09:10:12','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"1\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}',0,'*');
/*!40000 ALTER TABLE `uxlo0_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_modules_menu`
--

DROP TABLE IF EXISTS `uxlo0_modules_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_modules_menu` (
  `moduleid` int(11) NOT NULL DEFAULT '0',
  `menuid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`moduleid`,`menuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_modules_menu`
--

LOCK TABLES `uxlo0_modules_menu` WRITE;
/*!40000 ALTER TABLE `uxlo0_modules_menu` DISABLE KEYS */;
INSERT INTO `uxlo0_modules_menu` VALUES (1,0),(2,0),(3,0),(4,0),(6,0),(7,0),(8,0),(9,0),(10,0),(12,0),(13,0),(14,0),(15,0),(16,0),(17,-101),(79,0),(86,0),(87,0),(88,0),(89,0),(90,-101),(91,-101),(92,0),(93,0),(94,101),(97,101),(98,101),(99,107);
/*!40000 ALTER TABLE `uxlo0_modules_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_newsfeeds`
--

DROP TABLE IF EXISTS `uxlo0_newsfeeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_newsfeeds` (
  `catid` int(11) NOT NULL DEFAULT '0',
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `link` varchar(200) NOT NULL DEFAULT '',
  `filename` varchar(200) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `numarticles` int(10) unsigned NOT NULL DEFAULT '1',
  `cache_time` int(10) unsigned NOT NULL DEFAULT '3600',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rtl` tinyint(4) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`published`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_newsfeeds`
--

LOCK TABLES `uxlo0_newsfeeds` WRITE;
/*!40000 ALTER TABLE `uxlo0_newsfeeds` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_newsfeeds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_overrider`
--

DROP TABLE IF EXISTS `uxlo0_overrider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_overrider` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `constant` varchar(255) NOT NULL,
  `string` text NOT NULL,
  `file` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_overrider`
--

LOCK TABLES `uxlo0_overrider` WRITE;
/*!40000 ALTER TABLE `uxlo0_overrider` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_overrider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_redirect_links`
--

DROP TABLE IF EXISTS `uxlo0_redirect_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_redirect_links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `old_url` varchar(255) NOT NULL,
  `new_url` varchar(255) NOT NULL,
  `referer` varchar(150) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `published` tinyint(4) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_link_old` (`old_url`),
  KEY `idx_link_modifed` (`modified_date`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_redirect_links`
--

LOCK TABLES `uxlo0_redirect_links` WRITE;
/*!40000 ALTER TABLE `uxlo0_redirect_links` DISABLE KEYS */;
INSERT INTO `uxlo0_redirect_links` VALUES (1,'http://localhost:10080/sun/index.php?option=com_content&view=article&id=58&Itemid=107','','http://localhost:10080/sun/index.php?option=com_content&view=article&id=35&Itemid=102','',0,'2012-04-24 16:36:30','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `uxlo0_redirect_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_schemas`
--

DROP TABLE IF EXISTS `uxlo0_schemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_schemas` (
  `extension_id` int(11) NOT NULL,
  `version_id` varchar(20) NOT NULL,
  PRIMARY KEY (`extension_id`,`version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_schemas`
--

LOCK TABLES `uxlo0_schemas` WRITE;
/*!40000 ALTER TABLE `uxlo0_schemas` DISABLE KEYS */;
INSERT INTO `uxlo0_schemas` VALUES (700,'2.5.4-2012-03-19'),(10008,'4.0');
/*!40000 ALTER TABLE `uxlo0_schemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_session`
--

DROP TABLE IF EXISTS `uxlo0_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_session` (
  `session_id` varchar(200) NOT NULL DEFAULT '',
  `client_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `guest` tinyint(4) unsigned DEFAULT '1',
  `time` varchar(14) DEFAULT '',
  `data` mediumtext,
  `userid` int(11) DEFAULT '0',
  `username` varchar(150) DEFAULT '',
  `usertype` varchar(50) DEFAULT '',
  PRIMARY KEY (`session_id`),
  KEY `whosonline` (`guest`,`usertype`),
  KEY `userid` (`userid`),
  KEY `time` (`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_session`
--

LOCK TABLES `uxlo0_session` WRITE;
/*!40000 ALTER TABLE `uxlo0_session` DISABLE KEYS */;
INSERT INTO `uxlo0_session` VALUES ('ed0916jm86os2v187ctrc4i7i1',0,1,'1336295480','__default|a:21:{s:15:\"session.counter\";i:149;s:19:\"session.timer.start\";i:1336285936;s:18:\"session.timer.last\";i:1336295479;s:17:\"session.timer.now\";i:1336295480;s:22:\"session.client.browser\";s:65:\"Mozilla/5.0 (Windows NT 6.1; rv:12.0) Gecko/20100101 Firefox/12.0\";s:8:\"registry\";O:9:\"JRegistry\":1:{s:7:\"\0*\0data\";O:8:\"stdClass\":2:{s:20:\"eb_validation_errors\";a:4:{s:4:\"name\";b:1;s:4:\"text\";b:1;s:13:\"easycalccheck\";b:1;s:4:\"mail\";b:1;}s:18:\"eb_validation_data\";a:13:{s:6:\"option\";s:20:\"com_easybookreloaded\";s:4:\"task\";s:4:\"save\";s:10:\"controller\";s:5:\"entry\";s:6:\"gbname\";s:0:\"\";s:6:\"gbmail\";s:0:\"\";s:6:\"gbvote\";s:1:\"0\";s:6:\"gbtext\";s:0:\"\";s:13:\"easycalccheck\";s:0:\"\";s:4:\"send\";s:12:\"提交内容\";s:6:\"gbdate\";s:19:\"2012-05-06 08:58:20\";s:9:\"published\";s:1:\"1\";s:4:\"gbip\";s:9:\"127.0.0.1\";s:9:\"gbcomment\";N;}}}s:4:\"user\";O:5:\"JUser\":23:{s:9:\"\0*\0isRoot\";b:0;s:2:\"id\";i:0;s:4:\"name\";N;s:8:\"username\";N;s:5:\"email\";N;s:8:\"password\";N;s:14:\"password_clear\";s:0:\"\";s:8:\"usertype\";N;s:5:\"block\";N;s:9:\"sendEmail\";i:0;s:12:\"registerDate\";N;s:13:\"lastvisitDate\";N;s:10:\"activation\";N;s:6:\"params\";N;s:6:\"groups\";a:0:{}s:5:\"guest\";i:1;s:10:\"\0*\0_params\";O:9:\"JRegistry\":1:{s:7:\"\0*\0data\";O:8:\"stdClass\":0:{}}s:14:\"\0*\0_authGroups\";a:1:{i:0;i:1;}s:14:\"\0*\0_authLevels\";a:2:{i:0;i:1;i:1;i:1;}s:15:\"\0*\0_authActions\";N;s:12:\"\0*\0_errorMsg\";N;s:10:\"\0*\0_errors\";a:0:{}s:3:\"aid\";i:0;}s:19:\"messagefilter_order\";s:0:\"\";s:23:\"messagefilter_order_Dir\";s:0:\"\";s:17:\"global.list.limit\";i:20;s:17:\"messagelimitstart\";i:0;s:20:\"messagefilter_string\";s:0:\"\";s:18:\"postData:message_0\";s:0:\"\";s:12:\"isOK:message\";b:1;s:16:\"errorMsg:message\";s:0:\"\";s:15:\"idSaved:message\";i:0;s:38:\"confirmationMessage:message_1890304861\";s:39:\"Email sent. Thank you for your message.\";s:19:\"return_task:message\";a:1:{s:5:\"sTask\";s:7:\"message\";}s:13:\"session.token\";s:32:\"fc285e296cda3c64621cd3c23843901e\";s:14:\"last_task_temp\";a:2:{s:5:\"sTask\";s:7:\"message\";s:4:\"task\";s:7:\"display\";}s:38:\"confirmationMessage:message_1110360403\";s:39:\"Email sent. Thank you for your message.\";}__easybookreloaded|a:5:{s:8:\"operator\";s:1:\"+\";s:10:\"spamcheck1\";i:5;s:10:\"spamcheck2\";i:2;s:15:\"spamcheckresult\";i:7;s:4:\"time\";i:1336295472;}',0,'',''),('gttnlf7kev74e1k2i6eg7klub4',1,0,'1336295413','__default|a:8:{s:15:\"session.counter\";i:69;s:19:\"session.timer.start\";i:1336286090;s:18:\"session.timer.last\";i:1336295412;s:17:\"session.timer.now\";i:1336295412;s:22:\"session.client.browser\";s:65:\"Mozilla/5.0 (Windows NT 6.1; rv:12.0) Gecko/20100101 Firefox/12.0\";s:8:\"registry\";O:9:\"JRegistry\":1:{s:7:\"\0*\0data\";O:8:\"stdClass\":5:{s:11:\"application\";O:8:\"stdClass\":1:{s:4:\"lang\";s:0:\"\";}s:13:\"com_installer\";O:8:\"stdClass\":2:{s:7:\"message\";s:0:\"\";s:17:\"extension_message\";s:0:\"\";}s:11:\"com_content\";O:8:\"stdClass\":1:{s:4:\"edit\";O:8:\"stdClass\":1:{s:7:\"article\";O:8:\"stdClass\":2:{s:2:\"id\";a:0:{}s:4:\"data\";N;}}}s:11:\"com_modules\";O:8:\"stdClass\":3:{s:7:\"modules\";O:8:\"stdClass\":4:{s:6:\"filter\";O:8:\"stdClass\":8:{s:18:\"client_id_previous\";i:0;s:6:\"search\";s:0:\"\";s:6:\"access\";i:0;s:5:\"state\";s:0:\"\";s:8:\"position\";s:11:\"content-top\";s:6:\"module\";s:0:\"\";s:9:\"client_id\";i:0;s:8:\"language\";s:0:\"\";}s:10:\"limitstart\";i:0;s:8:\"ordercol\";s:8:\"ordering\";s:9:\"orderdirn\";s:3:\"asc\";}s:4:\"edit\";O:8:\"stdClass\":1:{s:6:\"module\";O:8:\"stdClass\":2:{s:4:\"data\";N;s:2:\"id\";a:1:{i:0;i:99;}}}s:3:\"add\";O:8:\"stdClass\":1:{s:6:\"module\";O:8:\"stdClass\":2:{s:12:\"extension_id\";N;s:6:\"params\";N;}}}s:6:\"global\";O:8:\"stdClass\":1:{s:4:\"list\";O:8:\"stdClass\":1:{s:5:\"limit\";s:2:\"20\";}}}}s:4:\"user\";O:5:\"JUser\":28:{s:9:\"\0*\0isRoot\";b:1;s:2:\"id\";s:2:\"42\";s:4:\"name\";s:10:\"Super User\";s:8:\"username\";s:5:\"admin\";s:5:\"email\";s:18:\"william0760@qq.com\";s:8:\"password\";s:65:\"4c7f4eb7323a2ffc67d3714d4b051ef7:o0jfHGJ4vqRWoJz6aINY2FguHWX4bwuq\";s:14:\"password_clear\";s:0:\"\";s:8:\"usertype\";s:10:\"deprecated\";s:5:\"block\";s:1:\"0\";s:9:\"sendEmail\";s:1:\"1\";s:12:\"registerDate\";s:19:\"2012-04-19 12:58:10\";s:13:\"lastvisitDate\";s:19:\"2012-05-05 06:48:44\";s:10:\"activation\";s:1:\"0\";s:6:\"params\";s:92:\"{\"admin_style\":\"\",\"admin_language\":\"\",\"language\":\"\",\"editor\":\"\",\"helpsite\":\"\",\"timezone\":\"\"}\";s:6:\"groups\";a:1:{i:8;s:1:\"8\";}s:5:\"guest\";i:0;s:10:\"\0*\0_params\";O:9:\"JRegistry\":1:{s:7:\"\0*\0data\";O:8:\"stdClass\":6:{s:11:\"admin_style\";s:0:\"\";s:14:\"admin_language\";s:0:\"\";s:8:\"language\";s:0:\"\";s:6:\"editor\";s:0:\"\";s:8:\"helpsite\";s:0:\"\";s:8:\"timezone\";s:0:\"\";}}s:14:\"\0*\0_authGroups\";a:2:{i:0;i:1;i:1;i:8;}s:14:\"\0*\0_authLevels\";a:4:{i:0;i:1;i:1;i:1;i:2;i:2;i:3;i:3;}s:15:\"\0*\0_authActions\";N;s:12:\"\0*\0_errorMsg\";N;s:10:\"\0*\0_errors\";a:0:{}s:3:\"aid\";i:0;s:4:\"used\";s:1:\"0\";s:5:\"phone\";s:6:\"111111\";s:8:\"currency\";s:3:\"RMB\";s:11:\"getpassword\";s:4:\"2124\";s:2:\"qq\";s:5:\"11223\";}s:13:\"session.token\";s:32:\"162c16339f18ad9090b057235f533dc1\";}__wf|a:1:{s:13:\"session.token\";s:32:\"f0679c13b3c0a115196c2dd6e973e588\";}',42,'admin','');
/*!40000 ALTER TABLE `uxlo0_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_template_styles`
--

DROP TABLE IF EXISTS `uxlo0_template_styles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_template_styles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template` varchar(50) NOT NULL DEFAULT '',
  `client_id` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `home` char(7) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_template` (`template`),
  KEY `idx_home` (`home`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_template_styles`
--

LOCK TABLES `uxlo0_template_styles` WRITE;
/*!40000 ALTER TABLE `uxlo0_template_styles` DISABLE KEYS */;
INSERT INTO `uxlo0_template_styles` VALUES (2,'bluestork',1,'1','Bluestork - Default','{\"useRoundedCorners\":\"1\",\"showSiteName\":\"0\"}'),(3,'atomic',0,'0','Atomic - Default','{}'),(5,'hathor',1,'0','Hathor - Default','{\"showSiteName\":\"0\",\"colourChoice\":\"\",\"boldText\":\"0\"}'),(7,'sun',0,'1','周日 - 默认','[]');
/*!40000 ALTER TABLE `uxlo0_template_styles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_update_categories`
--

DROP TABLE IF EXISTS `uxlo0_update_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_update_categories` (
  `categoryid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT '',
  `description` text NOT NULL,
  `parent` int(11) DEFAULT '0',
  `updatesite` int(11) DEFAULT '0',
  PRIMARY KEY (`categoryid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Update Categories';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_update_categories`
--

LOCK TABLES `uxlo0_update_categories` WRITE;
/*!40000 ALTER TABLE `uxlo0_update_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_update_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_update_sites`
--

DROP TABLE IF EXISTS `uxlo0_update_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_update_sites` (
  `update_site_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '',
  `type` varchar(20) DEFAULT '',
  `location` text NOT NULL,
  `enabled` int(11) DEFAULT '0',
  `last_check_timestamp` bigint(20) DEFAULT '0',
  PRIMARY KEY (`update_site_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='Update Sites';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_update_sites`
--

LOCK TABLES `uxlo0_update_sites` WRITE;
/*!40000 ALTER TABLE `uxlo0_update_sites` DISABLE KEYS */;
INSERT INTO `uxlo0_update_sites` VALUES (1,'Joomla Core','collection','http://update.joomla.org/core/list.xml',1,1336286099),(2,'Joomla Extension Directory','collection','http://update.joomla.org/jed/list.xml',1,1336286101),(3,'JCE Editor Updates','extension','https://www.joomlacontenteditor.net/index.php?option=com_updates&view=update&format=xml&id=1',0,1334930979);
/*!40000 ALTER TABLE `uxlo0_update_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_update_sites_extensions`
--

DROP TABLE IF EXISTS `uxlo0_update_sites_extensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_update_sites_extensions` (
  `update_site_id` int(11) NOT NULL DEFAULT '0',
  `extension_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`update_site_id`,`extension_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Links extensions to update sites';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_update_sites_extensions`
--

LOCK TABLES `uxlo0_update_sites_extensions` WRITE;
/*!40000 ALTER TABLE `uxlo0_update_sites_extensions` DISABLE KEYS */;
INSERT INTO `uxlo0_update_sites_extensions` VALUES (1,700),(2,700),(3,10004);
/*!40000 ALTER TABLE `uxlo0_update_sites_extensions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_updates`
--

DROP TABLE IF EXISTS `uxlo0_updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_updates` (
  `update_id` int(11) NOT NULL AUTO_INCREMENT,
  `update_site_id` int(11) DEFAULT '0',
  `extension_id` int(11) DEFAULT '0',
  `categoryid` int(11) DEFAULT '0',
  `name` varchar(100) DEFAULT '',
  `description` text NOT NULL,
  `element` varchar(100) DEFAULT '',
  `type` varchar(20) DEFAULT '',
  `folder` varchar(20) DEFAULT '',
  `client_id` tinyint(3) DEFAULT '0',
  `version` varchar(10) DEFAULT '',
  `data` text NOT NULL,
  `detailsurl` text NOT NULL,
  `infourl` text NOT NULL,
  PRIMARY KEY (`update_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Available Updates';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_updates`
--

LOCK TABLES `uxlo0_updates` WRITE;
/*!40000 ALTER TABLE `uxlo0_updates` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_updates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_user_notes`
--

DROP TABLE IF EXISTS `uxlo0_user_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_user_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(100) NOT NULL DEFAULT '',
  `body` text NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(10) unsigned NOT NULL,
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `review_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_category_id` (`catid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_user_notes`
--

LOCK TABLES `uxlo0_user_notes` WRITE;
/*!40000 ALTER TABLE `uxlo0_user_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_user_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_user_profiles`
--

DROP TABLE IF EXISTS `uxlo0_user_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_user_profiles` (
  `user_id` int(11) NOT NULL,
  `profile_key` varchar(100) NOT NULL,
  `profile_value` varchar(255) NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `idx_user_id_profile_key` (`user_id`,`profile_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Simple user profile storage table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_user_profiles`
--

LOCK TABLES `uxlo0_user_profiles` WRITE;
/*!40000 ALTER TABLE `uxlo0_user_profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_user_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_user_usergroup_map`
--

DROP TABLE IF EXISTS `uxlo0_user_usergroup_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_user_usergroup_map` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__users.id',
  `group_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__usergroups.id',
  PRIMARY KEY (`user_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_user_usergroup_map`
--

LOCK TABLES `uxlo0_user_usergroup_map` WRITE;
/*!40000 ALTER TABLE `uxlo0_user_usergroup_map` DISABLE KEYS */;
INSERT INTO `uxlo0_user_usergroup_map` VALUES (42,8),(43,2),(44,2),(45,2);
/*!40000 ALTER TABLE `uxlo0_user_usergroup_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_usergroups`
--

DROP TABLE IF EXISTS `uxlo0_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_usergroups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Adjacency List Reference Id',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `title` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_usergroup_parent_title_lookup` (`parent_id`,`title`),
  KEY `idx_usergroup_title_lookup` (`title`),
  KEY `idx_usergroup_adjacency_lookup` (`parent_id`),
  KEY `idx_usergroup_nested_set_lookup` (`lft`,`rgt`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_usergroups`
--

LOCK TABLES `uxlo0_usergroups` WRITE;
/*!40000 ALTER TABLE `uxlo0_usergroups` DISABLE KEYS */;
INSERT INTO `uxlo0_usergroups` VALUES (1,0,1,20,'Public'),(2,1,6,17,'Registered'),(3,2,7,14,'Author'),(4,3,8,11,'Editor'),(5,4,9,10,'Publisher'),(6,1,2,5,'Manager'),(7,6,3,4,'Administrator'),(8,1,18,19,'Super Users');
/*!40000 ALTER TABLE `uxlo0_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_users`
--

DROP TABLE IF EXISTS `uxlo0_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `used` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(150) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `usertype` varchar(25) NOT NULL DEFAULT '',
  `block` tinyint(4) NOT NULL DEFAULT '0',
  `sendEmail` tinyint(4) DEFAULT '0',
  `registerDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastvisitDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activation` varchar(100) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  `phone` varchar(100) NOT NULL,
  `currency` varchar(10) NOT NULL,
  `getpassword` varchar(100) NOT NULL,
  `qq` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `usertype` (`usertype`),
  KEY `idx_name` (`name`),
  KEY `idx_block` (`block`),
  KEY `username` (`username`),
  KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_users`
--

LOCK TABLES `uxlo0_users` WRITE;
/*!40000 ALTER TABLE `uxlo0_users` DISABLE KEYS */;
INSERT INTO `uxlo0_users` VALUES (42,0,'Super User','admin','william0760@qq.com','4c7f4eb7323a2ffc67d3714d4b051ef7:o0jfHGJ4vqRWoJz6aINY2FguHWX4bwuq','deprecated',0,1,'2012-04-19 12:58:10','2012-05-06 06:34:58','0','{\"admin_style\":\"\",\"admin_language\":\"\",\"language\":\"\",\"editor\":\"\",\"helpsite\":\"\",\"timezone\":\"\"}','111111','RMB','2124','11223'),(43,0,'猫之良品','catcat','catcat@gmail.com','d61ed75a05df3d606279b1a08e33c185:vBD8kWdi3ZOWK4wNZQL8u5Ai7qLnjm8b','',1,0,'2012-04-30 13:27:51','0000-00-00 00:00:00','','{}','222222','rmb','0000','33333'),(44,1,'test1','test1','test1111@qq.com','fbc0950c36989a56ce70337d6bcfebad:V3zg8zkVZGvurlbdiRbzLBbpdkfletW1','',0,0,'2012-05-01 12:30:37','0000-00-00 00:00:00','','{\"admin_style\":\"\",\"admin_language\":\"\",\"language\":\"\",\"editor\":\"\",\"helpsite\":\"\",\"timezone\":\"\"}','test','RMB','test','test'),(45,0,'test2','test2','test2@qq.com','db89c9ec707db4741bf7c3313f1549b7:JyPkQSf0ZF3EAyRHPiSswXkJdTRRBsAE','',1,0,'2012-05-01 12:34:37','0000-00-00 00:00:00','','{\"admin_style\":\"\",\"admin_language\":\"\",\"language\":\"\",\"editor\":\"\",\"helpsite\":\"\",\"timezone\":\"\"}','','RMB','','');
/*!40000 ALTER TABLE `uxlo0_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_viewlevels`
--

DROP TABLE IF EXISTS `uxlo0_viewlevels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_viewlevels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `title` varchar(100) NOT NULL DEFAULT '',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rules` varchar(5120) NOT NULL COMMENT 'JSON encoded access control.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_assetgroup_title_lookup` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_viewlevels`
--

LOCK TABLES `uxlo0_viewlevels` WRITE;
/*!40000 ALTER TABLE `uxlo0_viewlevels` DISABLE KEYS */;
INSERT INTO `uxlo0_viewlevels` VALUES (1,'Public',0,'[1]'),(2,'Registered',1,'[6,2,8]'),(3,'Special',2,'[6,3,8]');
/*!40000 ALTER TABLE `uxlo0_viewlevels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_weblinks`
--

DROP TABLE IF EXISTS `uxlo0_weblinks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_weblinks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL DEFAULT '0',
  `sid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `url` varchar(250) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hits` int(11) NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '1',
  `access` int(11) NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  `language` char(7) NOT NULL DEFAULT '',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if link is featured.',
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`state`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_weblinks`
--

LOCK TABLES `uxlo0_weblinks` WRITE;
/*!40000 ALTER TABLE `uxlo0_weblinks` DISABLE KEYS */;
/*!40000 ALTER TABLE `uxlo0_weblinks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `uxlo0_wf_profiles`
--

DROP TABLE IF EXISTS `uxlo0_wf_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uxlo0_wf_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `users` text NOT NULL,
  `types` varchar(255) NOT NULL,
  `components` text NOT NULL,
  `area` tinyint(3) NOT NULL,
  `rows` text NOT NULL,
  `plugins` text NOT NULL,
  `published` tinyint(3) NOT NULL,
  `ordering` int(11) NOT NULL,
  `checked_out` tinyint(3) NOT NULL,
  `checked_out_time` datetime NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uxlo0_wf_profiles`
--

LOCK TABLES `uxlo0_wf_profiles` WRITE;
/*!40000 ALTER TABLE `uxlo0_wf_profiles` DISABLE KEYS */;
INSERT INTO `uxlo0_wf_profiles` VALUES (1,'Default','Default Profile for all users','','6,7,3,4,5,8','',0,'help,newdocument,undo,redo,spacer,bold,italic,underline,strikethrough,justifyfull,justifycenter,justifyleft,justifyright,spacer,blockquote,formatselect,styleselect,removeformat,cleanup;fontselect,fontsizeselect,forecolor,backcolor,spacer,paste,indent,outdent,numlist,bullist,sub,sup,textcase,charmap,hr;directionality,fullscreen,preview,source,print,searchreplace,spacer,table;visualaid,visualchars,nonbreaking,style,xhtmlxtras,anchor,unlink,link,imgmanager,spellchecker,article','contextmenu,browser,inlinepopups,media,help,paste,searchreplace,directionality,fullscreen,preview,source,table,textcase,print,style,nonbreaking,visualchars,xhtmlxtras,imgmanager,link,spellchecker,article',1,1,0,'0000-00-00 00:00:00','{\"editor\":{\"width\":\"\",\"height\":\"\",\"toolbar_theme\":\"default\",\"toolbar_align\":\"left\",\"toolbar_location\":\"top\",\"statusbar_location\":\"bottom\",\"path\":\"1\",\"resizing\":\"1\",\"resize_horizontal\":\"1\",\"resizing_use_cookie\":\"1\",\"dialog_theme\":\"jce\",\"profile_content_css\":\"2\",\"profile_content_css_custom\":\"\",\"relative_urls\":\"1\",\"invalid_elements\":\"\",\"invalid_attributes\":\"dynsrc,lowsrc\",\"invalid_attribute_values\":\"\",\"extended_elements\":\"\",\"allow_javascript\":\"0\",\"allow_css\":\"0\",\"allow_php\":\"0\",\"inline_styles\":\"1\",\"cdata\":\"1\",\"theme_advanced_blockformats\":[\"p\",\"div\",\"h1\",\"h2\",\"h3\",\"h4\",\"h5\",\"h6\",\"address\",\"code\",\"pre\",\"samp\",\"span\"],\"theme_advanced_styles\":\"\",\"theme_advanced_fonts_add\":\"\",\"theme_advanced_fonts_remove\":\"\",\"theme_advanced_font_sizes\":\"8pt,10pt,12pt,14pt,18pt,24pt,36pt\",\"visualchars\":\"0\",\"toggle\":\"1\",\"toggle_state\":\"1\",\"toggle_label\":\"[Toggle Editor]\",\"custom_colors\":\"\",\"dir\":\"\",\"filesystem\":{\"name\":\"joomla\",\"joomla\":{\"allow_root\":\"0\",\"restrict_dir\":\"administrator,cache,components,includes,language,libraries,logs,media,modules,plugins,templates,xmlrpc\"}},\"max_size\":\"\",\"upload_conflict\":\"overwrite\",\"upload_runtimes\":[\"html5\",\"flash\"],\"browser_position\":\"bottom\",\"folder_tree\":\"1\",\"list_limit\":\"all\",\"validate_mimetype\":\"0\",\"websafe_mode\":\"utf-8\"},\"browser\":{\"dir\":\"\",\"max_size\":\"\",\"extensions\":\"xml=xml;html=htm,html;office=doc,docx,ppt,xls;text=txt,rtf;image=gif,jpeg,jpg,png;acrobat=pdf;archive=zip,tar,gz,rar;flash=swf;quicktime=mov,mp4,qt;windowsmedia=wmv,asx,asf,avi;audio=wav,mp3,aiff;openoffice=odt,odg,odp,ods,odf\",\"filesystem\":{\"name\":\"\"},\"upload\":\"1\",\"folder_new\":\"1\",\"folder_delete\":\"1\",\"folder_rename\":\"1\",\"folder_move\":\"1\",\"file_delete\":\"1\",\"file_rename\":\"1\",\"file_move\":\"1\"},\"media\":{\"strict\":\"1\",\"iframes\":\"0\",\"audio\":\"1\",\"video\":\"1\",\"object\":\"1\",\"embed\":\"1\",\"version_flash\":\"10,1,53,64\",\"version_windowsmedia\":\"10,00,00,3646\",\"version_quicktime\":\"7,3,0,0\",\"version_java\":\"1,5,0,0\",\"version_shockwave\":\"10,2,0,023\"},\"paste\":{\"use_dialog\":\"0\",\"dialog_width\":\"450\",\"dialog_height\":\"400\",\"force_cleanup\":\"1\",\"strip_class_attributes\":\"all\",\"remove_spans\":\"0\",\"remove_styles\":\"0\",\"retain_style_properties\":\"\",\"remove_empty_paragraphs\":\"1\",\"remove_styles_if_webkit\":\"0\",\"html\":\"1\",\"text\":\"1\"},\"source\":{\"highlight\":\"1\",\"numbers\":\"1\",\"wrap\":\"1\",\"theme\":\"textmate\"},\"table\":{\"width\":\"\",\"height\":\"\",\"border\":\"0\",\"cols\":\"2\",\"rows\":\"2\",\"cellpadding\":\"\",\"cellspacing\":\"\"},\"imgmanager\":{\"dir\":\"\",\"max_size\":\"\",\"extensions\":\"image=jpeg,jpg,png,gif\",\"hide_xtd_btns\":\"0\",\"filesystem\":{\"name\":\"\"},\"margin_top\":\"\",\"margin_right\":\"\",\"margin_bottom\":\"\",\"margin_left\":\"\",\"border\":\"0\",\"border_width\":\"1\",\"border_style\":\"solid\",\"border_color\":\"#000000\",\"align\":\"\",\"tabs_rollover\":\"1\",\"tabs_advanced\":\"1\",\"attributes_dimensions\":\"1\",\"attributes_align\":\"1\",\"attributes_margin\":\"1\",\"attributes_border\":\"1\",\"upload\":\"1\",\"folder_new\":\"1\",\"folder_delete\":\"1\",\"folder_rename\":\"1\",\"folder_move\":\"1\",\"file_delete\":\"1\",\"file_rename\":\"1\",\"file_move\":\"1\"},\"link\":{\"target\":\"\",\"file_browser\":\"1\",\"tabs_advanced\":\"1\",\"attributes_anchor\":\"1\",\"attributes_target\":\"1\",\"links\":{\"joomlalinks\":{\"enable\":\"1\",\"article_alias\":\"1\",\"weblinks_alias\":\"1\",\"content\":\"1\",\"static\":\"1\",\"contacts\":\"1\",\"weblinks\":\"1\",\"menu\":\"1\"}},\"popups\":{\"jcemediabox\":{\"enable\":\"1\"},\"window\":{\"enable\":\"1\"}}},\"spellchecker\":{\"engine\":\"googlespell\",\"languages\":\"English=en\",\"pspell_mode\":\"PSPELL_FAST\",\"pspell_spelling\":\"\",\"pspell_jargon\":\"\",\"pspell_encoding\":\"\",\"pspell_dictionary\":\"components\\/com_jce\\/editor\\/tiny_mce\\/plugins\\/spellchecker\\/dictionary.pws\",\"pspellshell_aspell\":\"\\/usr\\/bin\\/aspell\",\"pspellshell_tmp\":\"\\/tmp\"},\"article\":{\"show_readmore\":\"1\",\"show_pagebreak\":\"1\",\"hide_xtd_btns\":\"0\"}}'),(2,'Front End','Sample Front-end Profile','','3,4,5','',1,'help,newdocument,undo,redo,spacer,bold,italic,underline,strikethrough,justifyfull,justifycenter,justifyleft,justifyright,spacer,formatselect,styleselect;paste,searchreplace,indent,outdent,numlist,bullist,cleanup,charmap,removeformat,hr,sub,sup,textcase,nonbreaking,visualchars;fullscreen,preview,print,visualaid,style,xhtmlxtras,anchor,unlink,link,imgmanager,spellchecker,article','contextmenu,inlinepopups,help,paste,searchreplace,fullscreen,preview,print,style,textcase,nonbreaking,visualchars,xhtmlxtras,imgmanager,link,spellchecker,article',0,2,0,'0000-00-00 00:00:00','');
/*!40000 ALTER TABLE `uxlo0_wf_profiles` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-05-06 17:11:38
